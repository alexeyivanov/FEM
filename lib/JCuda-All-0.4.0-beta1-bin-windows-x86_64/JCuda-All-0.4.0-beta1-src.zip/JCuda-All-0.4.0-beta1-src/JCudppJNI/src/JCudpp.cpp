/*
 * JCudpp - Java bindings for CUDPP, the CUDA Data Parallel
 * Primitives Library, to be used with JCuda
 *
 * Copyright (c) 2009 Marco Hutter - http://www.jcuda.org
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include "cudpp.h"
#include "JCudpp.hpp"
#include "JCudpp_common.hpp"
#include <cuda_runtime.h>
#include <cuda.h>

jfieldID CUDPPConfiguration_algorithm; // CUDPPAlgorithm
jfieldID CUDPPConfiguration_op; // CUDPPOperator
jfieldID CUDPPConfiguration_datatype; // CUDPPDatatype
jfieldID CUDPPConfiguration_options; // unsigned int

jfieldID CUDPPHandle_nativeID; // long


/**
 * Called when the library is loaded. Will initialize all
 * required field and method IDs
 */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *jvm, void *reserved)
{
    JNIEnv *env = NULL;
    if (jvm->GetEnv((void **)&env, JNI_VERSION_1_4))
    {
        return JNI_ERR;
    }

    Logger::log(LOG_TRACE, "Initializing JCudpp\n");

    jclass cls = NULL;

    // Initialize the JNIUtils and PointerUtils
    if (initJNIUtils(env) == JNI_ERR) return JNI_ERR;
    if (initPointerUtils(env) == JNI_ERR) return JNI_ERR;


    // Obtain the fieldIDs of the CUDPPConfiguration class
    if (!init(env, cls, "jcuda/jcudpp/CUDPPConfiguration")) return JNI_ERR;
    if (!init(env, cls, CUDPPConfiguration_algorithm, "algorithm", "I")) return JNI_ERR;
    if (!init(env, cls, CUDPPConfiguration_op,        "op",        "I")) return JNI_ERR;
    if (!init(env, cls, CUDPPConfiguration_datatype,  "datatype",  "I")) return JNI_ERR;
    if (!init(env, cls, CUDPPConfiguration_options,   "options",   "I")) return JNI_ERR;


    // Obtain the fieldIDs of the CUDPPHandle class
    if (!init(env, cls, "jcuda/jcudpp/CUDPPHandle")) return JNI_ERR;
    if (!init(env, cls, CUDPPHandle_nativeID, "nativeID", "J")) return JNI_ERR;

    return JNI_VERSION_1_4;
}



/*
 * Set the log level
 *
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    setLogLevel
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_jcuda_jcudpp_JCudpp_setLogLevel
  (JNIEnv *env, jclass cla, jint logLevel)
{
    Logger::setLogLevel((LogLevel)logLevel);
}



//============================================================================



/**
 * Returns the native representation of the given Java object
 */
CUDPPConfiguration getCUDPPConfiguration(JNIEnv *env, jobject config)
{
    CUDPPConfiguration nativeConfig;

    nativeConfig.algorithm = (CUDPPAlgorithm)env->GetIntField(config, CUDPPConfiguration_algorithm);
    nativeConfig.op        = (CUDPPOperator) env->GetIntField(config, CUDPPConfiguration_op);
    nativeConfig.datatype  = (CUDPPDatatype) env->GetIntField(config, CUDPPConfiguration_datatype);
    nativeConfig.options   = (unsigned int)  env->GetIntField(config, CUDPPConfiguration_options);

    return nativeConfig;
}


//============================================================================



/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppPlanNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/jcudpp/CUDPPConfiguration;JJJ)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppPlanNative
  (JNIEnv *env, jclass cls, jobject planHandle, jobject config, jlong n, jlong rows, jlong rowPitch)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppPlan");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (config == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'config' is null for cudppPlan");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Creating cudppPlan\n");

    CUDPPHandle nativePlanHandle;
    CUDPPConfiguration nativeConfig = getCUDPPConfiguration(env, config);

    int result = cudppPlan(&nativePlanHandle, nativeConfig, (size_t)n, (size_t)rows, (size_t)rowPitch);

    env->SetLongField(planHandle, CUDPPHandle_nativeID, (jlong)nativePlanHandle);

    return result;
}







/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppDestroyPlanNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppDestroyPlanNative
  (JNIEnv *env, jclass cls, jobject planHandle)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppDestroyPlan");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Destroying cudppPlan\n");

    CUDPPHandle nativePlanHandle =  (CUDPPHandle)env->GetLongField(planHandle, CUDPPHandle_nativeID);
    int result = cudppDestroyPlan(nativePlanHandle);
    return result;
}



/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppScanNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/Pointer;Ljcuda/Pointer;J)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppScanNative
  (JNIEnv *env, jclass cls, jobject planHandle, jobject d_out, jobject d_in, jlong numElements)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppScan");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_out == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_out' is null for cudppScan");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_in == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_in' is null for cudppScan");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cudppScan on %ld elements\n", (long)numElements);

    CUDPPHandle nativePlanHandle = (CUDPPHandle)env->GetLongField(planHandle, CUDPPHandle_nativeID);
    void *nativeD_out = getPointer(env, d_out);
    void *nativeD_in  = getPointer(env, d_in);

    int result = cudppScan(nativePlanHandle, nativeD_out, nativeD_in, (size_t)numElements);

    return result;
}



/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppMultiScanNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/Pointer;Ljcuda/Pointer;JJ)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppMultiScanNative
  (JNIEnv *env, jclass cls, jobject planHandle, jobject d_out, jobject d_in, jlong numElements, jlong numRows)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppMultiScan");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_out == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_out' is null for cudppMultiScan");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_in == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_in' is null for cudppMultiScan");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cudppMultiScan on %ld elements with %ld rows\n", (long)numElements, (long)numRows);

    CUDPPHandle nativePlanHandle = (CUDPPHandle)env->GetLongField(planHandle, CUDPPHandle_nativeID);
    void *nativeD_out = getPointer(env, d_out);
    void *nativeD_in  = getPointer(env, d_in);

    int result = cudppMultiScan(nativePlanHandle, nativeD_out, nativeD_in, (size_t)numElements, (size_t)numRows);

    return result;
}



/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppSegmentedScanNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/Pointer;Ljcuda/Pointer;Ljcuda/Pointer;J)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppSegmentedScanNative
  (JNIEnv *env, jclass cls, jobject planHandle, jobject d_out, jobject d_in, jobject d_iflags, jlong numElements)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppMultiScan");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_out == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_out' is null for cudppMultiScan");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_in == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_in' is null for cudppMultiScan");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_iflags == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_iflags' is null for cudppMultiScan");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cudppSegmentedScan on %ld elements \n", (long)numElements);

    CUDPPHandle nativePlanHandle = (CUDPPHandle)env->GetLongField(planHandle, CUDPPHandle_nativeID);
    void *nativeD_out = getPointer(env, d_out);
    void *nativeD_in  = getPointer(env, d_in);
    unsigned int *nativeD_iflags  = (unsigned int *)getPointer(env, d_iflags);


    int result = cudppSegmentedScan(nativePlanHandle, nativeD_out, nativeD_in, nativeD_iflags, (size_t)numElements);

    return result;
}


/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppCompactNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/Pointer;Ljcuda/Pointer;Ljcuda/Pointer;Ljcuda/Pointer;J)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppCompactNative
  (JNIEnv *env, jclass cls, jobject planHandle, jobject d_out, jobject d_numValidElements, jobject d_in, jobject d_isValid, jlong numElements)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppCompact");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_out == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_out' is null for cudppCompact");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_numValidElements == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_numValidElements' is null for cudppCompact");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_in == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_in' is null for cudppCompact");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_isValid == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_isValid' is null for cudppCompact");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cudppCompact on %ld elements \n", (long)numElements);

    CUDPPHandle nativePlanHandle = (CUDPPHandle)env->GetLongField(planHandle, CUDPPHandle_nativeID);
    void *nativeD_out                =                getPointer(env, d_out);
    size_t *nativeD_numValidElements = (size_t*)      getPointer(env, d_numValidElements);
    void *nativeD_in                 =                getPointer(env, d_in);
    unsigned int *nativeD_isValid    = (unsigned int*)getPointer(env, d_isValid);

    int result = cudppCompact(nativePlanHandle, nativeD_out, nativeD_numValidElements, nativeD_in, nativeD_isValid, (size_t)numElements);

    return result;
}



/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppSortNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/Pointer;Ljcuda/Pointer;IJ)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppSortNative
  (JNIEnv *env, jclass cls, jobject planHandle, jobject d_keys, jobject d_values, jint keyBits, jlong numElements)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppSort");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_keys == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_keys' is null for cudppSort");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cudppSort on %ld elements\n", (long)numElements);

    CUDPPHandle nativePlanHandle = (CUDPPHandle)env->GetLongField(planHandle, CUDPPHandle_nativeID);
    void *nativeD_keys = getPointer(env, d_keys);
    void *nativeD_values  = getPointer(env, d_values);

    int result = cudppSort(nativePlanHandle, nativeD_keys, nativeD_values, (int)keyBits, (size_t)numElements);

    return result;
}



/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppSparseMatrixNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/jcudpp/CUDPPConfiguration;JJLjcuda/Pointer;Ljcuda/Pointer;Ljcuda/Pointer;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppSparseMatrixNative
  (JNIEnv *env, jclass cls, jobject sparseMatrixHandle, jobject config, jlong numNonZeroElements, jlong numRows, jobject A, jobject h_rowIndices, jobject h_indices)
{
    if (sparseMatrixHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'sparseMatrixHandle' is null for cudppSparseMatrix");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (config == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'config' is null for cudppSparseMatrix");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (A == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'A' is null for cudppSparseMatrix");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (h_rowIndices == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'h_rowIndices' is null for cudppSparseMatrix");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (h_indices == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'h_indices' is null for cudppSparseMatrix");
        return JCUDPP_INTERNAL_ERROR;
    }


    Logger::log(LOG_TRACE, "Executing cudppSparseMatrix\n");

    CUDPPHandle nativeSparseMatrixHandle;

    CUDPPConfiguration nativeConfig = getCUDPPConfiguration(env, config);

    PointerData *APointerData = initPointerData(env, A);
	if (APointerData == NULL)
	{
		return JCUDPP_INTERNAL_ERROR;
	}
    PointerData *h_rowIndicesPointerData = initPointerData(env, h_rowIndices);
	if (h_rowIndicesPointerData == NULL)
	{
		return JCUDPP_INTERNAL_ERROR;
	}
    PointerData *h_indicesPointerData = initPointerData(env, h_indices);
	if (h_indicesPointerData == NULL)
	{
		return JCUDPP_INTERNAL_ERROR;
	}

    int result = cudppSparseMatrix(
        &nativeSparseMatrixHandle,
        nativeConfig,
        (size_t)numNonZeroElements,
        (size_t)numRows,
        (void*)APointerData->getPointer(env),
        (unsigned int*)h_rowIndicesPointerData->getPointer(env),
        (unsigned int*)h_indicesPointerData->getPointer(env));

    if (!releasePointerData(env, APointerData)) return JCUDPP_INTERNAL_ERROR;
    if (!releasePointerData(env, h_rowIndicesPointerData)) return JCUDPP_INTERNAL_ERROR;
    if (!releasePointerData(env, h_indicesPointerData)) return JCUDPP_INTERNAL_ERROR;

    env->SetLongField(sparseMatrixHandle, CUDPPHandle_nativeID, (jlong)nativeSparseMatrixHandle);

    return result;
}







/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppDestroySparseMatrixNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppDestroySparseMatrixNative
  (JNIEnv *env, jclass cls, jobject sparseMatrixHandle)
{
    if (sparseMatrixHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'sparseMatrixHandle' is null for cudppDestroySparseMatrix");
        return JCUDPP_INTERNAL_ERROR;
    }
    Logger::log(LOG_TRACE, "Executing cudppDestroySparseMatrix\n");

    CUDPPHandle nativeSparseMatrixHandle = (CUDPPHandle)env->GetLongField(sparseMatrixHandle, CUDPPHandle_nativeID);

    int result = cudppDestroySparseMatrix(nativeSparseMatrixHandle);
    return result;
}



/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppSparseMatrixVectorMultiplyNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/Pointer;Ljcuda/Pointer;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppSparseMatrixVectorMultiplyNative
  (JNIEnv *env, jclass cls, jobject sparseMatrixHandle, jobject d_y, jobject d_x)
{
    if (sparseMatrixHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'sparseMatrixHandle' is null for cudppSparseMatrixVectorMultiply");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_y == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_y' is null for cudppSparseMatrixVectorMultiply");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_x == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_x' is null for cudppSparseMatrixVectorMultiply");
        return JCUDPP_INTERNAL_ERROR;
    }
    Logger::log(LOG_TRACE, "Executing cudppSparseMatrixVectorMultiply\n");


    CUDPPHandle nativeSparseMatrixHandle = (CUDPPHandle)env->GetLongField(sparseMatrixHandle, CUDPPHandle_nativeID);
    void *nativeD_y = getPointer(env, d_y);
    void *nativeD_x = getPointer(env, d_x);

    int result = cudppSparseMatrixVectorMultiply(nativeSparseMatrixHandle, nativeD_y, nativeD_x);

    return result;
}



/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppRandNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;Ljcuda/Pointer;J)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppRandNative
  (JNIEnv *env, jclass cls, jobject planHandle, jobject d_out, jlong numElements)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppRand");
        return JCUDPP_INTERNAL_ERROR;
    }
    if (d_out == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'd_out' is null for cudppRand");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cudppRand on %ld elements \n", (long)numElements);

    CUDPPHandle nativePlanHandle = (CUDPPHandle)env->GetLongField(planHandle, CUDPPHandle_nativeID);
    void *nativeD_out = getPointer(env, d_out);

    int result = cudppRand(nativePlanHandle, nativeD_out, (size_t)numElements);

    return result;

}


/*
 * Class:     jcuda_jcudpp_JCudpp
 * Method:    cudppRandSeedNative
 * Signature: (Ljcuda/jcudpp/CUDPPHandle;I)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcudpp_JCudpp_cudppRandSeedNative
  (JNIEnv *env, jclass cls, jobject planHandle, jint seed)
{
    if (planHandle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'planHandle' is null for cudppRandSeed");
        return JCUDPP_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cudppRandSeed\n");

    CUDPPHandle nativePlanHandle = (CUDPPHandle)env->GetLongField(planHandle, CUDPPHandle_nativeID);

    int result = cudppRandSeed(nativePlanHandle, (unsigned int)seed);

    return result;
}





