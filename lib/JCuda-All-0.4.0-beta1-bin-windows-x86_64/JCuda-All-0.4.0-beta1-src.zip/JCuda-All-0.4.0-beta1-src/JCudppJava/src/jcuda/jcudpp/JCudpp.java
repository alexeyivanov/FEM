/*
 * JCudpp - Java bindings for CUDPP, the CUDA Data Parallel
 * Primitives Library, to be used with JCuda
 *
 * Copyright (c) 2009 Marco Hutter - http://www.jcuda.org
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * 
 * 
 * --- BEGIN OF CUDPP LICENSE --->
 * Copyright (c) 2007-2009 The Regents of the University of California, Davis
 * campus ("The Regents") and NVIDIA Corporation ("NVIDIA"). All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *     * Neither the name of the The Regents, nor NVIDIA, nor the names of its 
 *       contributors may be used to endorse or promote products derived from this 
 *       software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * <--- END OF CUDPP LICENSE ---
 * 
 * Homepage for CUDPP: http://www.gpgpu.org/developer/cudpp/
 */


package jcuda.jcudpp;
import jcuda.*;

/**
 * Java bindings for the public interface of CUDPP, the CUDA Data 
 * Parallel Primitives Library. <br />
 * (http://www.gpgpu.org/developer/cudpp/) <br />
 * <br />
 * Most comments are taken from the CUDPP library documentation.<br />
 */
public class JCudpp
{
    /**
     * The flag that indicates whether the native library has been
     * loaded
     */
    private static boolean initialized = false;

    
    /**
     * Whether a CudaException should be thrown if a method is about
     * to return a result code that is not CUDPPResult.CUDPP_SUCCESS
     */
    private static boolean exceptionsEnabled = false;
    
    /* Private constructor to prevent instantiation */
    private JCudpp()
    {
    }

    /**
     * Set the flag which indicates whether the emulation mode
     * should be used.<br />
     * 
     * @deprecated The emulation mode has been deprecated in
     * CUDA 3.0. This function no longer has any effect, and
     * will be removed in the next release.
     */
    public static void setEmulation(boolean emulation)
    {
    }


    /**
     * Set the specified log level for the JCudpp library.<br />
     * <br />
     * Currently supported log levels:
     * <br />
     * LOG_QUIET: Never print anything <br />
     * LOG_ERROR: Print error messages <br />
     * LOG_TRACE: Print a trace of all native function calls <br />
     *
     * @param logLevel The log level to use.
     */
    public static void setLogLevel(LogLevel logLevel)
    {
        assertInit();
        setLogLevel(logLevel.ordinal());
    }

    private static native void setLogLevel(int logLevel);

    
    /**
     * Enables or disables exceptions. By default, the methods of this class
     * only return the CUDPPResult error code from the underlying CUDA function.
     * If exceptions are enabled, a CudaException with a detailed error 
     * message will be thrown if a method is about to return a result code 
     * that is not CUDPPResult.CUDPP_SUCCESS
     * 
     * @param enabled Whether exceptions are enabled
     */
    public static void setExceptionsEnabled(boolean enabled)
    {
        exceptionsEnabled = enabled;
    }

    /**
     * If the given result is different to CUDPPResult.CUDPP_SUCCESS and
     * exceptions have been enabled, this method will throw a 
     * CudaException with an error message that corresponds to the
     * given result code. Otherwise, the given result is simply
     * returned.
     * 
     * @param result The result to check
     * @return The result that was given as the parameter
     * @throws CudaException If exceptions have been enabled and
     * the given result code is not CUDPPResult.CUDPP_SUCCESS
     */
    private static int checkResult(int result)
    {
        if (exceptionsEnabled && result != CUDPPResult.CUDPP_SUCCESS)
        {
            throw new CudaException(CUDPPResult.stringFor(result));
        }
        return result;
    }
    
    
    
    /**
     * Initializes the native library. Note that this method
     * does not have to be called explicitly by the user of
     * the library: The library will automatically be 
     * initialized with the first function call.
     */
    public static void initialize()
    {
        assertInit();
    }

    
    /**
     * Assert that the native library that corresponds to the current value
     * of the emulation mode flag has been loaded.
     */
    private static void assertInit()
    {
        if (!initialized)
        {
            LibUtils.loadLibrary("JCudpp");
            initialized = true;
        }
    }


    /**
     * Create a CUDPP plan.<br />
     * <br />
     * A plan is a data structure containing state and intermediate storage
     * space that CUDPP uses to execute algorithms on data. A plan is created
     * by passing to cudppPlan() a CUDPPConfiguration that specifies the
     * algorithm, operator, datatype, and options. The size of the data must
     * also be passed to cudppPlan(), in the numElements, numRows, and
     * rowPitch arguments. These sizes are used to allocate internal storage
     * space at the time the plan is created. The CUDPP planner may use the
     * sizes, options, and information about the present hardware to choose
     * optimal settings.<br />
     * <br />
     * Note that numElements is the maximum size of the array to be processed
     * with this plan. That means that a plan may be re-used to process
     * (for example, to sort or scan) smaller arrays.<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *     [out]   planHandle  A pointer to an opaque handle to the internal plan
     *     [in]    config  The configuration struct specifying algorithm and options
     *     [in]    numElements     The maximum number of elements to be processed
     *     [in]    numRows     The number of rows (for 2D operations) to be processed
     *     [in]    rowPitch    The pitch of the rows of input data, in elements
     * </pre>
     */
    public static int cudppPlan(
            CUDPPHandle planHandle,
            CUDPPConfiguration config,
            long n,
            long rows,
            long rowPitch)
    {
        assertInit();
        return checkResult(cudppPlanNative(planHandle, config, n, rows, rowPitch));
    }
    private static native int cudppPlanNative(
            CUDPPHandle planHandle,
            CUDPPConfiguration config,
            long n,
            long rows,
            long rowPitch);




    /**
     * Destroy a CUDPP Plan.<br />
     * <br />
     * Deletes the plan referred to by planHandle and all associated internal
     * storage.<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *      [in]    planHandle  The CUDPPHandle to the plan to be destroyed
     * </pre>
     */
    public static int cudppDestroyPlan(CUDPPHandle plan)
    {
        assertInit();
        return checkResult(cudppDestroyPlanNative(plan));
    }
    private static native int cudppDestroyPlanNative(CUDPPHandle plan);


    /**
     * Performs a scan operation of numElements on its input in GPU memory
     * (d_in) and places the output in GPU memory (d_out), with the scan
     * parameters specified in the plan pointed to by planHandle.<br />
     *
     * The input to a scan operation is an input array, a binary
     * associative operator (like + or max), and an identity element for
     * that operator (+'s identity is 0). The output of scan is the same
     * size as its input. Informally, the output at each element is the
     * result of operator applied to each input that comes before it.
     * For instance, the output of sum-scan at each element is the sum
     * of all the input elements before that input.<br />
     * <br />
     * More formally, for associative operator +,
     * out<sub>i</sub> = in<sub>0</sub> + in<sub>1</sub> + ... + in<sub>i-1</sub>.
     * <br />
     * <br />
     * CUDPP supports "exclusive" and "inclusive" scans. For the ADD operator,
     * an exclusive scan computes the sum of all input elements before the
     * current element, while an inclusive scan computes the sum of all input
     * elements up to and including the current element.<br />
     * <br />
     * Before calling scan, create an internal plan using cudppPlan().
     * <br />
     * After you are finished with the scan plan, clean up with
     * cudppDestroyPlan().<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *     [in]    planHandle  Handle to plan for this scan
     *     [out]   d_out   output of scan, in GPU memory
     *     [in]    d_in    input to scan, in GPU memory
     *     [in]    numElements     number of elements to scan
     * </pre>
     * @see jcuda.jcudpp.JCudpp#cudppPlan
     * @see jcuda.jcudpp.JCudpp#cudppDestroyPlan
     */
    public static int cudppScan(
            CUDPPHandle planHandle,
            Pointer d_out,
            Pointer d_in,
            long numElements)
    {
        assertInit();
        return checkResult(cudppScanNative(planHandle, d_out, d_in, numElements));
    }
    private static native int cudppScanNative(
            CUDPPHandle planHandle,
            Pointer d_out,
            Pointer d_in,
            long numElements);


    /**
     * Performs numRows parallel scan operations of numElements each on its
     * input (d_in) and places the output in d_out, with the scan parameters
     * set by config. Exactly like cudppScan except that it runs on multiple
     * rows in parallel.<br />
     * <br />
     * Note that to achieve good performance with cudppMultiScan one should
     * allocate the device arrays passed to it so that all rows are aligned
     * to the correct boundaries for the architecture the app is running on.
     * The easy way to do this is to use cudaMallocPitch() to allocate a 2D
     * array on the device. Use the rowPitch parameter to cudppPlan() to
     * specify this pitch. The easiest way is to pass the device pitch
     * returned by cudaMallocPitch to cudppPlan() via rowPitch.<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *     [in]    planHandle  handle to CUDPPScanPlan
     *     [out]   d_out   output of scan, in GPU memory
     *     [in]    d_in    input to scan, in GPU memory
     *     [in]    numElements     number of elements (per row) to scan
     *     [in]    numRows     number of rows to scan in parallel
     * </pre>
     * @see jcuda.jcudpp.JCudpp#cudppScan
     * @see jcuda.jcudpp.JCudpp#cudppPlan
     */
    public static int cudppMultiScan(
            CUDPPHandle planHandle,
            Pointer d_out,
            Pointer d_in,
            long numElements,
            long numRows)
    {
        assertInit();
        return checkResult(cudppMultiScanNative(planHandle, d_out, d_in, numElements, numRows));
    }
    private static native int cudppMultiScanNative(
            CUDPPHandle planHandle,
            Pointer d_out,
            Pointer d_in,
            long numElements,
            long numRows);


    /**
     * Performs a segmented scan operation of numElements on its input in GPU
     * memory (d_idata) and places the output in GPU memory (d_out), with the
     * scan parameters specified in the plan pointed to by planHandle.<br />
     * <br />
     * The input to a segmented scan operation is an input array of data, an
     * input array of flags which demarcate segments, a binary associative
     * operator (like + or max), and an identity element for that operator
     * (+'s identity is 0). The array of flags is the same length as the input
     * with 1 marking the the first element of a segment and 0 otherwise.
     * The output of segmented scan is the same size as its input. Informally,
     * the output at each element is the result of operator applied to each
     * input that comes before it in that segment. For instance, the output
     * of segmented sum-scan at each element is the sum of all the input
     * elements before that input in that segment.<br />
     * <br />
     * More formally, for associative operator +,
     * out<sub>i</sub> = in<sub>k</sub> + in<sub>k+1</sub> + ... + in<sub>i-1</sub>. k is the index of the first element
     * of the segment in which i lies.<br />
     * <br />
     * We support both "exclusive" and "inclusive" variants. For a segmented
     * sum-scan, the exclusive variant computes the sum of all input elements
     * before the current element in that segment, while the inclusive variant
     * computes the sum of all input elements up to and including the current
     * element, in that segment.<br />
     * <br />
     * Before calling segmented scan, create an internal plan using cudppPlan().
     * <br />
     * After you are finished with the scan plan, clean up with cudppDestroyPlan().
     * <br />
     * Parameters:<br />
     * <pre>
     *     [in]    planHandle  Handle to plan for this scan
     *     [out]   d_out   output of segmented scan, in GPU memory
     *     [in]    d_idata     input data to segmented scan, in GPU memory
     *     [in]    d_iflags    input flags to segmented scan, in GPU memory
     *     [in]    numElements     number of elements to perform segmented scan on
     * </pre>
     * @see jcuda.jcudpp.JCudpp#cudppPlan
     * @see jcuda.jcudpp.JCudpp#cudppDestroyPlan
     */

    public static int cudppSegmentedScan(
            CUDPPHandle planHandle,
            Pointer d_out,
            Pointer d_idata,
            Pointer d_iflags,
            long numElements)
    {
        assertInit();
        return checkResult(cudppSegmentedScanNative(planHandle, d_out, d_idata, d_iflags, numElements));
    }

    private static native int cudppSegmentedScanNative(
            CUDPPHandle planHandle,
            Pointer d_out,
            Pointer d_idata,
            Pointer d_iflags,
            long numElements);



    /**
     * Given an array d_in and an array of 1/0 flags in deviceValid, returns
     * a compacted array in d_out of corresponding only the "valid" values
     * from d_in.<br />
     * <br />
     * Takes as input an array of elements in GPU memory (d_in) and an
     * equal-sized unsigned int array in GPU memory (deviceValid) that
     * indicate which of those input elements are valid. The output is a
     * packed array, in GPU memory, of only those elements marked as valid.
     * <br />
     * Internally, uses cudppScan.<br />
     * <br />
     * Example:<br />
     * <pre>
     *  d_in    = [ a b c d e f ]
     *  deviceValid = [ 1 0 1 1 0 1 ]
     *  d_out   = [ a c d f ]
     * </pre>
     * <br />
     * Parameters:<br />
     * <pre>
     *     [in]    planHandle  handle to CUDPPCompactPlan
     *     [out]   d_out   compacted output
     *     [out]   d_numValidElements  set during cudppCompact;
     *             is set with the number of elements valid flags in the
     *             d_isValid input array
     *     [in]    d_in    input to compact
     *     [in]    d_isValid   which elements in d_in are valid
     *     [in]    numElements     number of elements in d_in
     * </pre>
     */
    public static int cudppCompact(
            CUDPPHandle planHandle,
            Pointer d_out,
            Pointer d_numValidElements,
            Pointer d_in,
            Pointer d_isValid,
            long numElements)
    {
        assertInit();
        return checkResult(cudppCompactNative(planHandle, d_out, d_numValidElements, d_in, d_isValid, numElements));
    }

    private static native int cudppCompactNative(
            CUDPPHandle planHandle,
            Pointer d_out,
            Pointer d_numValidElements,
            Pointer d_in,
            Pointer d_isValid,
            long numElements);



    /**
     * Sorts key-value pairs or keys only.<br />
     * <br />
     * Takes as input an array of keys in GPU memory (d_keys) and an optional 
     * array of corresponding values, and outputs sorted arrays of keys and 
     * (optionally) values in place. Key-value and key-only sort is selected 
     * through the configuration of the plan, using the options 
     * CUDPP_OPTION_KEYS_ONLY and CUDPP_OPTION_KEY_VALUE_PAIRS.<br />
     * <br />
     * Supported key types are CUDPP_FLOAT and CUDPP_UINT. Values can be any
     * 32-bit type (internally, values are treated only as a payload and cast 
     * to unsigned int).<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *    [in]    planHandle  handle to CUDPPSortPlan
     *    [out]   d_keys  keys by which key-value pairs will be sorted
     *    [in]    d_values    values to be sorted
     *    [in]    keyBits     the number of least significant bits in each element of d_keys to sort by
     *    [in]    numElements     number of elements in d_keys and d_values
     * </pre>
     * @see jcuda.jcudpp.JCudpp#cudppPlan
     * @see jcuda.jcudpp.CUDPPConfiguration
     * @see jcuda.jcudpp.CUDPPAlgorithm
     */
    public static int cudppSort(
            CUDPPHandle planHandle,
            Pointer d_keys,
            Pointer d_values,
            int keyBits,
            long numElements)
    {
        assertInit();
        return checkResult(cudppSortNative(planHandle, d_keys, d_values, keyBits, numElements));
    }

    private static native int cudppSortNative(
            CUDPPHandle planHandle,
            Pointer d_keys,
            Pointer d_values,
            int keyBits,
            long numElements);



    /**
     * Create a CUDPP Sparse Matrix Object.<br />
     * <br />
     * The sparse matrix plan is a data structure containing state and
     * intermediate storage space that CUDPP uses to perform sparse
     * matrix dense vector multiply. This plan is created by passing to
     * CUDPPSparseMatrixVectorMultiplyPlan() a CUDPPConfiguration that
     * specifies the algorithm (sprarse matrix-dense vector multiply)
     * and datatype, along with the sparse matrix itself in CSR format.
     * The number of non-zero elements in the sparse matrix must also
     * be passed as numNonZeroElements. This is used to allocate internal
     * storage space at the time the sparse matrix plan is created.<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *     [out]   sparseMatrixHandle  A pointer to an opaque handle to the sparse matrix object
     *     [in]    config  The configuration struct specifying algorithm and options
     *     [in]    numNonZeroElements  The number of non zero elements in the sparse matrix
     *     [in]    numRows     This is the number of rows in y, x and A for y = A * x
     *     [in]    A   The matrix data
     *     [in]    h_rowIndices    An array containing the index of the start of each row in A
     *     [in]    h_indices   An array containing the index of each nonzero element in A
     * </pre>
     */
    public static int cudppSparseMatrix(
            CUDPPHandle sparseMatrixHandle,
            CUDPPConfiguration config,
            long numNonZeroElements,
            long numRows,
            Pointer A,
            Pointer h_rowIndices,
            Pointer h_indices)
    {
        assertInit();
        return checkResult(cudppSparseMatrixNative(sparseMatrixHandle, config, numNonZeroElements, numRows, A, h_rowIndices, h_indices));
    }
    private static native int cudppSparseMatrixNative(
            CUDPPHandle sparseMatrixHandle,
            CUDPPConfiguration config,
            long numNonZeroElements,
            long numRows,
            Pointer A,
            Pointer h_rowIndices,
            Pointer h_indices);



    /**
     * Destroy a CUDPP Sparse Matrix Object.<br />
     * <br />
     * Deletes the sparse matrix data and plan referred to by
     * sparseMatrixHandle and all associated internal storage.<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *     [in]    sparseMatrixHandle  The CUDPPHandle to the matrix object to be destroyed
     * </pre>
     */
    public static int cudppDestroySparseMatrix(
            CUDPPHandle sparseMatrixHandle)
    {
        assertInit();
        return checkResult(cudppDestroySparseMatrixNative(sparseMatrixHandle));
    }

    private static native int cudppDestroySparseMatrixNative(
            CUDPPHandle sparseMatrixHandle);



    /**
     * Perform matrix-vector multiply y = A*x for arbitrary sparse matrix
     * A and vector x.<br />
     * <br />
     * Given a matrix object handle (which has been initialized using
     * cudppSparseMatrix()), This function multiplies the input vector
     * d_x by the matrix referred to by sparseMatrixHandle, returning
     * the result in d_y.<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *         sparseMatrixHandle  Handle to a sparse matrix object created
     *                             with cudppSparseMatrix()
     *         d_y     The output vector, y
     *         d_x     The input vector, x
     * </pre>
     * @see jcuda.jcudpp.JCudpp#cudppSparseMatrix
     * @see jcuda.jcudpp.JCudpp#cudppDestroySparseMatrix
     */
    public static int cudppSparseMatrixVectorMultiply(
            CUDPPHandle sparseMatrixHandle,
            Pointer d_y, Pointer d_x)
    {
        assertInit();
        return checkResult(cudppSparseMatrixVectorMultiplyNative(sparseMatrixHandle, d_y, d_x));
    }

    private static native int cudppSparseMatrixVectorMultiplyNative(
            CUDPPHandle sparseMatrixHandle,
            Pointer d_y, Pointer d_x);
    
    
    /**
     * Rand puts numElements random 32-bit elements into d_out.<br />
     * <br />
     * Outputs numElements random values to d_out. d_out must be of 
     * type unsigned int, allocated in device memory.<br />
     * <br />
     * The algorithm used for the random number generation is 
     * stored in planHandle. Depending on the specification of the pseudo 
     * random number generator(PRNG), the generator may have one or more 
     * seeds. To set the seed, use cudppRandSeed().<br />
     * <br />
     * Currently only MD5 PRNG is supported. We may provide more 
     * rand routines in the future.
     * Parameters:<br />
     * <pre>
     *    [in]    planHandle  Handle to plan for rand
     *    [in]    numElements     number of elements in d_out.
     *    [out]   d_out   output of rand, in GPU memory. Should be an array of unsigned integers.
     * </pre>
     * 
     * @see jcuda.jcudpp.CUDPPConfiguration
     * @see jcuda.jcudpp.CUDPPAlgorithm
     */
    public static int cudppRand(CUDPPHandle planHandle, Pointer d_out, long numElements)
    {
        assertInit();
        return checkResult(cudppRandNative(planHandle, d_out, numElements));
    }
    private static native int cudppRandNative(CUDPPHandle planHandle, Pointer d_out, long numElements);

    /**
     * Sets the seed used for rand.<br />
     * <br />
     * The seed is crucial to any random number generator as it allows a 
     * sequence of random numbers to be replicated. Since there may be 
     * multiple different rand algorithms in CUDPP, cudppRandSeed uses 
     * planHandle to determine which seed to set. Each rand algorithm 
     * has its own unique set of seeds depending on what the algorithm 
     * needs.<br />
     * <br />
     * Parameters:<br />
     * <pre>
     *    [in]    planHandle  the handle to the plan which specifies which rand seed to set
     *    [in]    seed    the value which the internal cudpp seed will be set to 
     */
    public static int cudppRandSeed(CUDPPHandle planHandle, int seed)
    {
        assertInit();
        return checkResult(cudppRandSeedNative(planHandle, seed));
    }
    private static native int cudppRandSeedNative(CUDPPHandle planHandle, int seed);
    
}
