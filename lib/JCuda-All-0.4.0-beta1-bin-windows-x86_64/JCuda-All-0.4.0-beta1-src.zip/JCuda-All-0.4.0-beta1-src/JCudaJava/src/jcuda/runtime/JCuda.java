/*
 * JCuda - Java bindings for NVIDIA CUDA driver and runtime API
 *
 * Copyright (c) 2009-2011 Marco Hutter - http://www.jcuda.org
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

package jcuda.runtime;

import jcuda.*;


/**
 * Java bindings for the NVidia CUDA runtime API.<br />
 * <br />
 * Most comments are extracted from the CUDA online documentation
 */
public class JCuda
{
    /**
     * CUDA runtime version
     */
    public static final int CUDART_VERSION = 4000;

    /**
     * Default page-locked allocation flag
     */
    public static final int cudaHostAllocDefault           = 0x00;

    /**
     * Pinned memory accessible by all CUDA contexts
     */
    public static final int cudaHostAllocPortable          = 0x01;

    /**
     * Map allocation into device space
     */
    public static final int cudaHostAllocMapped            = 0x02;

    /**
     * Write-combined memory
     */
    public static final int cudaHostAllocWriteCombined     = 0x04;


    /**
     * Default host memory registration flag
     */
    public static final int cudaHostRegisterDefault        = 0x00;

    /**
     * Pinned memory accessible by all CUDA contexts
     */
    public static final int cudaHostRegisterPortable       = 0x01;

    /**
     * Map registered memory into device space
     */
    public static final int cudaHostRegisterMapped         = 0x02;


    /**
     * Default peer addressing enable flag
     */
    public static final int cudaPeerAccessDefault          = 0x00;


    /**
     * Default peer device pointer query flag .
     * @deprecated This flag has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2
     */
    public static final int cudaPeerDevicePointerDefault   = 0x00;


    /**
     * Default peer memory registration flag
     * @deprecated This flag has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2
     */
    public static final int cudaPeerRegisterDefault        = 0x00;

    /**
     * Map registered memory into device space
     * @deprecated This flag has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2
     */
    public static final int cudaPeerRegisterMapped         = 0x02;


    /**
     * Default event flag
     */
    public static final int cudaEventDefault               = 0x00;

    /**
     * Event uses blocking synchronization
     */
    public static final int cudaEventBlockingSync          = 0x01;

    /**
     * Event will not record timing data
     */
    public static final int cudaEventDisableTiming         = 0x02;


    /**
     * Device flag - Automatic scheduling
     */
    public static final int cudaDeviceScheduleAuto         = 0x00;

    /**
     * Device flag - Spin default scheduling
     */
    public static final int cudaDeviceScheduleSpin         = 0x01;

    /**
     * Device flag - Yield default scheduling
     */
    public static final int cudaDeviceScheduleYield        = 0x02;

    /**
     * Device flag - Use blocking synchronization
     */
    public static final int cudaDeviceScheduleBlockingSync = 0x04;

    /**
     * Device flag - Use blocking synchronization
     * @deprecated
     */
    public static final int cudaDeviceBlockingSync         = 0x04;

    /**
     * Device flag - Support mapped pinned allocations
     */
    public static final int cudaDeviceMapHost              = 0x08;

    /**
     * Device flag - Keep local memory allocation after launch
     */
    public static final int cudaDeviceLmemResizeToMax      = 0x10;

    /**
     * Device flags mask
     */
    public static final int cudaDeviceMask                 = 0x1f;


    /**
     * Default CUDA array allocation flag
     */
    public static final int cudaArrayDefault               = 0x00 ;

    /**
     * Must be set in cudaMalloc3DArray to create a layered texture
     */
    public static final int cudaArrayLayered               = 0x01 ;

    /**
     * Must be set in cudaMallocArray in order to bind surfaces to the CUDA array
     */
    public static final int cudaArraySurfaceLoadStore      = 0x02 ;


    /**
     * The flag that indicates whether the native library has been
     * loaded
     */
    private static boolean initialized = false;

    /**
     * Whether a CudaException should be thrown if a method is about
     * to return a result code that is not cudaError.cudaSuccess
     */
    private static boolean exceptionsEnabled = false;


    /* Private constructor to prevent instantiation */
    private JCuda()
    {
    }

    /**
     * Set the flag which indicates whether a call to any
     * function should initialize the JCuda runtime API
     * in emulation mode.<br />
     *
     * @deprecated The emulation mode has been deprecated in
     * CUDA 3.0. This function no longer has any effect, and
     * will be removed in the next release.
     */
    public static void setEmulation(boolean emulation)
    {
    }

    // Initialize the native library.
    static
    {
        initialize();
    }

    /**
     * Initializes the native library. Note that this method
     * does not have to be called explicitly by the user of
     * the library: The library will automatically be
     * initialized when this class is loaded.
     */
    public static void initialize()
    {
        if (!initialized)
        {
            LibUtils.loadLibrary("JCudaRuntime");
            initialized = true;
        }
    }

    /**
     * Set the specified log level for the JCuda runtime library.<br />
     * <br />
     * Currently supported log levels:
     * <br />
     * LOG_QUIET: Never print anything <br />
     * LOG_ERROR: Print error messages <br />
     * LOG_TRACE: Print a trace of all native function calls <br />
     *
     * @param logLevel The log level to use.
     */
    public static void setLogLevel(LogLevel logLevel)
    {
        setLogLevel(logLevel.ordinal());
    }

    private static native void setLogLevel(int logLevel);


    /**
     * Enables or disables exceptions. By default, the methods of this class
     * only return the cudaError error code from the underlying CUDA function.
     * If exceptions are enabled, a CudaException with a detailed error
     * message will be thrown if a method is about to return a result code
     * that is not cudaError.cudaSuccess
     *
     * @param enabled Whether exceptions are enabled
     */
    public static void setExceptionsEnabled(boolean enabled)
    {
        exceptionsEnabled = enabled;
    }

    /**
     * If the given result is different to cudaError.cudaSuccess and
     * exceptions have been enabled, this method will throw a
     * CudaException with an error message that corresponds to the
     * given result code. Otherwise, the given result is simply
     * returned.
     *
     * @param result The result to check
     * @return The result that was given as the parameter
     * @throws CudaException If exceptions have been enabled and
     * the given result code is not cudaError.cudaSuccess
     */
    private static int checkResult(int result)
    {
        if (exceptionsEnabled && result != cudaError.cudaSuccess)
        {
            throw new CudaException(cudaError.stringFor(result));
        }
        return result;
    }




    /**
     * Returns the number of compute-capable devices.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetDeviceCount           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>count</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*count</code> the number of devices with compute
     *       capability greater or equal to 1.0 that are available for execution.
     *       If there is no such device, <code>cudaGetDeviceCount()</code> returns
     *       1 and device 0 only supports device emulation mode. Since this device
     *       will be able to emulate all hardware features, this device will report
     *       major and minor compute capability versions of 9999.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaGetDevice
     * @see JCuda#cudaSetDevice
     * @see JCuda#cudaGetDeviceProperties
     * @see JCuda#cudaChooseDevice
     */
    public static int cudaGetDeviceCount(int count[])
    {
        return checkResult(cudaGetDeviceCountNative(count));
    }
    private static native int cudaGetDeviceCountNative(int count[]);


    /**
     * Set device to be used for GPU executions.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaSetDevice           </td>
     *         <td>(</td>
     *         <td>int&nbsp;</td>
     *         <td> <em>device</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets <code>device</code> as the current device for the calling host
     *       thread.
     *     <p>
     *       Any device memory subsequently allocated from this host thread using
     *       cudaMalloc(), cudaMallocPitch() or cudaMallocArray() will be physically
     *       resident on <code>device</code>. Any host memory allocated from this
     *       host thread using cudaMallocHost() or cudaHostAlloc() or
     *       cudaHostRegister() will have its lifetime associated with
     *       <code>device</code>. Any streams or events created from this host
     *       thread will be associated with <code>device</code>. Any kernels launched
     *       from this host thread using the &lt;&lt;&lt;&gt;&gt;&gt; operator or
     *       cudaLaunch() will be executed on <code>device</code>.
     *     <p>
     *       This call may be made from any host thread, to any device, and at any
     *       time. This function will do no synchronization with the previous or
     *       new device, and should be considered a very low overhead call.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevice, cudaErrorSetOnActiveProcess
     *
     *
     * @see JCuda#cudaGetDeviceCount
     * @see JCuda#cudaGetDevice
     * @see JCuda#cudaGetDeviceProperties
     * @see JCuda#cudaChooseDevice
     */
    public static int cudaSetDevice(int device)
    {
        return checkResult(cudaSetDeviceNative(device));
    }
    private static native int cudaSetDeviceNative(int device);


    /**
     * Sets flags to be used for device executions.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaSetDeviceFlags           </td>
     *         <td>(</td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Records <code>flags</code> as the flags to use when initializing the
     *       current device. If no device has been made current to the calling
     *       thread then <code>flags</code> will be applied to the initialization
     *       of any device initialized by the calling host thread, unless that
     *       device has had its initialization flags set explicitly by this or any
     *       host thread.
     *     <p>
     *       If the current device has been set and that device has already been
     *       initialized then this call will fail with the error
     *       cudaErrorSetOnActiveProcess. In this case it is necessary to reset
     *       <code>device</code> using cudaDeviceReset() before the device's
     *       initialization flags may be set.
     *     <p>
     *       The two LSBs of the <code>flags</code> parameter can be used to control
     *       how the CPU thread interacts with the OS scheduler when waiting for
     *       results from the device.
     *     <p>
     *     <ul>
     *       <li>cudaDeviceScheduleAuto: The default value if the <code>flags</code>
     *         parameter is zero, uses a heuristic based on the number of active CUDA
     *         contexts in the process <code>C</code> and the number of logical
     *         processors in the system <code>P</code>. If <code>C</code> &gt;
     *         <code>P</code>, then CUDA will yield to other OS threads when waiting
     *         for the device, otherwise CUDA will not yield while waiting for results
     *         and actively spin on the processor.
     *       </li>
     *       <li>cudaDeviceScheduleSpin:
     *         Instruct CUDA to actively spin when waiting for results from the
     *         device. This can decrease latency when waiting for the device, but may
     *         lower the performance of CPU threads if they are performing work in
     *         parallel with the CUDA thread.
     *       </li>
     *       <li>cudaDeviceScheduleYield: Instruct
     *         CUDA to yield its thread when waiting for results from the device. This
     *         can increase latency when waiting for the device, but can increase the
     *         performance of CPU threads performing work in parallel with the
     *         device.
     *       </li>
     *       <li>cudaDeviceScheduleBlockingSync: Instruct CUDA to block
     *         the CPU thread on a synchronization primitive when waiting for the
     *         device to finish work.
     *       </li>
     *       <li>
     *         cudaDeviceBlockingSync: Instruct CUDA
     *         to block the CPU thread on a synchronization primitive when waiting
     *         for the device to finish work.
     *         <dl compact>
     *           <dt><b>Deprecated:</b></dt>
     *           <dd>This
     *             flag was deprecated as of CUDA 4.0 and replaced with
     *             cudaDeviceScheduleBlockingSync.
     *           </dd>
     *         </dl>
     *       </li>
     *     </ul>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevice,
     * cudaErrorSetOnActiveProcess
     *
     * @see JCuda#cudaGetDeviceCount
     * @see JCuda#cudaGetDevice
     * @see JCuda#cudaGetDeviceProperties
     * @see JCuda#cudaSetDevice
     * @see JCuda#cudaSetValidDevices
     * @see JCuda#cudaChooseDevice
     */
    public static int cudaSetDeviceFlags(int flags)
    {
        return checkResult(cudaSetDeviceFlagsNative(flags));
    }
    private static native int cudaSetDeviceFlagsNative(int flags);


    /**
     * Set a list of devices that can be used for CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaSetValidDevices           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>device_arr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>len</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets a list of devices for CUDA execution in priority order using
     *       <code>device_arr</code>. The parameter <code>len</code> specifies the
     *       number of elements in the list. CUDA will try devices from the list
     *       sequentially until it finds one that works. If this function is not
     *       called, or if it is called with a <code>len</code> of 0, then CUDA will
     *       go back to its default behavior of trying devices sequentially from a
     *       default list containing all of the available CUDA devices in the
     *       system. If a specified device ID in the list does not exist, this
     *       function will return cudaErrorInvalidDevice. If <code>len</code> is
     *       not 0 and <code>device_arr</code> is NULL or if <code>len</code>
     *       exceeds the number of devices in the system, then cudaErrorInvalidValue
     *       is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevice
     *
     * @see JCuda#cudaGetDeviceCount
     * @see JCuda#cudaSetDevice
     * @see JCuda#cudaGetDeviceProperties
     * @see JCuda#cudaSetDeviceFlags
     * @see JCuda#cudaChooseDevice
     */
    public static int cudaSetValidDevices (int device_arr[], int len)
    {
        return checkResult(cudaSetValidDevicesNative(device_arr, len));
    }
    private static native int cudaSetValidDevicesNative(int device_arr[], int len);

    /**
     * Returns which device is currently being used.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetDevice           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>device</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*device</code> the current device for the calling host
     *       thread.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaGetDeviceCount
     * @see JCuda#cudaSetDevice
     * @see JCuda#cudaGetDeviceProperties
     * @see JCuda#cudaChooseDevice
     */
    public static int cudaGetDevice(int device[])
    {
        return checkResult(cudaGetDeviceNative(device));
    }
    private static native int cudaGetDeviceNative(int device[]);


    /**
     * Returns information about the compute-device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetDeviceProperties           </td>
     *         <td>(</td>
     *         <td>struct cudaDeviceProp *&nbsp;</td>
     *         <td> <em>prop</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>device</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*prop</code> the properties of device <code>dev</code>.
     *       The cudaDeviceProp structure is defined as:
     *     <div>
     *       <pre>    <span>struct </span>cudaDeviceProp {
     *         <span>char</span> name[256];
     *         <span>size_t</span> totalGlobalMem;
     *         <span>size_t</span> sharedMemPerBlock;
     *         <span>int</span> regsPerBlock;
     *         <span>int</span> warpSize;
     *         <span>size_t</span> memPitch;
     *         <span>int</span> maxThreadsPerBlock;
     *         <span>int</span> maxThreadsDim[3];
     *         <span>int</span> maxGridSize[3];
     *         <span>int</span> clockRate;
     *         <span>size_t</span> totalConstMem;
     *         <span>int</span> major;
     *         <span>int</span> minor;
     *         <span>size_t</span> textureAlignment;
     *         <span>int</span> deviceOverlap;
     *         <span>int</span> multiProcessorCount;
     *         <span>int</span> kernelExecTimeoutEnabled;
     *         <span>int</span> integrated;
     *         <span>int</span> canMapHostMemory;
     *         <span>int</span> computeMode;
     *         <span>int</span> maxTexture1D;
     *         <span>int</span> maxTexture2D[2];
     *         <span>int</span> maxTexture3D[3];
     *         <span>int</span> maxTexture1DLayered[2];
     *         <span>int</span> maxTexture2DLayered[3];
     *         <span>size_t</span> surfaceAlignment;
     *         <span>int</span> concurrentKernels;
     *         <span>int</span> ECCEnabled;
     *         <span>int</span> pciBusID;
     *         <span>int</span> pciDeviceID;
     *         <span>int</span> tccDriver;
     *         <span>int</span> asyncEngineCount;
     *         <span>int</span> unifiedAddressing;
     *         <span>int</span> memoryClockRate;
     *         <span>int</span> memoryBusWidth;
     *         <span>int</span> l2CacheSize;
     *         <span>int</span> maxThreadsPerMultiProcessor;
     *     }
     * </pre>
     *     </div>
     *     where:
     *     <ul>
     *       <li>name[256] is an ASCII string identifying the
     *         device;
     *       </li>
     *       <li>totalGlobalMem is the total amount of global memory
     *         available on the device in bytes;
     *       </li>
     *       <li>sharedMemPerBlock is the
     *         maximum amount of shared memory available to a thread block in bytes;
     *         this amount is shared by all thread blocks simultaneously resident on
     *         a multiprocessor;
     *       </li>
     *       <li>regsPerBlock is the maximum number of 32-bit
     *         registers available to a thread block; this number is shared by all
     *         thread blocks simultaneously resident on a multiprocessor;
     *       </li>
     *       <li>warpSize
     *         is the warp size in threads;
     *       </li>
     *       <li>memPitch is the maximum pitch in
     *         bytes allowed by the memory copy functions that involve memory regions
     *         allocated through cudaMallocPitch();
     *       </li>
     *       <li>maxThreadsPerBlock is the
     *         maximum number of threads per block;
     *       </li>
     *       <li>maxThreadsDim[3] contains
     *         the maximum size of each dimension of a block;
     *       </li>
     *       <li>maxGridSize[3]
     *         contains the maximum size of each dimension of a grid;
     *       </li>
     *       <li>clockRate
     *         is the clock frequency in kilohertz;
     *       </li>
     *       <li>totalConstMem is the total
     *         amount of constant memory available on the device in bytes;
     *       </li>
     *       <li>major,
     *         minor are the major and minor revision numbers defining the device's
     *         compute capability;
     *       </li>
     *       <li>textureAlignment is the alignment
     *         requirement; texture base addresses that are aligned to textureAlignment
     *         bytes do not need an offset applied to texture fetches;
     *       </li>
     *       <li>deviceOverlap
     *         is 1 if the device can concurrently copy memory between host and device
     *         while executing a kernel, or 0 if not. Deprecated, use instead
     *         asyncEngineCount.
     *       </li>
     *       <li>multiProcessorCount is the number of
     *         multiprocessors on the device;
     *       </li>
     *       <li>kernelExecTimeoutEnabled is 1
     *         if there is a run time limit for kernels executed on the device, or 0
     *         if not.
     *       </li>
     *       <li>integrated is 1 if the device is an integrated
     *         (motherboard) GPU and 0 if it is a discrete (card)
     *         component.
     *       </li>
     *       <li>canMapHostMemory is 1 if the device can map host
     *         memory into the CUDA address space for use with
     *         cudaHostAlloc()/cudaHostGetDevicePointer(), or 0 if not;
     *       </li>
     *       <li>
     *         computeMode
     *         is the compute mode that the device is currently in. Available modes
     *         are as follows:
     *         <ul>
     *           <li>cudaComputeModeDefault: Default mode - Device is not restricted
     *             and multiple threads can use cudaSetDevice() with this
     *             device.
     *           </li>
     *           <li>cudaComputeModeExclusive: Compute-exclusive mode - Only
     *             one thread will be able to use cudaSetDevice() with this
     *             device.
     *           </li>
     *           <li>cudaComputeModeProhibited: Compute-prohibited mode -
     *             No threads can use cudaSetDevice() with this device. Any errors from
     *             calling cudaSetDevice() with an exclusive (and occupied) or prohibited
     *             device will only show up after a non-device management runtime function
     *             is called. At that time, cudaErrorNoDevice will be returned.
     *           </li>
     *         </ul>
     *       </li>
     *       <li>maxTexture1D is the maximum 1D texture size.</li>
     *       <li>maxTexture2D[2]
     *         contains the maximum 2D texture dimensions.
     *       </li>
     *       <li>maxTexture3D[3]
     *         contains the maximum 3D texture dimensions.
     *       </li>
     *       <li>maxTexture1DLayered[2]
     *         contains the maximum 1D layered texture
     *         dimensions.
     *       </li>
     *       <li>maxTexture2DLayered[3] contains the maximum 2D
     *         layered texture dimensions.
     *       </li>
     *       <li>surfaceAlignment specifies the
     *         alignment requirements for surfaces.
     *       </li>
     *       <li>concurrentKernels is 1 if
     *         the device supports executing multiple kernels within the same context
     *         simultaneously, or 0 if not. It is not guaranteed that multiple kernels
     *         will be resident on the device concurrently so this feature should not
     *         be relied upon for correctness;
     *       </li>
     *       <li>ECCEnabled is 1 if the device
     *         has ECC support turned on, or 0 if not.
     *       </li>
     *       <li>pciBusID is the PCI
     *         bus identifier of the device.
     *       </li>
     *       <li>pciDeviceID is the PCI device
     *         (sometimes called slot) identifier of the device.
     *       </li>
     *       <li>tccDriver is
     *         1 if the device is using a TCC driver or 0 if not.
     *       </li>
     *       <li>asyncEngineCount
     *         is 1 when the device can concurrently copy memory between host and
     *         device while executing a kernel. It is 2 when the device can concurrently
     *         copy memory between host and device in both directions and execute a
     *         kernel at the same time. It is 0 if neither of these is
     *         supported.
     *       </li>
     *       <li>unifiedAddressing is 1 if the device shares a
     *         unified address space with the host and 0 otherwise.
     *       </li>
     *       <li>memoryClockRate
     *         is the peak memory clock frequency in kilohertz.
     *       </li>
     *       <li>memoryBusWidth
     *         is the memory bus width in bits.
     *       </li>
     *       <li>l2CacheSize is L2 cache size
     *         in bytes.
     *       </li>
     *       <li>maxThreadsPerMultiProcessor is the number of maximum
     *         resident threads per multiprocessor.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevice
     *
     * @see JCuda#cudaGetDeviceCount
     * @see JCuda#cudaGetDevice
     * @see JCuda#cudaSetDevice
     * @see JCuda#cudaChooseDevice
     */
    public static int cudaGetDeviceProperties(cudaDeviceProp prop, int device)
    {
        return checkResult(cudaGetDevicePropertiesNative(prop, device));
    }
    private static native int cudaGetDevicePropertiesNative(cudaDeviceProp prop, int device);


    /**
     * Select compute-device which best matches criteria.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaChooseDevice           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>device</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaDeviceProp *&nbsp;</td>
     *         <td> <em>prop</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*device</code> the device which has properties that
     *       best match <code>*prop</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue
     *
     * @see JCuda#cudaGetDeviceCount
     * @see JCuda#cudaGetDevice
     * @see JCuda#cudaSetDevice
     * @see JCuda#cudaGetDeviceProperties
     */
    public static int cudaChooseDevice(int device[], cudaDeviceProp prop)
    {
        return checkResult(cudaChooseDeviceNative(device, prop));
    }
    private static native int cudaChooseDeviceNative(int device[], cudaDeviceProp prop);



    /**
     * Allocates logical 1D, 2D, or 3D memory objects on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMalloc3D           </td>
     *         <td>(</td>
     *         <td>struct cudaPitchedPtr *&nbsp;</td>
     *         <td> <em>pitchedDevPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>struct cudaExtent&nbsp;</td>
     *         <td> <em>extent</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates at least <code>width</code> * <code>height</code> *
     *       <code>depth</code> bytes of linear memory on the device and returns a
     *       cudaPitchedPtr in which <code>ptr</code> is a pointer to the allocated
     *       memory. The function may pad the allocation to ensure hardware alignment
     *       requirements are met. The pitch returned in the <code>pitch</code>
     *       field of <code>pitchedDevPtr</code> is the width in bytes of the
     *       allocation.
     *     <p>
     *       The returned cudaPitchedPtr contains additional fields <code>xsize</code>
     *       and <code>ysize</code>, the logical width and height of the allocation,
     *       which are equivalent to the <code>width</code> and <code>height</code>
     *       <code>extent</code> parameters provided by the programmer during
     *       allocation.
     *     <p>
     *       For allocations of 2D and 3D objects, it is highly recommended that
     *       programmers perform allocations using cudaMalloc3D() or cudaMallocPitch().
     *       Due to alignment restrictions in the hardware, this is especially true
     *       if the application will be performing memory copies involving 2D or 3D
     *       objects (whether linear memory or CUDA arrays).
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaMallocPitch
     * @see JCuda#cudaFree
     * @see JCuda#cudaMemcpy3D
     * @see JCuda#cudaMemset3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaMallocArray
     * @see JCuda#cudaFreeArray
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaFreeHost
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaMalloc3D(cudaPitchedPtr pitchDevPtr, cudaExtent extent)
    {
        return checkResult(cudaMalloc3DNative(pitchDevPtr, extent));
    }
    private static native int cudaMalloc3DNative(cudaPitchedPtr pitchDevPtr, cudaExtent extent);

    /**
     * Calls cudaMalloc3DArray wit the default value '0' as the last parameter
     * 
     * @see JCuda#cudaMalloc3DArray(cudaArray, cudaChannelFormatDesc, cudaExtent, int)
     */
    public static int cudaMalloc3DArray(cudaArray arrayPtr, cudaChannelFormatDesc desc, cudaExtent extent)    {
        return cudaMalloc3DArray(arrayPtr, desc, extent, 0);
    }

    /**
     * Allocate an array on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMalloc3DArray           </td>
     *         <td>(</td>
     *         <td>struct cudaArray **&nbsp;</td>
     *         <td> <em>array</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaChannelFormatDesc *&nbsp;</td>
     *         <td> <em>desc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>struct cudaExtent&nbsp;</td>
     *         <td> <em>extent</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates a CUDA array according to the cudaChannelFormatDesc structure
     *       <code>desc</code> and returns a handle to the new CUDA array in
     *       <code>*array</code>.
     *     <p>
     *       The cudaChannelFormatDesc is defined as:
     *     <div>
     *       <pre>    <span>struct
     * </span>cudaChannelFormatDesc {
     *         <span>int</span> x, y, z, w;
     *         <span>enum</span> cudaChannelFormatKind f;
     *     };
     * </pre>
     *     </div>
     *     where cudaChannelFormatKind is one of
     *     cudaChannelFormatKindSigned, cudaChannelFormatKindUnsigned, or
     *     cudaChannelFormatKindFloat.
     *     <p>
     *       cudaMalloc3DArray() can allocate the following:
     *     <p>
     *     <ul>
     *       <li>A 1D array is allocated if the height and depth extent are both
     *         zero. For 1D arrays, valid extent ranges are {(1, maxTexture1D), 0,
     *         0}.
     *       </li>
     *       <li>A 2D array is allocated if only the depth extent is zero.
     *         For 2D arrays, valid extent ranges are {(1, maxTexture2D[0]), (1,
     *         maxTexture2D[1]), 0}.
     *       </li>
     *       <li>A 3D array is allocated if all three
     *         extents are non-zero. For 3D arrays, valid extent ranges are {(1,
     *         maxTexture3D[0]), (1, maxTexture3D[1]), (1, maxTexture3D[2])}.
     *       </li>
     *       <li>A
     *         1D layered texture is allocated if only the height extent is zero and
     *         the cudaArrayLayered flag is set. The number of layers is determined
     *         by the depth extent. For 1D layered textures, valid extent ranges are
     *         {(1, maxTexture1DLayered[0]), 0, (1, maxTexture1DLayered[1])}.
     *       </li>
     *       <li>A
     *         2D layered texture is allocated if all three extents are non-zero and
     *         the cudaArrayLayered flag is set. The number of layers is determined
     *         by the depth extent. For 1D layered textures, valid extent ranges are
     *         {(1, maxTexture2DLayered[0]), (1, maxTexture2DLayered[1]), (1,
     *         maxTexture2DLayered[2])}.
     *       </li>
     *     </ul>
     *     <p>
     *       The <code>flags</code> parameter enables different options to be
     *       specified that affect the allocation, as follows.
     *     <ul>
     *       <li>cudaArrayDefault: This flag's value is defined to be 0 and provides
     *         default array allocation
     *       </li>
     *       <li>cudaArrayLayered: Allocates a layered
     *         texture, with the depth extent indicating the number of
     *         layers
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc
     * @see JCuda#cudaMallocPitch
     * @see JCuda#cudaFree
     * @see JCuda#cudaFreeArray
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaFreeHost
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaMalloc3DArray(cudaArray arrayPtr, cudaChannelFormatDesc desc, cudaExtent extent, int flags)
    {
        return checkResult(cudaMalloc3DArrayNative(arrayPtr, desc, extent, flags));
    }
    private static native int cudaMalloc3DArrayNative(cudaArray arrayPtr, cudaChannelFormatDesc desc, cudaExtent extent, int flags);


    /**
     * Initializes or sets device memory to a value.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemset3D           </td>
     *         <td>(</td>
     *         <td>struct cudaPitchedPtr&nbsp;</td>
     *         <td> <em>pitchedDevPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>value</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>struct cudaExtent&nbsp;</td>
     *         <td> <em>extent</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Initializes each element of a 3D array to the specified value
     *       <code>value</code>. The object to initialize is defined by
     *       <code>pitchedDevPtr</code>. The <code>pitch</code> field of
     *       <code>pitchedDevPtr</code> is the width in memory in bytes of the 3D
     *       array pointed to by <code>pitchedDevPtr</code>, including any padding
     *       added to the end of each row. The <code>xsize</code> field specifies
     *       the logical width of each row in bytes, while the <code>ysize</code>
     *       field specifies the height of each 2D slice in rows.
     *     <p>
     *       The extents of the initialized region are specified as a
     *       <code>width</code> in bytes, a <code>height</code> in rows, and a
     *       <code>depth</code> in slices.
     *     <p>
     *       Extents with <code>width</code> greater than or equal to the
     *       <code>xsize</code> of <code>pitchedDevPtr</code> may perform
     *       significantly faster than extents narrower than the <code>xsize</code>.
     *       Secondarily, extents with <code>height</code> equal to the
     *       <code>ysize</code> of <code>pitchedDevPtr</code> will perform faster
     *       than when the <code>height</code> is shorter than the
     *       <code>ysize</code>.
     *     <p>
     *       This function performs fastest when the <code>pitchedDevPtr</code> has
     *       been allocated by cudaMalloc3D().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer
     *
     *
     * @see JCuda#cudaMemset
     * @see JCuda#cudaMemset2D
     * @see JCuda#cudaMemsetAsync
     * @see JCuda#cudaMemset2DAsync
     * @see JCuda#cudaMemset3DAsync
     * @see JCuda#cudaMalloc3D
     */
    public static int cudaMemset3D(cudaPitchedPtr pitchDevPtr, int value, cudaExtent extent)
    {
        return checkResult(cudaMemset3DNative(pitchDevPtr, value, extent));
    }
    private static native int cudaMemset3DNative(cudaPitchedPtr pitchDevPtr, int value, cudaExtent extent);


    /**
     * Initializes or sets device memory to a value.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemsetAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>value</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Fills the first <code>count</code> bytes of the memory area pointed to
     *       by <code>devPtr</code> with the constant byte value
     *       <code>value</code>.
     *     <p>
     *       cudaMemsetAsync() is asynchronous with respect to the host, so the call
     *       may return before the memset is complete. The operation can optionally
     *       be associated to a stream by passing a non-zero <code>stream</code>
     *       argument. If <code>stream</code> is non-zero, the operation may overlap
     *       with operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer
     *
     *
     * @see JCuda#cudaMemset
     * @see JCuda#cudaMemset2D
     * @see JCuda#cudaMemset3D
     * @see JCuda#cudaMemset2DAsync
     * @see JCuda#cudaMemset3DAsync
     */
    public static int cudaMemsetAsync(Pointer devPtr, int value, long count, cudaStream_t stream)
    {
        return checkResult(cudaMemsetAsyncNative(devPtr, value, count, stream));
    }


    private static native int cudaMemsetAsyncNative(Pointer devPtr, int value, long count, cudaStream_t stream);


    /**
     * Initializes or sets device memory to a value.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemset2DAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>pitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>value</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets to the specified value <code>value</code> a matrix
     *       (<code>height</code> rows of <code>width</code> bytes each) pointed to
     *       by <code>dstPtr</code>. <code>pitch</code> is the width in bytes of
     *       the 2D array pointed to by <code>dstPtr</code>, including any padding
     *       added to the end of each row. This function performs fastest when the
     *       pitch is one that has been passed back by cudaMallocPitch().
     *     <p>
     *       cudaMemset2DAsync() is asynchronous with respect to the host, so the
     *       call may return before the memset is complete. The operation can
     *       optionally be associated to a stream by passing a non-zero
     *       <code>stream</code> argument. If <code>stream</code> is non-zero, the
     *       operation may overlap with operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer
     *
     *
     * @see JCuda#cudaMemset
     * @see JCuda#cudaMemset2D
     * @see JCuda#cudaMemset3D
     * @see JCuda#cudaMemsetAsync
     * @see JCuda#cudaMemset3DAsync
     */
    public static int cudaMemset2DAsync(Pointer devPtr, long pitch, int value, long width, long height, cudaStream_t stream)
    {
        return checkResult(cudaMemset2DAsyncNative(devPtr, pitch, value, width, height, stream));
    }
    private static native int cudaMemset2DAsyncNative(Pointer devPtr, long pitch, int value, long width, long height, cudaStream_t stream);


    /**
     * Initializes or sets device memory to a value.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemset3DAsync           </td>
     *         <td>(</td>
     *         <td>struct cudaPitchedPtr&nbsp;</td>
     *         <td> <em>pitchedDevPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>value</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>struct cudaExtent&nbsp;</td>
     *         <td> <em>extent</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Initializes each element of a 3D array to the specified value
     *       <code>value</code>. The object to initialize is defined by
     *       <code>pitchedDevPtr</code>. The <code>pitch</code> field of
     *       <code>pitchedDevPtr</code> is the width in memory in bytes of the 3D
     *       array pointed to by <code>pitchedDevPtr</code>, including any padding
     *       added to the end of each row. The <code>xsize</code> field specifies
     *       the logical width of each row in bytes, while the <code>ysize</code>
     *       field specifies the height of each 2D slice in rows.
     *     <p>
     *       The extents of the initialized region are specified as a
     *       <code>width</code> in bytes, a <code>height</code> in rows, and a
     *       <code>depth</code> in slices.
     *     <p>
     *       Extents with <code>width</code> greater than or equal to the
     *       <code>xsize</code> of <code>pitchedDevPtr</code> may perform
     *       significantly faster than extents narrower than the <code>xsize</code>.
     *       Secondarily, extents with <code>height</code> equal to the
     *       <code>ysize</code> of <code>pitchedDevPtr</code> will perform faster
     *       than when the <code>height</code> is shorter than the
     *       <code>ysize</code>.
     *     <p>
     *       This function performs fastest when the <code>pitchedDevPtr</code> has
     *       been allocated by cudaMalloc3D().
     *     <p>
     *       cudaMemset3DAsync() is asynchronous with respect to the host, so the
     *       call may return before the memset is complete. The operation can
     *       optionally be associated to a stream by passing a non-zero
     *       <code>stream</code> argument. If <code>stream</code> is non-zero, the
     *       operation may overlap with operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer
     *
     *
     * @see JCuda#cudaMemset
     * @see JCuda#cudaMemset2D
     * @see JCuda#cudaMemset3D
     * @see JCuda#cudaMemsetAsync
     * @see JCuda#cudaMemset2DAsync
     * @see JCuda#cudaMalloc3D
     */
    public static int cudaMemset3DAsync(cudaPitchedPtr pitchedDevPtr, int value, cudaExtent extent, cudaStream_t stream)
    {
        return checkResult(cudaMemset3DAsyncNative(pitchedDevPtr, value, extent, stream));
    }

    private static native int cudaMemset3DAsyncNative(cudaPitchedPtr pitchedDevPtr, int value, cudaExtent extent, cudaStream_t stream);

    /**
     * Copies data between 3D objects.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy3D           </td>
     *         <td>(</td>
     *         <td>const struct cudaMemcpy3DParms *&nbsp;</td>
     *         <td> <em>p</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <div>
     *       <pre><span>struct </span>cudaExtent {
     *   <span>size_t</span> width;
     *   <span>size_t</span> height;
     *   <span>size_t</span> depth;
     * };
     * <span>struct </span>cudaExtent make_cudaExtent(size_t w, size_t h,
     * size_t d);
     *
     * <span>struct </span>cudaPos {
     *   <span>size_t</span> x;
     *   <span>size_t</span> y;
     *   <span>size_t</span> z;
     * };
     * <span>struct </span>cudaPos make_cudaPos(size_t x, size_t y, size_t
     * z);
     *
     * <span>struct </span>cudaMemcpy3DParms {
     *   <span>struct </span>cudaArray     *srcArray;
     *   <span>struct </span>cudaPos        srcPos;
     *   <span>struct </span>cudaPitchedPtr srcPtr;
     *   <span>struct </span>cudaArray     *dstArray;
     *   <span>struct </span>cudaPos        dstPos;
     *   <span>struct </span>cudaPitchedPtr dstPtr;
     *   <span>struct </span>cudaExtent     extent;
     *   <span>enum</span> cudaMemcpyKind   kind;
     * };
     * </pre>
     *     </div>
     *     <p>
     *       cudaMemcpy3D() copies data betwen two 3D objects. The source and
     *       destination objects may be in either host memory, device memory, or a
     *       CUDA array. The source, destination, extent, and kind of copy performed
     *       is specified by the cudaMemcpy3DParms struct which should be initialized
     *       to zero before use:
     *     <div>
     *       <pre>cudaMemcpy3DParms myParms = {0};
     * </pre>
     *     </div>
     *     <p>
     *       The struct passed to cudaMemcpy3D() must specify one of
     *       <code>srcArray</code> or <code>srcPtr</code> and one of
     *       <code>dstArray</code> or <code>dstPtr</code>. Passing more than one
     *       non-zero source or destination will cause cudaMemcpy3D() to return an
     *       error.
     *     <p>
     *       The <code>srcPos</code> and <code>dstPos</code> fields are optional
     *       offsets into the source and destination objects and are defined in
     *       units of each object's elements. The element for a host or device
     *       pointer is assumed to be <b>unsigned char</b>. For CUDA arrays,
     *       positions must be in the range [0, 2048) for any dimension.
     *     <p>
     *       The <code>extent</code> field defines the dimensions of the transferred
     *       area in elements. If a CUDA array is participating in the copy, the
     *       extent is defined in terms of that array's elements. If no CUDA array
     *       is participating in the copy then the extents are defined in elements
     *       of <b>unsigned char</b>.
     *     <p>
     *       The <code>kind</code> field defines the direction of the copy. It must
     *       be one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice.
     *     <p>
     *       If the source and destination are both arrays, cudaMemcpy3D() will
     *       return an error if they do not have the same element size.
     *     <p>
     *       The source and destination object may not overlap. If overlapping
     *       source and destination objects are specified, undefined behavior will
     *       result.
     *     <p>
     *       The source object must lie entirely within the region defined by
     *       <code>srcPos</code> and <code>extent</code>. The destination object
     *       must lie entirely within the region defined by <code>dstPos</code> and
     *       <code>extent</code>.
     *     <p>
     *       cudaMemcpy3D() returns an error if the pitch of <code>srcPtr</code> or
     *       <code>dstPtr</code> exceeds the maximum allowed. The pitch of a
     *       cudaPitchedPtr allocated with cudaMalloc3D() will always be valid.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidPitchValue, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaMemset3D
     * @see JCuda#cudaMemcpy3DAsync
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy3D(cudaMemcpy3DParms p)
    {
        return checkResult(cudaMemcpy3DNative(p));
    }
    private static native int cudaMemcpy3DNative(cudaMemcpy3DParms p);


    /**
     * Copies memory between devices.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy3DPeer           </td>
     *         <td>(</td>
     *         <td>const struct cudaMemcpy3DPeerParms *&nbsp;</td>
     *         <td> <em>p</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 3D memory copy according to the parameters specified in
     *       <code>p</code>. See the definition of the cudaMemcpy3DPeerParms
     *       structure for documentation of its parameters.
     *     <p>
     *       Note that this function is synchronous with respect to the host only
     *       if the source or destination of the transfer is host memory. Note also
     *       that this copy is serialized with respect to all pending and future
     *       asynchronous work in to the current device, the copy's source device,
     *       and the copy's destination device (use cudaMemcpy3DPeerAsync to avoid
     *       this synchronization).
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevice
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpyPeer
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpyPeerAsync
     * @see JCuda#cudaMemcpy3DPeerAsync
     */
    public static int cudaMemcpy3DPeer(cudaMemcpy3DPeerParms p)
    {
        return checkResult(cudaMemcpy3DPeerNative(p));
    }
    private static native int cudaMemcpy3DPeerNative(cudaMemcpy3DPeerParms p);


    /**
     * Copies data between 3D objects.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy3DAsync           </td>
     *         <td>(</td>
     *         <td>const struct cudaMemcpy3DParms *&nbsp;</td>
     *         <td> <em>p</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <div>
     *       <pre><span>struct </span>cudaExtent {
     *   <span>size_t</span> width;
     *   <span>size_t</span> height;
     *   <span>size_t</span> depth;
     * };
     * <span>struct </span>cudaExtent make_cudaExtent(size_t w, size_t h,
     * size_t d);
     *
     * <span>struct </span>cudaPos {
     *   <span>size_t</span> x;
     *   <span>size_t</span> y;
     *   <span>size_t</span> z;
     * };
     * <span>struct </span>cudaPos make_cudaPos(size_t x, size_t y, size_t
     * z);
     *
     * <span>struct </span>cudaMemcpy3DParms {
     *   <span>struct </span>cudaArray     *srcArray;
     *   <span>struct </span>cudaPos        srcPos;
     *   <span>struct </span>cudaPitchedPtr srcPtr;
     *   <span>struct </span>cudaArray     *dstArray;
     *   <span>struct </span>cudaPos        dstPos;
     *   <span>struct </span>cudaPitchedPtr dstPtr;
     *   <span>struct </span>cudaExtent     extent;
     *   <span>enum</span> cudaMemcpyKind   kind;
     * };
     * </pre>
     *     </div>
     *     <p>
     *       cudaMemcpy3DAsync() copies data betwen two 3D objects. The source and
     *       destination objects may be in either host memory, device memory, or a
     *       CUDA array. The source, destination, extent, and kind of copy performed
     *       is specified by the cudaMemcpy3DParms struct which should be initialized
     *       to zero before use:
     *     <div>
     *       <pre>cudaMemcpy3DParms myParms = {0};
     * </pre>
     *     </div>
     *     <p>
     *       The struct passed to cudaMemcpy3DAsync() must specify one of
     *       <code>srcArray</code> or <code>srcPtr</code> and one of
     *       <code>dstArray</code> or <code>dstPtr</code>. Passing more than one
     *       non-zero source or destination will cause cudaMemcpy3DAsync() to return
     *       an error.
     *     <p>
     *       The <code>srcPos</code> and <code>dstPos</code> fields are optional
     *       offsets into the source and destination objects and are defined in
     *       units of each object's elements. The element for a host or device
     *       pointer is assumed to be <b>unsigned char</b>. For CUDA arrays,
     *       positions must be in the range [0, 2048) for any dimension.
     *     <p>
     *       The <code>extent</code> field defines the dimensions of the transferred
     *       area in elements. If a CUDA array is participating in the copy, the
     *       extent is defined in terms of that array's elements. If no CUDA array
     *       is participating in the copy then the extents are defined in elements
     *       of <b>unsigned char</b>.
     *     <p>
     *       The <code>kind</code> field defines the direction of the copy. It must
     *       be one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice.
     *     <p>
     *       If the source and destination are both arrays, cudaMemcpy3DAsync() will
     *       return an error if they do not have the same element size.
     *     <p>
     *       The source and destination object may not overlap. If overlapping
     *       source and destination objects are specified, undefined behavior will
     *       result.
     *     <p>
     *       The source object must lie entirely within the region defined by
     *       <code>srcPos</code> and <code>extent</code>. The destination object
     *       must lie entirely within the region defined by <code>dstPos</code> and
     *       <code>extent</code>.
     *     <p>
     *       cudaMemcpy3DAsync() returns an error if the pitch of <code>srcPtr</code>
     *       or <code>dstPtr</code> exceeds the maximum allowed. The pitch of a
     *       cudaPitchedPtr allocated with cudaMalloc3D() will always be valid.
     *     <p>
     *       cudaMemcpy3DAsync() is asynchronous with respect to the host, so the
     *       call may return before the copy is complete. It only works on
     *       page-locked host memory and returns an error if a pointer to pageable
     *       memory is passed as input. The copy can optionally be associated to a
     *       stream by passing a non-zero <code>stream</code> argument. If
     *       <code>kind</code> is cudaMemcpyHostToDevice or cudaMemcpyDeviceToHost
     *       and <code>stream</code> is non-zero, the copy may overlap with
     *       operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidPitchValue, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaMemset3D
     * @see JCuda#cudaMemcpy3D
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy3DAsync(cudaMemcpy3DParms p, cudaStream_t stream)
    {
        return checkResult(cudaMemcpy3DAsyncNative(p, stream));
    }
    private static native int cudaMemcpy3DAsyncNative(cudaMemcpy3DParms p, cudaStream_t stream);


    /**
     * Copies memory between devices asynchronously.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy3DPeerAsync           </td>
     *         <td>(</td>
     *         <td>const struct cudaMemcpy3DPeerParms *&nbsp;</td>
     *         <td> <em>p</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 3D memory copy according to the parameters specified in
     *       <code>p</code>. See the definition of the cudaMemcpy3DPeerParms
     *       structure for documentation of its parameters.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevice
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpyPeer
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpyPeerAsync
     * @see JCuda#cudaMemcpy3DPeerAsync
     */
    public static int cudaMemcpy3DPeerAsync(cudaMemcpy3DPeerParms p, cudaStream_t stream)
    {
        return checkResult(cudaMemcpy3DPeerAsyncNative(p, stream));
    }
    private static native int cudaMemcpy3DPeerAsyncNative(cudaMemcpy3DPeerParms p, cudaStream_t stream);



    /**
     * Allocates page-locked memory on the host.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaHostAlloc           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>pHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>size</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates <code>size</code> bytes of host memory that is page-locked
     *       and accessible to the device. The driver tracks the virtual memory
     *       ranges allocated with this function and automatically accelerates calls
     *       to functions such as cudaMemcpy(). Since the memory can be accessed
     *       directly by the device, it can be read or written with much higher
     *       bandwidth than pageable memory obtained with functions such as malloc().
     *       Allocating excessive amounts of pinned memory may degrade system
     *       performance, since it reduces the amount of memory available to the
     *       system for paging. As a result, this function is best used sparingly
     *       to allocate staging areas for data exchange between host and
     *       device.
     *     <p>
     *       The <code>flags</code> parameter enables different options to be
     *       specified that affect the allocation, as follows.
     *     <ul>
     *       <li>cudaHostAllocDefault: This flag's value is defined to be 0 and
     *         causes cudaHostAlloc() to emulate cudaMallocHost().
     *       </li>
     *       <li>cudaHostAllocPortable:
     *         The memory returned by this call will be considered as pinned memory
     *         by all CUDA contexts, not just the one that performed the
     *         allocation.
     *       </li>
     *       <li>cudaHostAllocMapped: Maps the allocation into the
     *         CUDA address space. The device pointer to the memory may be obtained
     *         by calling cudaHostGetDevicePointer().
     *       </li>
     *       <li>cudaHostAllocWriteCombined:
     *         Allocates the memory as write-combined (WC). WC memory can be
     *         transferred across the PCI Express bus more quickly on some system
     *         configurations, but cannot be read efficiently by most CPUs. WC memory
     *         is a good option for buffers that will be written by the CPU and read
     *         by the device via mapped pinned memory or host-&gt;device
     *         transfers.
     *       </li>
     *     </ul>
     *     <p>
     *       All of these flags are orthogonal to one another: a developer may
     *       allocate memory that is portable, mapped and/or write-combined with no
     *       restrictions.
     *     <p>
     *       cudaSetDeviceFlags() must have been called with the cudaDeviceMapHost
     *       flag in order for the cudaHostAllocMapped flag to have any effect.
     *     <p>
     *       The cudaHostAllocMapped flag may be specified on CUDA contexts for
     *       devices that do not support mapped pinned memory. The failure is
     *       deferred to cudaHostGetDevicePointer() because the memory may be mapped
     *       into other CUDA contexts via the cudaHostAllocPortable flag.
     *     <p>
     *       Memory allocated by this function must be freed with
     *       cudaFreeHost().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaSetDeviceFlags
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaFreeHost
     */
    public static int cudaHostAlloc(Pointer ptr, long size, int flags)
    {
        return checkResult(cudaHostAllocNative(ptr, size, flags));
    }
    private static native int cudaHostAllocNative(Pointer ptr, long size, int flags);



    /**
     * Registers an existing host memory range for use by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaHostRegister           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>ptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>size</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Page-locks the memory range specified by <code>ptr</code> and
     *       <code>size</code> and maps it for the device(s) as specified by
     *       <code>flags</code>. This memory range also is added to the same tracking
     *       mechanism as cudaHostAlloc() to automatically accelerate calls to
     *       functions such as cudaMemcpy(). Since the memory can be accessed
     *       directly by the device, it can be read or written with much higher
     *       bandwidth than pageable memory that has not been registered. Page-locking
     *       excessive amounts of memory may degrade system performance, since it
     *       reduces the amount of memory available to the system for paging. As a
     *       result, this function is best used sparingly to register staging areas
     *       for data exchange between host and device.
     *     <p>
     *       The <code>flags</code> parameter enables different options to be
     *       specified that affect the allocation, as follows.
     *     <p>
     *     <ul>
     *       <li>cudaHostRegisterPortable: The memory returned by this call will be
     *         considered as pinned memory by all CUDA contexts, not just the one that
     *         performed the allocation.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>cudaHostRegisterMapped: Maps the allocation into the CUDA address
     *         space. The device pointer to the memory may be obtained by calling
     *         cuMemHostGetDevicePointer(). This feature is available only on GPUs
     *         with compute capability greater than or equal to 1.1.
     *       </li>
     *     </ul>
     *     <p>
     *       All of these flags are orthogonal to one another: a developer may
     *       page-lock memory that is portable or mapped with no restrictions.
     *     <p>
     *       The CUDA context must have been created with the cudaMapHost flag in
     *       order for the cudaHostRegisterMapped flag to have any effect.
     *     <p>
     *       The cudaHostRegisterMapped flag may be specified on CUDA contexts for
     *       devices that do not support mapped pinned memory. The failure is
     *       deferred to cudaHostGetDevicePointer() because the memory may be mapped
     *       into other CUDA contexts via the cudaHostRegisterPortable flag.
     *     <p>
     *       The pointer <code>ptr</code> and size <code>size</code> must be aligned
     *       to the host page size (4 KB).
     *     <p>
     *       The memory page-locked by this function must be unregistered with
     *       cudaHostUnregister().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaHostUnregister
     * @see JCuda#cudaHostGetDevicePointer
     */
    public static int cudaHostRegister(Pointer ptr, long size, int flags)
    {
        return checkResult(cudaHostRegisterNative(ptr, size, flags));
    }
    private static native int cudaHostRegisterNative(Pointer ptr, long size, int flags);

    /**
     * Unregisters a memory range that was registered with
     * cuMemHostRegister().
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaHostUnregister           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>ptr</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Unmaps the memory range whose base address is specified by
     *       <code>ptr</code>, and makes it pageable again.
     *     <p>
     *       The base address must be the same one specified to
     *       cudaHostRegister().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue
     *
     * @see JCuda#cudaHostUnregister
     */
    public static int cudaHostUnregister(Pointer ptr)
    {
        return checkResult(cudaHostUnregisterNative(ptr));
    }
    private static native int cudaHostUnregisterNative(Pointer ptr);


    /**
     * Passes back device pointer of mapped host memory allocated by
     * cudaHostAlloc() or registered by cudaHostRegister().
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaHostGetDevicePointer           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>pDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>pHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Passes back the device pointer corresponding to the mapped, pinned host
     *       buffer allocated by cudaHostAlloc() or registered by
     *       cudaHostRegister().
     *     <p>
     *       cudaHostGetDevicePointer() will fail if the cudaDeviceMapHost flag was
     *       not specified before deferred context creation occurred, or if called
     *       on a device that does not support mapped, pinned memory.
     *     <p>
     *       <code>flags</code> provides for future releases. For now, it must be
     *       set to 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaSetDeviceFlags
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaHostGetDevicePointer(Pointer pDevice, Pointer pHost, int flags)
    {
        return checkResult(cudaHostGetDevicePointerNative(pDevice, pHost, flags));
    }
    private static native int cudaHostGetDevicePointerNative(Pointer pDevice, Pointer pHost, int flags);






    /**
     * Allocate memory on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMalloc           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>size</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates <code>size</code> bytes of linear memory on the device and
     *       returns in <code>*devPtr</code> a pointer to the allocated memory. The
     *       allocated memory is suitably aligned for any kind of variable. The
     *       memory is not cleared. cudaMalloc() returns cudaErrorMemoryAllocation
     *       in case of failure.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaMallocPitch
     * @see JCuda#cudaFree
     * @see JCuda#cudaMallocArray
     * @see JCuda#cudaFreeArray
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaFreeHost
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaMalloc(Pointer devPtr, long size)
    {
        return checkResult(cudaMallocNative(devPtr, size));
    }
    private static native int cudaMallocNative(Pointer devPtr, long size);


    /**
     * Allocates page-locked memory on the host.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMallocHost           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>ptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>size</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates <code>size</code> bytes of host memory that is page-locked
     *       and accessible to the device. The driver tracks the virtual memory
     *       ranges allocated with this function and automatically accelerates calls
     *       to functions such as cudaMemcpy*(). Since the memory can be accessed
     *       directly by the device, it can be read or written with much higher
     *       bandwidth than pageable memory obtained with functions such as malloc().
     *       Allocating excessive amounts of memory with cudaMallocHost() may
     *       degrade system performance, since it reduces the amount of memory
     *       available to the system for paging. As a result, this function is best
     *       used sparingly to allocate staging areas for data exchange between host
     *       and device.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaMalloc
     * @see JCuda#cudaMallocPitch
     * @see JCuda#cudaMallocArray
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaHostAlloc
     * @see JCuda#cudaFree
     * @see JCuda#cudaFreeArray
     * @see JCuda#cudaFreeHost
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaMallocHost(Pointer ptr, long size)
    {
        return checkResult(cudaMallocHostNative(ptr, size));
    }
    private static native int cudaMallocHostNative(Pointer ptr, long size);


    /**
     * Allocates pitched memory on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMallocPitch           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>pitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates at least <code>width</code> (in bytes) * <code>height</code>
     *       bytes of linear memory on the device and returns in <code>*devPtr</code>
     *       a pointer to the allocated memory. The function may pad the allocation
     *       to ensure that corresponding pointers in any given row will continue
     *       to meet the alignment requirements for coalescing as the address is
     *       updated from row to row. The pitch returned in <code>*pitch</code> by
     *       cudaMallocPitch() is the width in bytes of the allocation. The intended
     *       usage of <code>pitch</code> is as a separate parameter of the
     *       allocation, used to compute addresses within the 2D array. Given the
     *       row and column of an array element of type <code>T</code>, the address
     *       is computed as:
     *     <div>
     *       <pre>    T* pElement = (T*)((<span>char</span>*)BaseAddress + Row * pitch) + Column;
     * </pre>
     *     </div>
     *     <p>
     *       For allocations of 2D arrays, it is recommended that programmers
     *       consider performing pitch allocations using cudaMallocPitch(). Due to
     *       pitch alignment restrictions in the hardware, this is especially true
     *       if the application will be performing 2D memory copies between different
     *       regions of device memory (whether linear memory or CUDA arrays).
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaMalloc
     * @see JCuda#cudaFree
     * @see JCuda#cudaMallocArray
     * @see JCuda#cudaFreeArray
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaFreeHost
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaMallocPitch(Pointer devPtr, long pitch[], long width, long height)
    {
        return checkResult(cudaMallocPitchNative(devPtr, pitch, width, height));
    }
    private static native int cudaMallocPitchNative(Pointer devPtr, long pitch[], long width, long height);


    /**
     * Calls cudaMallocArray wit the default value '0' as the last parameter
     * 
     * @see JCuda#cudaMallocArray(cudaArray, cudaChannelFormatDesc, long, long, int)
     */
    public static int cudaMallocArray(cudaArray array, cudaChannelFormatDesc desc, long width, long height)
    {
        return cudaMallocArray(array, desc, width, height, 0);
    }

    /**
     * Allocate an array on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMallocArray           </td>
     *         <td>(</td>
     *         <td>struct cudaArray **&nbsp;</td>
     *         <td> <em>array</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaChannelFormatDesc *&nbsp;</td>
     *         <td> <em>desc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em> = <code>0</code>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates a CUDA array according to the cudaChannelFormatDesc structure
     *       <code>desc</code> and returns a handle to the new CUDA array in
     *       <code>*array</code>.
     *     <p>
     *       The cudaChannelFormatDesc is defined as:
     *     <div>
     *       <pre>    <span>struct
     * </span>cudaChannelFormatDesc {
     *         <span>int</span> x, y, z, w;
     *     <span>enum</span> cudaChannelFormatKind f;
     *     };
     * </pre>
     *     </div>
     *     where cudaChannelFormatKind is one of
     *     cudaChannelFormatKindSigned, cudaChannelFormatKindUnsigned, or
     *     cudaChannelFormatKindFloat.
     *     <p>
     *       The <code>flags</code> parameter enables different options to be
     *       specified that affect the allocation, as follows.
     *     <ul>
     *       <li>cudaArrayDefault: This flag's value is defined to be 0 and provides
     *         default array allocation
     *       </li>
     *       <li>cudaArraySurfaceLoadStore: Allocates
     *         an array that can be read from or written to using a surface
     *         reference
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaMalloc
     * @see JCuda#cudaMallocPitch
     * @see JCuda#cudaFree
     * @see JCuda#cudaFreeArray
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaFreeHost
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaMallocArray(cudaArray array, cudaChannelFormatDesc desc, long width, long height, int flags)
    {
        return checkResult(cudaMallocArrayNative(array, desc, width, height, flags));
    }
    private static native int cudaMallocArrayNative(cudaArray array, cudaChannelFormatDesc desc, long width, long height, int flags);


    /**
     * Frees memory on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaFree           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>devPtr</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Frees the memory space pointed to by <code>devPtr</code>, which must
     *       have been returned by a previous call to cudaMalloc() or
     *       cudaMallocPitch(). Otherwise, or if cudaFree(<code>devPtr</code>) has
     *       already been called before, an error is returned. If <code>devPtr</code>
     *       is 0, no operation is performed. cudaFree() returns
     *       cudaErrorInvalidDevicePointer in case of failure.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevicePointer,
     * cudaErrorInitializationError
     *
     * @see JCuda#cudaMalloc
     * @see JCuda#cudaMallocPitch
     * @see JCuda#cudaMallocArray
     * @see JCuda#cudaFreeArray
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaFreeHost
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaFree(Pointer devPtr)
    {
        return checkResult(cudaFreeNative(devPtr));
    }
    private static native int cudaFreeNative(Pointer devPtr);


    /**
     * Frees page-locked memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaFreeHost           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>ptr</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Frees the memory space pointed to by <code>hostPtr</code>, which must
     *       have been returned by a previous call to cudaMallocHost() or
     *       cudaHostAlloc().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError
     *
     * @see JCuda#cudaMalloc
     * @see JCuda#cudaMallocPitch
     * @see JCuda#cudaFree
     * @see JCuda#cudaMallocArray
     * @see JCuda#cudaFreeArray
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaMalloc3D
     * @see JCuda#cudaMalloc3DArray
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaFreeHost(Pointer ptr)
    {
        return checkResult(cudaFreeHostNative(ptr));
    }
    private static native int cudaFreeHostNative(Pointer ptr);


    /**
     * Frees an array on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaFreeArray           </td>
     *         <td>(</td>
     *         <td>struct cudaArray *&nbsp;</td>
     *         <td> <em>array</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Frees the CUDA array <code>array</code>, which must have been * returned
     *       by a previous call to cudaMallocArray(). If cudaFreeArray(<code>array</code>)
     *       has already been called before, cudaErrorInvalidValue is returned. If
     *       <code>devPtr</code> is 0, no operation is performed.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInitializationError
     *
     *
     * @see JCuda#cudaMalloc
     * @see JCuda#cudaMallocPitch
     * @see JCuda#cudaFree
     * @see JCuda#cudaMallocArray
     * @see JCuda#cudaMallocHost
     * @see JCuda#cudaFreeHost
     * @see JCuda#cudaHostAlloc
     */
    public static int cudaFreeArray(cudaArray array)
    {
        return checkResult(cudaFreeArrayNative(array));
    }
    private static native int cudaFreeArrayNative(cudaArray array);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the memory area pointed to by
     *       <code>src</code> to the memory area pointed to by <code>dst</code>,
     *       where <code>kind</code> is one of cudaMemcpyHostToHost,
     *       cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice,
     *       and specifies the direction of the copy. The memory areas may not
     *       overlap. Calling cudaMemcpy() with <code>dst</code> and <code>src</code>
     *       pointers that do not match the direction of the copy results in an
     *       undefined behavior.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy(Pointer dst, Pointer src, long count, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpyNative(dst, src, count, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpyNative(Pointer dst, Pointer src, long count, int cudaMemcpyKind_kind);


    /**
     * Copies memory between two devices.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyPeer           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies memory from one device to memory on another device.
     *       <code>dst</code> is the base device pointer of the destination memory
     *       and <code>dstDevice</code> is the destination device. <code>src</code>
     *       is the base device pointer of the source memory and <code>srcDevice</code>
     *       is the source device. <code>count</code> specifies the number of bytes
     *       to copy.
     *     <p>
     *       Note that this function is asynchronous with respect to the host, but
     *       serialized with respect all pending and future asynchronous work in to
     *       the current device, <code>srcDevice</code>, and <code>dstDevice</code>
     *       (use cudaMemcpyPeerAsync to avoid this synchronization).
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevice
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy3DPeer
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpyPeerAsync
     * @see JCuda#cudaMemcpy3DPeerAsync
     */
    public static int cudaMemcpyPeer(Pointer dst, int dstDevice, Pointer src, int srcDevice, long count)
    {
        return checkResult(cudaMemcpyPeerNative(dst, dstDevice, src, srcDevice, count));
    }
    private static native int cudaMemcpyPeerNative(Pointer dst, int dstDevice, Pointer src, int srcDevice, long count);



    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyToArray           </td>
     *         <td>(</td>
     *         <td>struct cudaArray *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the memory area pointed to by
     *       <code>src</code> to the CUDA array <code>dst</code> starting at the
     *       upper left corner (<code>wOffset</code>, <code>hOffset</code>), where
     *       <code>kind</code> is one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice, and specifies the
     *       direction of the copy.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyToArray(cudaArray dst, long wOffset, long hOffset, Pointer src, long count, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpyToArrayNative(dst, wOffset, hOffset, src, count, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpyToArrayNative(cudaArray dst, long wOffset, long hOffset, Pointer src, long count, int cudaMemcpyKind_kind);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyFromArray           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the CUDA array <code>src</code>
     *       starting at the upper left corner (<code>wOffset</code>, hOffset) to
     *       the memory area pointed to by <code>dst</code>, where <code>kind</code>
     *       is one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice, and specifies the
     *       direction of the copy.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyFromArray(Pointer dst, cudaArray src, long wOffset, long hOffset, long count, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpyFromArrayNative(dst, src, wOffset, hOffset, count, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpyFromArrayNative(Pointer dst, cudaArray src, long wOffset, long hOffset, long count, int cudaMemcpyKind_kind);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyArrayToArray           </td>
     *         <td>(</td>
     *         <td>struct cudaArray *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffsetDst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffsetDst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffsetSrc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffsetSrc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em> =
     *           <code>cudaMemcpyDeviceToDevice</code>
     *         </td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the CUDA array <code>src</code>
     *       starting at the upper left corner (<code>wOffsetSrc</code>,
     *       <code>hOffsetSrc</code>) to the CUDA array <code>dst</code> starting
     *       at the upper left corner (<code>wOffsetDst</code>, <code>hOffsetDst</code>)
     *       where <code>kind</code> is one of cudaMemcpyHostToHost,
     *       cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice,
     *       and specifies the direction of the copy.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidMemcpyDirection
     *
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyArrayToArray(cudaArray dst, long wOffsetDst, long hOffsetDst, cudaArray src, long wOffsetSrc, long hOffsetSrc, long count, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpyArrayToArrayNative(dst, wOffsetDst, hOffsetDst, src, wOffsetSrc, hOffsetSrc, count, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpyArrayToArrayNative(cudaArray dst, long wOffsetDst, long hOffsetDst, cudaArray src, long wOffsetSrc, long hOffsetSrc, long count, int cudaMemcpyKind_kind);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy2D           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dpitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>spitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies a matrix (<code>height</code> rows of <code>width</code> bytes
     *       each) from the memory area pointed to by <code>src</code> to the memory
     *       area pointed to by <code>dst</code>, where <code>kind</code> is one of
     *       cudaMemcpyHostToHost, cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost,
     *       or cudaMemcpyDeviceToDevice, and specifies the direction of the copy.
     *       <code>dpitch</code> and <code>spitch</code> are the widths in memory
     *       in bytes of the 2D arrays pointed to by <code>dst</code> and
     *       <code>src</code>, including any padding added to the end of each row.
     *       The memory areas may not overlap. <code>width</code> must not exceed
     *       either <code>dpitch</code> or <code>spitch</code>. Calling cudaMemcpy2D()
     *       with <code>dst</code> and <code>src</code> pointers that do not match
     *       the direction of the copy results in an undefined behavior.
     *       cudaMemcpy2D() returns an error if <code>dpitch</code> or
     *       <code>spitch</code> exceeds the maximum allowed.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidPitchValue,
     * cudaErrorInvalidDevicePointer, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy2D(Pointer dst, long dpitch, Pointer src, long spitch, long width, long height, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpy2DNative(dst, dpitch, src, spitch, width, height, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpy2DNative(Pointer dst, long dpitch, Pointer src, long spitch, long width, long height, int cudaMemcpyKind_kind);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy2DToArray           </td>
     *         <td>(</td>
     *         <td>struct cudaArray *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>spitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies a matrix (<code>height</code> rows of <code>width</code> bytes
     *       each) from the memory area pointed to by <code>src</code> to the CUDA
     *       array <code>dst</code> starting at the upper left corner
     *       (<code>wOffset</code>, <code>hOffset</code>) where <code>kind</code>
     *       is one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice, and specifies the
     *       direction of the copy. <code>spitch</code> is the width in memory in
     *       bytes of the 2D array pointed to by <code>src</code>, including any
     *       padding added to the end of each row. <code>wOffset</code> +
     *       <code>width</code> must not exceed the width of the CUDA array
     *       <code>dst</code>. <code>width</code> must not exceed <code>spitch</code>.
     *       cudaMemcpy2DToArray() returns an error if <code>spitch</code> exceeds
     *       the maximum allowed.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidPitchValue, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy2DToArray(cudaArray dst, long wOffset, long hOffset, Pointer src, long spitch, long width, long height, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpy2DToArrayNative(dst, wOffset, hOffset, src, spitch, width, height, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpy2DToArrayNative(cudaArray dst, long wOffset, long hOffset, Pointer src, long spitch, long width, long height, int cudaMemcpyKind_kind);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy2DFromArray           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dpitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies a matrix (<code>height</code> rows of <code>width</code> bytes
     *       each) from the CUDA array <code>srcArray</code> starting at the upper
     *       left corner (<code>wOffset</code>, <code>hOffset</code>) to the memory
     *       area pointed to by <code>dst</code>, where <code>kind</code> is one of
     *       cudaMemcpyHostToHost, cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost,
     *       or cudaMemcpyDeviceToDevice, and specifies the direction of the copy.
     *       <code>dpitch</code> is the width in memory in bytes of the 2D array
     *       pointed to by <code>dst</code>, including any padding added to the end
     *       of each row. <code>wOffset</code> + <code>width</code> must not exceed
     *       the width of the CUDA array <code>src</code>. <code>width</code> must
     *       not exceed <code>dpitch</code>. cudaMemcpy2DFromArray() returns an
     *       error if <code>dpitch</code> exceeds the maximum allowed.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidPitchValue, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy2DFromArray(Pointer dst, long dpitch, cudaArray src, long wOffset, long hOffset, long width, long height, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpy2DFromArrayNative(dst, dpitch, src, wOffset, hOffset, width, height, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpy2DFromArrayNative(Pointer dst, long dpitch, cudaArray src, long wOffset, long hOffset, long width, long height, int cudaMemcpyKind_kind);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy2DArrayToArray           </td>
     *         <td>(</td>
     *         <td>struct cudaArray *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffsetDst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffsetDst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffsetSrc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffsetSrc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em> =
     *           <code>cudaMemcpyDeviceToDevice</code>
     *         </td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies a matrix (<code>height</code> rows of <code>width</code> bytes
     *       each) from the CUDA array <code>srcArray</code> starting at the upper
     *       left corner (<code>wOffsetSrc</code>, <code>hOffsetSrc</code>) to the
     *       CUDA array <code>dst</code> starting at the upper left corner
     *       (<code>wOffsetDst</code>, <code>hOffsetDst</code>), where
     *       <code>kind</code> is one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice, and specifies the
     *       direction of the copy. <code>wOffsetDst</code> + <code>width</code>
     *       must not exceed the width of the CUDA array <code>dst</code>.
     *       <code>wOffsetSrc</code> + <code>width</code> must not exceed the width
     *       of the CUDA array <code>src</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidMemcpyDirection
     *
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy2DArrayToArray(cudaArray dst, long wOffsetDst, long hOffsetDst, cudaArray src, long wOffsetSrc, long hOffsetSrc, long width, long height, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpy2DArrayToArrayNative(dst, wOffsetDst, hOffsetDst, src, wOffsetSrc, hOffsetSrc, width, height, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpy2DArrayToArrayNative(cudaArray dst, long wOffsetDst, long hOffsetDst, cudaArray src, long wOffsetSrc, long hOffsetSrc, long width, long height, int cudaMemcpyKind_kind);


    /**
     * Copies data to the given symbol on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyToSymbol           </td>
     *         <td>(</td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>symbol</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>offset</em> = <code>0</code>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em> =
     *           <code>cudaMemcpyHostToDevice</code>
     *         </td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the memory area pointed to by
     *       <code>src</code> to the memory area pointed to by <code>offset</code>
     *       bytes from the start of symbol <code>symbol</code>. The memory areas
     *       may not overlap. <code>symbol</code> can either be a variable that
     *       resides in global or constant memory space, or it can be a character
     *       string, naming a variable that resides in global or constant memory
     *       space. <code>kind</code> can be either cudaMemcpyHostToDevice or
     *       cudaMemcpyDeviceToDevice.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidSymbol,
     * cudaErrorInvalidDevicePointer, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyToSymbol(String symbol, Pointer src, long count, long offset, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpyToSymbolNative(symbol, src, count, offset, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpyToSymbolNative(String symbol, Pointer src, long count, long offset, int cudaMemcpyKind_kind);

    /**
     * Copies data from the given symbol on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyFromSymbol           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>symbol</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>offset</em> = <code>0</code>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em> =
     *           <code>cudaMemcpyDeviceToHost</code>
     *         </td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the memory area pointed to by
     *       <code>offset</code> bytes from the start of symbol <code>symbol</code>
     *       to the memory area pointed to by <code>dst</code>. The memory areas
     *       may not overlap. <code>symbol</code> can either be a variable that
     *       resides in global or constant memory space, or it can be a character
     *       string, naming a variable that resides in global or constant memory
     *       space. <code>kind</code> can be either cudaMemcpyDeviceToHost or
     *       cudaMemcpyDeviceToDevice.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidSymbol,
     * cudaErrorInvalidDevicePointer, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyFromSymbol(Pointer dst, String symbol, long count, long offset, int cudaMemcpyKind_kind)
    {
        return checkResult(cudaMemcpyFromSymbolNative(dst, symbol, count, offset, cudaMemcpyKind_kind));
    }
    private static native int cudaMemcpyFromSymbolNative(Pointer dst, String symbol, long count, long offset, int cudaMemcpyKind_kind);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the memory area pointed to by
     *       <code>src</code> to the memory area pointed to by <code>dst</code>,
     *       where <code>kind</code> is one of cudaMemcpyHostToHost,
     *       cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice,
     *       and specifies the direction of the copy. The memory areas may not
     *       overlap. Calling cudaMemcpyAsync() with <code>dst</code> and
     *       <code>src</code> pointers that do not match the direction of the copy
     *       results in an undefined behavior.
     *     <p>
     *       cudaMemcpyAsync() is asynchronous with respect to the host, so the call
     *       may return before the copy is complete. It only works on page-locked
     *       host memory and returns an error if a pointer to pageable memory is
     *       passed as input. The copy can optionally be associated to a stream by
     *       passing a non-zero <code>stream</code> argument. If <code>kind</code>
     *       is cudaMemcpyHostToDevice or cudaMemcpyDeviceToHost and the
     *       <code>stream</code> is non-zero, the copy may overlap with operations
     *       in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyAsync(Pointer dst, Pointer src, long count, int cudaMemcpyKind_kind, cudaStream_t stream)
    {
        return checkResult(cudaMemcpyAsyncNative(dst, src, count, cudaMemcpyKind_kind, stream));
    }
    private static native int cudaMemcpyAsyncNative(Pointer dst, Pointer src, long count, int cudaMemcpyKind_kind, cudaStream_t stream);

    /**
     * Copies memory between two devices asynchronously.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyPeerAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies memory from one device to memory on another device.
     *       <code>dst</code> is the base device pointer of the destination memory
     *       and <code>dstDevice</code> is the destination device. <code>src</code>
     *       is the base device pointer of the source memory and <code>srcDevice</code>
     *       is the source device. <code>count</code> specifies the number of bytes
     *       to copy.
     *     <p>
     *       Note that this function is asynchronous with respect to the host and
     *       all work in other streams and other devices.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevice
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpyPeer
     * @see JCuda#cudaMemcpy3DPeer
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy3DPeerAsync
     */
    public static int cudaMemcpyPeerAsync(Pointer dst, int dstDevice, Pointer src, int srcDevice, long count, cudaStream_t stream)
    {
        return checkResult(cudaMemcpyPeerAsyncNative(dst, dstDevice, src, srcDevice, count, stream));
    }
    private static native int cudaMemcpyPeerAsyncNative(Pointer dst, int dstDevice, Pointer src, int srcDevice, long count, cudaStream_t stream);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyToArrayAsync           </td>
     *         <td>(</td>
     *         <td>struct cudaArray *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the memory area pointed to by
     *       <code>src</code> to the CUDA array <code>dst</code> starting at the
     *       upper left corner (<code>wOffset</code>, <code>hOffset</code>), where
     *       <code>kind</code> is one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice, and specifies the
     *       direction of the copy.
     *     <p>
     *       cudaMemcpyToArrayAsync() is asynchronous with respect to the host, so
     *       the call may return before the copy is complete. It only works on
     *       page-locked host memory and returns an error if a pointer to pageable
     *       memory is passed as input. The copy can optionally be associated to a
     *       stream by passing a non-zero <code>stream</code> argument. If
     *       <code>kind</code> is cudaMemcpyHostToDevice or cudaMemcpyDeviceToHost
     *       and <code>stream</code> is non-zero, the copy may overlap with
     *       operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyToArrayAsync(cudaArray dst, long wOffset, long hOffset, Pointer src, long count, int cudaMemcpyKind_kind, cudaStream_t stream)
    {
        return checkResult(cudaMemcpyToArrayAsyncNative(dst, wOffset, hOffset, src, count, cudaMemcpyKind_kind, stream));
    }
    private static native int cudaMemcpyToArrayAsyncNative(cudaArray dst, long wOffset, long hOffset, Pointer src, long count, int cudaMemcpyKind_kind, cudaStream_t stream);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyFromArrayAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the CUDA array <code>src</code>
     *       starting at the upper left corner (<code>wOffset</code>, hOffset) to
     *       the memory area pointed to by <code>dst</code>, where <code>kind</code>
     *       is one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice, and specifies the
     *       direction of the copy.
     *     <p>
     *       cudaMemcpyFromArrayAsync() is asynchronous with respect to the host,
     *       so the call may return before the copy is complete. It only works on
     *       page-locked host memory and returns an error if a pointer to pageable
     *       memory is passed as input. The copy can optionally be associated to a
     *       stream by passing a non-zero <code>stream</code> argument. If
     *       <code>kind</code> is cudaMemcpyHostToDevice or cudaMemcpyDeviceToHost
     *       and <code>stream</code> is non-zero, the copy may overlap with
     *       operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyFromArrayAsync(Pointer dst, cudaArray src, long wOffset, long hOffset, long count, int cudaMemcpyKind_kind, cudaStream_t stream)
    {
        return checkResult(cudaMemcpyFromArrayAsyncNative(dst, src, wOffset, hOffset, count, cudaMemcpyKind_kind, stream));
    }
    private static native int cudaMemcpyFromArrayAsyncNative(Pointer dst, cudaArray src, long wOffset, long hOffset, long count, int cudaMemcpyKind_kind, cudaStream_t stream);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy2DAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dpitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>spitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies a matrix (<code>height</code> rows of <code>width</code> bytes
     *       each) from the memory area pointed to by <code>src</code> to the memory
     *       area pointed to by <code>dst</code>, where <code>kind</code> is one of
     *       cudaMemcpyHostToHost, cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost,
     *       or cudaMemcpyDeviceToDevice, and specifies the direction of the copy.
     *       <code>dpitch</code> and <code>spitch</code> are the widths in memory
     *       in bytes of the 2D arrays pointed to by <code>dst</code> and
     *       <code>src</code>, including any padding added to the end of each row.
     *       The memory areas may not overlap. <code>width</code> must not exceed
     *       either <code>dpitch</code> or <code>spitch</code>. Calling
     *       cudaMemcpy2DAsync() with <code>dst</code> and <code>src</code> pointers
     *       that do not match the direction of the copy results in an undefined
     *       behavior. cudaMemcpy2DAsync() returns an error if <code>dpitch</code>
     *       or <code>spitch</code> is greater than the maximum allowed.
     *     <p>
     *       cudaMemcpy2DAsync() is asynchronous with respect to the host, so the
     *       call may return before the copy is complete. It only works on
     *       page-locked host memory and returns an error if a pointer to pageable
     *       memory is passed as input. The copy can optionally be associated to a
     *       stream by passing a non-zero <code>stream</code> argument. If
     *       <code>kind</code> is cudaMemcpyHostToDevice or cudaMemcpyDeviceToHost
     *       and <code>stream</code> is non-zero, the copy may overlap with
     *       operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidPitchValue,
     * cudaErrorInvalidDevicePointer, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy2DAsync(Pointer dst, long dpitch, Pointer src, long spitch, long width, long height, int cudaMemcpyKind_kind, cudaStream_t stream)
    {
        return checkResult(cudaMemcpy2DAsyncNative(dst, dpitch, src, spitch, width, height, cudaMemcpyKind_kind, stream));
    }
    private static native int cudaMemcpy2DAsyncNative(Pointer dst, long dpitch, Pointer src, long spitch, long width, long height, int cudaMemcpyKind_kind, cudaStream_t stream);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy2DToArrayAsync           </td>
     *         <td>(</td>
     *         <td>struct cudaArray *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>spitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies a matrix (<code>height</code> rows of <code>width</code> bytes
     *       each) from the memory area pointed to by <code>src</code> to the CUDA
     *       array <code>dst</code> starting at the upper left corner
     *       (<code>wOffset</code>, <code>hOffset</code>) where <code>kind</code>
     *       is one of cudaMemcpyHostToHost, cudaMemcpyHostToDevice,
     *       cudaMemcpyDeviceToHost, or cudaMemcpyDeviceToDevice, and specifies the
     *       direction of the copy. <code>spitch</code> is the width in memory in
     *       bytes of the 2D array pointed to by <code>src</code>, including any
     *       padding added to the end of each row. <code>wOffset</code> +
     *       <code>width</code> must not exceed the width of the CUDA array
     *       <code>dst</code>. <code>width</code> must not exceed <code>spitch</code>.
     *       cudaMemcpy2DToArrayAsync() returns an error if <code>spitch</code>
     *       exceeds the maximum allowed.
     *     <p>
     *       cudaMemcpy2DToArrayAsync() is asynchronous with respect to the host,
     *       so the call may return before the copy is complete. It only works on
     *       page-locked host memory and returns an error if a pointer to pageable
     *       memory is passed as input. The copy can optionally be associated to a
     *       stream by passing a non-zero <code>stream</code> argument. If
     *       <code>kind</code> is cudaMemcpyHostToDevice or cudaMemcpyDeviceToHost
     *       and <code>stream</code> is non-zero, the copy may overlap with
     *       operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidPitchValue, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy2DToArrayAsync(cudaArray dst, long wOffset, long hOffset, Pointer src, long spitch, long width, long height, int cudaMemcpyKind_kind, cudaStream_t stream)
    {
        return checkResult(cudaMemcpy2DToArrayAsyncNative(dst, wOffset, hOffset, src, spitch, width, height, cudaMemcpyKind_kind, stream));
    }
    private static native int cudaMemcpy2DToArrayAsyncNative(cudaArray dst, long wOffset, long hOffset, Pointer src, long spitch, long width, long height, int cudaMemcpyKind_kind, cudaStream_t stream);


    /**
     * Copies data between host and device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpy2DFromArrayAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dpitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>wOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>hOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies a matrix (<code>height</code> rows of <code>width</code> bytes
     *       each) from the CUDA array <code>srcArray</code> starting at the upper
     *       left corner (<code>wOffset</code>, <code>hOffset</code>) to the memory
     *       area pointed to by <code>dst</code>, where <code>kind</code> is one of
     *       cudaMemcpyHostToHost, cudaMemcpyHostToDevice, cudaMemcpyDeviceToHost,
     *       or cudaMemcpyDeviceToDevice, and specifies the direction of the copy.
     *       <code>dpitch</code> is the width in memory in bytes of the 2D array
     *       pointed to by <code>dst</code>, including any padding added to the end
     *       of each row. <code>wOffset</code> + <code>width</code> must not exceed
     *       the width of the CUDA array <code>src</code>. <code>width</code> must
     *       not exceed <code>dpitch</code>. cudaMemcpy2DFromArrayAsync() returns
     *       an error if <code>dpitch</code> exceeds the maximum allowed.
     *     <p>
     *       cudaMemcpy2DFromArrayAsync() is asynchronous with respect to the host,
     *       so the call may return before the copy is complete. It only works on
     *       page-locked host memory and returns an error if a pointer to pageable
     *       memory is passed as input. The copy can optionally be associated to a
     *       stream by passing a non-zero <code>stream</code> argument. If
     *       <code>kind</code> is cudaMemcpyHostToDevice or cudaMemcpyDeviceToHost
     *       and <code>stream</code> is non-zero, the copy may overlap with
     *       operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidPitchValue, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpy2DFromArrayAsync(Pointer dst, long dpitch, cudaArray src, long wOffset, long hOffset, long width, long height, int cudaMemcpyKind_kind, cudaStream_t stream)
    {
        return checkResult(cudaMemcpy2DFromArrayAsyncNative(dst, dpitch, src, wOffset, hOffset, width, height, cudaMemcpyKind_kind, stream));
    }
    private static native int cudaMemcpy2DFromArrayAsyncNative(Pointer dst, long dpitch, cudaArray src, long wOffset, long hOffset, long width, long height, int cudaMemcpyKind_kind, cudaStream_t stream);


    /**
     * Copies data to the given symbol on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyToSymbolAsync           </td>
     *         <td>(</td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>symbol</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>offset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the memory area pointed to by
     *       <code>src</code> to the memory area pointed to by <code>offset</code>
     *       bytes from the start of symbol <code>symbol</code>. The memory areas
     *       may not overlap. <code>symbol</code> can either be a variable that
     *       resides in global or constant memory space, or it can be a character
     *       string, naming a variable that resides in global or constant memory
     *       space. <code>kind</code> can be either cudaMemcpyHostToDevice or
     *       cudaMemcpyDeviceToDevice.
     *     <p>
     *       cudaMemcpyToSymbolAsync() is asynchronous with respect to the host, so
     *       the call may return before the copy is complete. It only works on
     *       page-locked host memory and returns an error if a pointer to pageable
     *       memory is passed as input. The copy can optionally be associated to a
     *       stream by passing a non-zero <code>stream</code> argument. If
     *       <code>kind</code> is cudaMemcpyHostToDevice and <code>stream</code> is
     *       non-zero, the copy may overlap with operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidSymbol,
     * cudaErrorInvalidDevicePointer, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyFromSymbolAsync
     */
    public static int cudaMemcpyToSymbolAsync(String symbol, Pointer src, long count, long offset, int cudaMemcpyKind_kind, cudaStream_t stream)
    {
        return checkResult(cudaMemcpyToSymbolAsyncNative(symbol, src, count, offset, cudaMemcpyKind_kind, stream));
    }
    private static native int cudaMemcpyToSymbolAsyncNative(String symbol, Pointer src, long count, long offset, int cudaMemcpyKind_kind, cudaStream_t stream);

    /**
     * Copies data from the given symbol on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemcpyFromSymbolAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>symbol</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>offset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaMemcpyKind&nbsp;</td>
     *         <td> <em>kind</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies <code>count</code> bytes from the memory area pointed to by
     *       <code>offset</code> bytes from the start of symbol <code>symbol</code>
     *       to the memory area pointed to by <code>dst</code>. The memory areas
     *       may not overlap. <code>symbol</code> can either be a variable that
     *       resides in global or constant memory space, or it can be a character
     *       string, naming a variable that resides in global or constant memory
     *       space. <code>kind</code> can be either cudaMemcpyDeviceToHost or
     *       cudaMemcpyDeviceToDevice.
     *     <p>
     *       cudaMemcpyFromSymbolAsync() is asynchronous with respect to the host,
     *       so the call may return before the copy is complete. It only works on
     *       page-locked host memory and returns an error if a pointer to pageable
     *       memory is passed as input. The copy can optionally be associated to a
     *       stream by passing a non-zero <code>stream</code> argument. If
     *       <code>kind</code> is cudaMemcpyDeviceToHost and <code>stream</code> is
     *       non-zero, the copy may overlap with operations in other streams.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidSymbol,
     * cudaErrorInvalidDevicePointer, cudaErrorInvalidMemcpyDirection
     *
     * @see JCuda#cudaMemcpy
     * @see JCuda#cudaMemcpy2D
     * @see JCuda#cudaMemcpyToArray
     * @see JCuda#cudaMemcpy2DToArray
     * @see JCuda#cudaMemcpyFromArray
     * @see JCuda#cudaMemcpy2DFromArray
     * @see JCuda#cudaMemcpyArrayToArray
     * @see JCuda#cudaMemcpy2DArrayToArray
     * @see JCuda#cudaMemcpyToSymbol
     * @see JCuda#cudaMemcpyFromSymbol
     * @see JCuda#cudaMemcpyAsync
     * @see JCuda#cudaMemcpy2DAsync
     * @see JCuda#cudaMemcpyToArrayAsync
     * @see JCuda#cudaMemcpy2DToArrayAsync
     * @see JCuda#cudaMemcpyFromArrayAsync
     * @see JCuda#cudaMemcpy2DFromArrayAsync
     * @see JCuda#cudaMemcpyToSymbolAsync
     */
    public static int cudaMemcpyFromSymbolAsync(Pointer dst, String symbol, long count, long offset, int cudaMemcpyKind_kind, cudaStream_t stream)
    {
        return checkResult(cudaMemcpyFromSymbolAsyncNative(dst, symbol, count, offset, cudaMemcpyKind_kind, stream));
    }
    private static native int cudaMemcpyFromSymbolAsyncNative(Pointer dst, String symbol, long count, long offset, int cudaMemcpyKind_kind, cudaStream_t stream);



    /**
     * Initializes or sets device memory to a value.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemset           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>value</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>count</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Fills the first <code>count</code> bytes of the memory area pointed to
     *       by <code>devPtr</code> with the constant byte value
     *       <code>value</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer
     *
     *
     * @see JCuda#cudaMemset2D
     * @see JCuda#cudaMemset3D
     * @see JCuda#cudaMemsetAsync
     * @see JCuda#cudaMemset2DAsync
     * @see JCuda#cudaMemset3DAsync
     */
    public static int cudaMemset(Pointer mem, int c, long count)
    {
        return checkResult(cudaMemsetNative(mem, c, count));
    }
    private static native int cudaMemsetNative(Pointer mem, int c, long count);


    /**
     * Initializes or sets device memory to a value.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaMemset2D           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>pitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>value</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets to the specified value <code>value</code> a matrix
     *       (<code>height</code> rows of <code>width</code> bytes each) pointed to
     *       by <code>dstPtr</code>. <code>pitch</code> is the width in bytes of
     *       the 2D array pointed to by <code>dstPtr</code>, including any padding
     *       added to the end of each row. This function performs fastest when the
     *       pitch is one that has been passed back by cudaMallocPitch().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer
     *
     *
     * @see JCuda#cudaMemset
     * @see JCuda#cudaMemset3D
     * @see JCuda#cudaMemsetAsync
     * @see JCuda#cudaMemset2DAsync
     * @see JCuda#cudaMemset3DAsync
     */
    public static int cudaMemset2D(Pointer mem, long pitch, int c, long width, long height)
    {
        return checkResult(cudaMemset2DNative(mem, pitch, c, width, height));
    }
    private static native int cudaMemset2DNative(Pointer mem, long pitch, int c, long width, long height);



    /**
     * Get the channel descriptor of an array.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetChannelDesc           </td>
     *         <td>(</td>
     *         <td>struct cudaChannelFormatDesc *&nbsp;</td>
     *         <td> <em>desc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>array</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*desc</code> the channel descriptor of the CUDA array
     *       <code>array</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue
     *
     * @see JCuda#cudaCreateChannelDesc
     * @see JCuda#cudaGetTextureReference
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaUnbindTexture
     * @see JCuda#cudaGetTextureAlignmentOffset
     */
    public static int cudaGetChannelDesc(cudaChannelFormatDesc desc, cudaArray array)
    {
        return checkResult(cudaGetChannelDescNative(desc, array));
    }
    private static native int cudaGetChannelDescNative(cudaChannelFormatDesc desc, cudaArray array);


    /**
     * Returns a channel descriptor using the specified format.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T &gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaChannelFormatDesc cudaCreateChannelDesc          </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns a channel descriptor with format <code>f</code> and number of
     *       bits of each component <code>x</code>, <code>y</code>, <code>z</code>,
     *       and <code>w</code>. The cudaChannelFormatDesc is defined as:
     *     <div>
     *       <pre>  <span>struct </span>cudaChannelFormatDesc {
     *     <span>int</span> x, y, z, w;
     *     <span>enum</span> cudaChannelFormatKind f;
     *   };
     * </pre>
     *     </div>
     *     <p>
     *       where cudaChannelFormatKind is one of cudaChannelFormatKindSigned,
     *       cudaChannelFormatKindUnsigned, or cudaChannelFormatKindFloat.
     *     <p>
     *   </div>
     * </div>
     *
     * @return Channel descriptor with format <code>f</code>
     *
     * @see JCuda#cudaCreateChannelDesc
     * @see JCuda#cudaGetChannelDesc
     * @see JCuda#cudaGetTextureReference
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaUnbindTexture
     * @see JCuda#cudaGetTextureAlignmentOffset
     */
    public static cudaChannelFormatDesc cudaCreateChannelDesc(int x, int y, int z, int w, int cudaChannelFormatKind_f)
    {
        return cudaCreateChannelDescNative(x,y,z,w,cudaChannelFormatKind_f);
    }
    private static native cudaChannelFormatDesc cudaCreateChannelDescNative(int x, int y, int z, int w, int cudaChannelFormatKind_f);

    /**
     * Returns the last error from a runtime call.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetLastError           </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns the last error that has been produced by any of the runtime
     *       calls in the same host thread and resets it to cudaSuccess.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMissingConfiguration,
     * cudaErrorMemoryAllocation, cudaErrorInitializationError,
     * cudaErrorLaunchFailure, cudaErrorLaunchTimeout,
     * cudaErrorLaunchOutOfResources, cudaErrorInvalidDeviceFunction,
     * cudaErrorInvalidConfiguration, cudaErrorInvalidDevice,
     * cudaErrorInvalidValue, cudaErrorInvalidPitchValue, cudaErrorInvalidSymbol,
     * cudaErrorUnmapBufferObjectFailed, cudaErrorInvalidHostPointer,
     * cudaErrorInvalidDevicePointer, cudaErrorInvalidTexture,
     * cudaErrorInvalidTextureBinding, cudaErrorInvalidChannelDescriptor,
     * cudaErrorInvalidMemcpyDirection, cudaErrorInvalidFilterSetting,
     * cudaErrorInvalidNormSetting, cudaErrorUnknown, cudaErrorNotYetImplemented,
     * cudaErrorInvalidResourceHandle, cudaErrorInsufficientDriver,
     * cudaErrorSetOnActiveProcess, cudaErrorStartupFailure,
     * cudaErrorApiFailureBase
     *
     * @see JCuda#cudaPeekAtLastError
     * @see JCuda#cudaGetErrorString
     * @see cudaError
     */
    public static int cudaGetLastError()
    {
        return checkResult(cudaGetLastErrorNative());
    }
    private static native int cudaGetLastErrorNative();


    /**
     * Returns the last error from a runtime call.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaPeekAtLastError           </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns the last error that has been produced by any of the runtime
     *       calls in the same host thread. Note that this call does not reset the
     *       error to cudaSuccess like cudaGetLastError().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMissingConfiguration,
     * cudaErrorMemoryAllocation, cudaErrorInitializationError,
     * cudaErrorLaunchFailure, cudaErrorLaunchTimeout,
     * cudaErrorLaunchOutOfResources, cudaErrorInvalidDeviceFunction,
     * cudaErrorInvalidConfiguration, cudaErrorInvalidDevice,
     * cudaErrorInvalidValue, cudaErrorInvalidPitchValue, cudaErrorInvalidSymbol,
     * cudaErrorUnmapBufferObjectFailed, cudaErrorInvalidHostPointer,
     * cudaErrorInvalidDevicePointer, cudaErrorInvalidTexture,
     * cudaErrorInvalidTextureBinding, cudaErrorInvalidChannelDescriptor,
     * cudaErrorInvalidMemcpyDirection, cudaErrorInvalidFilterSetting,
     * cudaErrorInvalidNormSetting, cudaErrorUnknown, cudaErrorNotYetImplemented,
     * cudaErrorInvalidResourceHandle, cudaErrorInsufficientDriver,
     * cudaErrorSetOnActiveProcess, cudaErrorStartupFailure,
     * cudaErrorApiFailureBase
     *
     * @see JCuda#cudaGetLastError
     * @see JCuda#cudaGetErrorString
     * @see cudaError
     */
    public static int cudaPeekAtLastError()
    {
        return checkResult(cudaPeekAtLastErrorNative());
    }
    private static native int cudaPeekAtLastErrorNative();


    /**
     * Returns the message string from an error code.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>const char* cudaGetErrorString           </td>
     *         <td>(</td>
     *         <td>cudaError_t&nbsp;</td>
     *         <td> <em>error</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns the message string from an error code.
     *     <p>
     *   </div>
     * </div>
     *
     * @return <code>char*</code> pointer to a NULL-terminated string
     *
     * @see JCuda#cudaGetLastError
     * @see JCuda#cudaPeekAtLastError
     * @see cudaError
     */
    public static String cudaGetErrorString(int error)
    {
        return cudaGetErrorStringNative(error);
    }
    private static native String cudaGetErrorStringNative(int error);

    /**
     * Create an asynchronous stream.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaStreamCreate           </td>
     *         <td>(</td>
     *         <td>cudaStream_t *&nbsp;</td>
     *         <td> <em>pStream</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates a new asynchronous stream.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue
     *
     * @see JCuda#cudaStreamQuery
     * @see JCuda#cudaStreamSynchronize
     * @see JCuda#cudaStreamWaitEvent
     * @see JCuda#cudaStreamDestroy
     */
    public static int cudaStreamCreate(cudaStream_t stream)
    {
        return checkResult(cudaStreamCreateNative(stream));
    }
    private static native int cudaStreamCreateNative(cudaStream_t stream);


    /**
     * Destroys and cleans up an asynchronous stream.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaStreamDestroy           </td>
     *         <td>(</td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Destroys and cleans up the asynchronous stream specified by
     *       <code>stream</code>.
     *     <p>
     *       In the case that the device is still doing work in the stream
     *       <code>stream</code> when cudaStreamDestroy() is called, the function
     *       will return immediately and the resources associated with
     *       <code>stream</code> will be released automatically once the device has
     *       completed all work in <code>stream</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidResourceHandle
     *
     * @see JCuda#cudaStreamCreate
     * @see JCuda#cudaStreamQuery
     * @see JCuda#cudaStreamWaitEvent
     * @see JCuda#cudaStreamSynchronize
     */
    public static int cudaStreamDestroy(cudaStream_t stream)
    {
        return checkResult(cudaStreamDestroyNative(stream));
    }
    private static native int cudaStreamDestroyNative(cudaStream_t stream);


    /**
     * Make a compute stream wait on an event.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaStreamWaitEvent           </td>
     *         <td>(</td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaEvent_t&nbsp;</td>
     *         <td> <em>event</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Makes all future work submitted to <code>stream</code> wait until
     *       <code>event</code> reports completion before beginning execution. This
     *       synchronization will be performed efficiently on the device. The event
     *       <code>event</code> may be from a different context than
     *       <code>stream</code>, in which case this function will perform
     *       cross-device synchronization.
     *     <p>
     *       The stream <code>stream</code> will wait only for the completion of
     *       the most recent host call to cudaEventRecord() on <code>event</code>.
     *       Once this call has returned, any functions (including cudaEventRecord()
     *       and cudaEventDestroy()) may be called on <code>event</code> again, and
     *       the subsequent calls will not have any effect on
     *       <code>stream</code>.
     *     <p>
     *       If <code>stream</code> is NULL, any future work submitted in any stream
     *       will wait for <code>event</code> to complete before beginning execution.
     *       This effectively creates a barrier for all future work submitted to
     *       the device on this thread.
     *     <p>
     *       If cudaEventRecord() has not been called on <code>event</code>, this
     *       call acts as if the record has already completed, and so is a functional
     *       no-op.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidResourceHandle
     *
     * @see JCuda#cudaStreamCreate
     * @see JCuda#cudaStreamQuery
     * @see JCuda#cudaStreamSynchronize
     * @see JCuda#cudaStreamDestroy
     */
    public static int cudaStreamWaitEvent(cudaStream_t stream, cudaEvent_t event, int flags)
    {
        return checkResult(cudaStreamWaitEventNative(stream, event, flags));
    }
    private static native int cudaStreamWaitEventNative(cudaStream_t stream, cudaEvent_t event, int flags);

    /**
     * Waits for stream tasks to complete.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaStreamSynchronize           </td>
     *         <td>(</td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Blocks until <code>stream</code> has completed all operations. If the
     *       cudaDeviceScheduleBlockingSync flag was set for this device, the host
     *       thread will block until the stream is finished with all of its
     *       tasks.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidResourceHandle
     *
     * @see JCuda#cudaStreamCreate
     * @see JCuda#cudaStreamQuery
     * @see JCuda#cudaStreamWaitEvent
     * @see JCuda#cudaStreamDestroy
     */
    public static int cudaStreamSynchronize(cudaStream_t stream)
    {
        return checkResult(cudaStreamSynchronizeNative(stream));
    }
    private static native int cudaStreamSynchronizeNative(cudaStream_t stream);


    /**
     * Queries an asynchronous stream for completion status.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaStreamQuery           </td>
     *         <td>(</td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns cudaSuccess if all operations in <code>stream</code> have
     *       completed, or cudaErrorNotReady if not.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorNotReady cudaErrorInvalidResourceHandle
     *
     * @see JCuda#cudaStreamCreate
     * @see JCuda#cudaStreamWaitEvent
     * @see JCuda#cudaStreamSynchronize
     * @see JCuda#cudaStreamDestroy
     */
    public static int cudaStreamQuery(cudaStream_t stream)
    {
        return checkResult(cudaStreamQueryNative(stream));
    }
    private static native int cudaStreamQueryNative(cudaStream_t stream);


    /**
     * Creates an event object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaEventCreate           </td>
     *         <td>(</td>
     *         <td>cudaEvent_t *&nbsp;</td>
     *         <td> <em>event</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates an event object using cudaEventDefault.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError,
     * cudaErrorPriorLaunchFailure, cudaErrorInvalidValue,
     * cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaEventCreateWithFlags
     * @see JCuda#cudaEventRecord
     * @see JCuda#cudaEventQuery
     * @see JCuda#cudaEventSynchronize
     * @see JCuda#cudaEventDestroy
     * @see JCuda#cudaEventElapsedTime
     */
    public static int cudaEventCreate(cudaEvent_t event)
    {
        return checkResult(cudaEventCreateNative(event));
    }
    private static native int cudaEventCreateNative(cudaEvent_t event);


    /**
     * Creates an event object with the specified flags.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaEventCreateWithFlags           </td>
     *         <td>(</td>
     *         <td>cudaEvent_t *&nbsp;</td>
     *         <td> <em>event</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates an event object with the specified flags. Valid flags
     *       include:
     *     <ul>
     *       <li>cudaEventDefault: Default event creation
     *         flag.
     *       </li>
     *       <li>cudaEventBlockingSync: Specifies that event should use
     *         blocking synchronization. A host thread that uses cudaEventSynchronize()
     *         to wait on an event created with this flag will block until the event
     *         actually completes.
     *       </li>
     *       <li>cudaEventDisableTiming: Specifies that the
     *         created event does not need to record timing data. Events created with
     *         this flag specified and the cudaEventBlockingSync flag not specified
     *         will provide the best performance when used with cudaStreamWaitEvent()
     *         and cudaEventQuery().
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError, cudaErrorInvalidValue,
     * cudaErrorLaunchFailure, cudaErrorMemoryAllocation
     *
     * @see JCuda#cudaEventCreate
     * @see JCuda#cudaEventSynchronize
     * @see JCuda#cudaEventDestroy
     * @see JCuda#cudaEventElapsedTime
     * @see JCuda#cudaStreamWaitEvent
     */
    public static int cudaEventCreateWithFlags (cudaEvent_t event, int flags)
    {
        return checkResult(cudaEventCreateWithFlagsNative(event, flags));
    }
    private static native int cudaEventCreateWithFlagsNative(cudaEvent_t event, int flags);


    /**
     * Records an event.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaEventRecord           </td>
     *         <td>(</td>
     *         <td>cudaEvent_t&nbsp;</td>
     *         <td> <em>event</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Records an event. If <code>stream</code> is non-zero, the event is
     *       recorded after all preceding operations in <code>stream</code> have
     *       been completed; otherwise, it is recorded after all preceding operations
     *       in the CUDA context have been completed. Since operation is asynchronous,
     *       cudaEventQuery() and/or cudaEventSynchronize() must be used to determine
     *       when the event has actually been recorded.
     *     <p>
     *       If cudaEventRecord() has previously been called on <code>event</code>,
     *       then this call will overwrite any existing state in <code>event</code>.
     *       Any subsequent calls which examine the status of <code>event</code>
     *       will only examine the completion of this most recent call to
     *       cudaEventRecord().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInitializationError,
     * cudaErrorInvalidResourceHandle, cudaErrorLaunchFailure
     *
     * @see JCuda#cudaEventCreate
     * @see JCuda#cudaEventCreateWithFlags
     * @see JCuda#cudaEventQuery
     * @see JCuda#cudaEventSynchronize
     * @see JCuda#cudaEventDestroy
     * @see JCuda#cudaEventElapsedTime
     * @see JCuda#cudaStreamWaitEvent
     */
    public static int cudaEventRecord(cudaEvent_t event, cudaStream_t stream)
    {
        return checkResult(cudaEventRecordNative(event, stream));
    }
    private static native int cudaEventRecordNative(cudaEvent_t event, cudaStream_t stream);


    /**
     * Queries an event's status.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaEventQuery           </td>
     *         <td>(</td>
     *         <td>cudaEvent_t&nbsp;</td>
     *         <td> <em>event</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Query the status of all device work preceding the most recent call to
     *       cudaEventRecord() (in the appropriate compute streams, as specified by
     *       the arguments to cudaEventRecord()).
     *     <p>
     *       If this work has successfully been completed by the device, or if
     *       cudaEventRecord() has not been called on <code>event</code>, then
     *       cudaSuccess is returned. If this work has not yet been completed by
     *       the device then cudaErrorNotReady is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorNotReady, cudaErrorInitializationError,
     * cudaErrorInvalidValue, cudaErrorInvalidResourceHandle,
     * cudaErrorLaunchFailure
     *
     * @see JCuda#cudaEventCreate
     * @see JCuda#cudaEventCreateWithFlags
     * @see JCuda#cudaEventRecord
     * @see JCuda#cudaEventSynchronize
     * @see JCuda#cudaEventDestroy
     * @see JCuda#cudaEventElapsedTime
     */
    public static int cudaEventQuery(cudaEvent_t event)
    {
        return checkResult(cudaEventQueryNative(event));
    }
    private static native int cudaEventQueryNative(cudaEvent_t event);


    /**
     * Waits for an event to complete.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaEventSynchronize           </td>
     *         <td>(</td>
     *         <td>cudaEvent_t&nbsp;</td>
     *         <td> <em>event</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Wait until the completion of all device work preceding the most recent
     *       call to cudaEventRecord() (in the appropriate compute streams, as
     *       specified by the arguments to cudaEventRecord()).
     *     <p>
     *       If cudaEventRecord() has not been called on <code>event</code>,
     *       cudaSuccess is returned immediately.
     *     <p>
     *       Waiting for an event that was created with the cudaEventBlockingSync
     *       flag will cause the calling CPU thread to block until the event has
     *       been completed by the device. If the cudaEventBlockingSync flag has
     *       not been set, then the CPU thread will busy-wait until the event has
     *       been completed by the device.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError, cudaErrorInvalidValue,
     * cudaErrorInvalidResourceHandle, cudaErrorLaunchFailure
     *
     * @see JCuda#cudaEventCreate
     * @see JCuda#cudaEventCreateWithFlags
     * @see JCuda#cudaEventRecord
     * @see JCuda#cudaEventQuery
     * @see JCuda#cudaEventDestroy
     * @see JCuda#cudaEventElapsedTime
     */
    public static int cudaEventSynchronize(cudaEvent_t event)
    {
        return checkResult(cudaEventSynchronizeNative(event));
    }
    private static native int cudaEventSynchronizeNative(cudaEvent_t event);


    /**
     * Destroys an event object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaEventDestroy           </td>
     *         <td>(</td>
     *         <td>cudaEvent_t&nbsp;</td>
     *         <td> <em>event</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Destroys the event specified by <code>event</code>.
     *     <p>
     *       In the case that <code>event</code> has been recorded but has not yet
     *       been completed when cudaEventDestroy() is called, the function will
     *       return immediately and the resources associated with <code>event</code>
     *       will be released automatically once the device has completed
     *       <code>event</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError, cudaErrorInvalidValue,
     * cudaErrorLaunchFailure
     *
     * @see JCuda#cudaEventCreate
     * @see JCuda#cudaEventCreateWithFlags
     * @see JCuda#cudaEventQuery
     * @see JCuda#cudaEventSynchronize
     * @see JCuda#cudaEventRecord
     * @see JCuda#cudaEventElapsedTime
     */
    public static int cudaEventDestroy(cudaEvent_t event)
    {
        return checkResult(cudaEventDestroyNative(event));
    }
    private static native int cudaEventDestroyNative(cudaEvent_t event);


    /**
     * Computes the elapsed time between events.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaEventElapsedTime           </td>
     *         <td>(</td>
     *         <td>float *&nbsp;</td>
     *         <td> <em>ms</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaEvent_t&nbsp;</td>
     *         <td> <em>start</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaEvent_t&nbsp;</td>
     *         <td> <em>end</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Computes the elapsed time between two events (in milliseconds with a
     *       resolution of around 0.5 microseconds).
     *     <p>
     *       If either event was last recorded in a non-NULL stream, the resulting
     *       time may be greater than expected (even if both used the same stream
     *       handle). This happens because the cudaEventRecord() operation takes
     *       place asynchronously and there is no guarantee that the measured
     *       latency is actually just between the two events. Any number of other
     *       different stream operations could execute in between the two measured
     *       events, thus altering the timing in a significant way.
     *     <p>
     *       If cudaEventRecord() has not been called on either event, then
     *       cudaErrorInvalidResourceHandle is returned. If cudaEventRecord() has
     *       been called on both events but one or both of them has not yet been
     *       completed (that is, cudaEventQuery() would return cudaErrorNotReady on
     *       at least one of the events), cudaErrorNotReady is returned. If either
     *       event was created with the cudaEventDisableTiming flag, then this
     *       function will return cudaErrorInvalidResourceHandle.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorNotReady, cudaErrorInvalidValue,
     * cudaErrorInitializationError, cudaErrorInvalidResourceHandle,
     * cudaErrorLaunchFailure
     *
     * @see JCuda#cudaEventCreate
     * @see JCuda#cudaEventCreateWithFlags
     * @see JCuda#cudaEventQuery
     * @see JCuda#cudaEventSynchronize
     * @see JCuda#cudaEventDestroy
     * @see JCuda#cudaEventRecord
     */
    public static int cudaEventElapsedTime(float ms[], cudaEvent_t start, cudaEvent_t end)
    {
        return checkResult(cudaEventElapsedTimeNative(ms, start, end));
    }
    private static native int cudaEventElapsedTimeNative(float ms[], cudaEvent_t start, cudaEvent_t end);



    /**
     * Destroy all allocations and reset all state on the current device in
     * the current process.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceReset           </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Explicitly destroys and cleans up all resources associated with the
     *       current device in the current process. Any subsequent API call to this
     *       device will reinitialize the device.
     *     <p>
     *       Note that this function will reset the device immediately. It is the
     *       caller's responsibility to ensure that the device is not being accessed
     *       by any other host threads from the process when this function is
     *       called.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaDeviceSynchronize
     */
    public static int cudaDeviceReset()
    {
        return checkResult(cudaDeviceResetNative());
    }
    private static native int cudaDeviceResetNative();

    /**
     * Wait for compute device to finish.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceSynchronize           </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Blocks until the device has completed all preceding requested tasks.
     *       cudaDeviceSynchronize() returns an error if one of the preceding tasks
     *       has failed. If the cudaDeviceScheduleBlockingSync flag was set for this
     *       device, the host thread will block until the device has finished its
     *       work.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaDeviceSynchronize
     */
    public static int cudaDeviceSynchronize()
    {
        return checkResult(cudaDeviceSynchronizeNative());
    }
    private static native int cudaDeviceSynchronizeNative();

    /**
     * Set resource limits.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceSetLimit           </td>
     *         <td>(</td>
     *         <td>enum cudaLimit&nbsp;</td>
     *         <td> <em>limit</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>value</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Setting <code>limit</code> to <code>value</code> is a request by the
     *       application to update the current limit maintained by the device. The
     *       driver is free to modify the requested value to meet h/w requirements
     *       (this could be clamping to minimum or maximum values, rounding up to
     *       nearest element size, etc). The application can use cudaDeviceGetLimit()
     *       to find out exactly what the limit has been set to.
     *     <p>
     *       Setting each cudaLimit has its own specific restrictions, so each is
     *       discussed here.
     *     <p>
     *     <ul>
     *       <li>cudaLimitStackSize controls the stack size of each GPU thread. This
     *         limit is only applicable to devices of compute capability 2.0 and
     *         higher. Attempting to set this limit on devices of compute capability
     *         less than 2.0 will result in the error cudaErrorUnsupportedLimit being
     *         returned.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>cudaLimitPrintfFifoSize controls the size of the FIFO used by the
     *         printf() device system call. Setting cudaLimitPrintfFifoSize must be
     *         performed before launching any kernel that uses the printf() device
     *         system call, otherwise cudaErrorInvalidValue will be returned. This
     *         limit is only applicable to devices of compute capability 2.0 and
     *         higher. Attempting to set this limit on devices of compute capability
     *         less than 2.0 will result in the error cudaErrorUnsupportedLimit being
     *         returned.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>cudaLimitMallocHeapSize controls the size of the heap used by the
     *         malloc() and free() device system calls. Setting cudaLimitMallocHeapSize
     *         must be performed before launching any kernel that uses the malloc()
     *         or free() device system calls, otherwise cudaErrorInvalidValue will be
     *         returned. This limit is only applicable to devices of compute capability
     *         2.0 and higher. Attempting to set this limit on devices of compute
     *         capability less than 2.0 will result in the error cudaErrorUnsupportedLimit
     *         being returned.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorUnsupportedLimit, cudaErrorInvalidValue
     *
     * @see JCuda#cudaDeviceGetLimit
     */
    public static int cudaDeviceSetLimit(int limit, long value)
    {
        return checkResult(cudaDeviceSetLimitNative(limit, value));
    }
    private static native int cudaDeviceSetLimitNative(int limit, long value);

    /**
     * Returns resource limits.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceGetLimit           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>pValue</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaLimit&nbsp;</td>
     *         <td> <em>limit</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pValue</code> the current size of <code>limit</code>.
     *       The supported cudaLimit values are:
     *     <ul>
     *       <li>cudaLimitStackSize: stack size of each GPU
     *         thread;
     *       </li>
     *       <li>cudaLimitPrintfFifoSize: size of the FIFO used by the
     *         printf() device system call.
     *       </li>
     *       <li>cudaLimitMallocHeapSize: size of
     *         the heap used by the malloc() and free() device system
     *         calls;
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorUnsupportedLimit, cudaErrorInvalidValue
     *
     * @see JCuda#cudaDeviceSetLimit
     */
    public static int cudaDeviceGetLimit(long pValue[], int limit)
    {
        return checkResult(cudaDeviceGetLimitNative(pValue, limit));
    }
    private static native int cudaDeviceGetLimitNative(long pValue[], int limit);

    /**
     * Returns the preferred cache configuration for the current device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceGetCacheConfig           </td>
     *         <td>(</td>
     *         <td>enum cudaFuncCache *&nbsp;</td>
     *         <td> <em>pCacheConfig</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       On devices where the L1 cache and shared memory use the same hardware
     *       resources, this returns through <code>pCacheConfig</code> the preferred
     *       cache configuration for the current device. This is only a preference.
     *       The runtime will use the requested configuration if possible, but it
     *       is free to choose a different configuration if required to execute
     *       functions.
     *     <p>
     *       This will return a <code>pCacheConfig</code> of cudaFuncCachePreferNone
     *       on devices where the size of the L1 cache and shared memory are
     *       fixed.
     *     <p>
     *       The supported cache configurations are:
     *     <ul>
     *       <li>cudaFuncCachePreferNone: no preference for shared memory or L1
     *         (default)
     *       </li>
     *       <li>cudaFuncCachePreferShared: prefer larger shared
     *         memory and smaller L1 cache
     *       </li>
     *       <li>cudaFuncCachePreferL1: prefer
     *         larger L1 cache and smaller shared memory
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError
     *
     * @see JCuda#cudaDeviceSetCacheConfig
     * @see JCuda#cudaDeviceSetCacheConfig
     * @see JCuda#cudaDeviceSetCacheConfig
     */
    public static int cudaDeviceGetCacheConfig(int pCacheConfig[])
    {
        return checkResult(cudaDeviceGetCacheConfigNative(pCacheConfig));
    }
    private static native int cudaDeviceGetCacheConfigNative(int pCacheConfig[]);


    /**
     * Sets the preferred cache configuration for the current device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceSetCacheConfig           </td>
     *         <td>(</td>
     *         <td>enum cudaFuncCache&nbsp;</td>
     *         <td> <em>cacheConfig</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       On devices where the L1 cache and shared memory use the same hardware
     *       resources, this sets through <code>cacheConfig</code> the preferred
     *       cache configuration for the current device. This is only a preference.
     *       The runtime will use the requested configuration if possible, but it
     *       is free to choose a different configuration if required to execute the
     *       function. Any function preference set via cudaDeviceSetCacheConfig (C
     *       API) or cudaDeviceSetCacheConfig (C++ API) will be preferred over this
     *       device-wide setting. Setting the device-wide cache configuration to
     *       cudaFuncCachePreferNone will cause subsequent kernel launches to prefer
     *       to not change the cache configuration unless required to launch the
     *       kernel.
     *     <p>
     *       This setting does nothing on devices where the size of the L1 cache
     *       and shared memory are fixed.
     *     <p>
     *       Launching a kernel with a different preference than the most recent
     *       preference setting may insert a device-side synchronization point.
     *     <p>
     *       The supported cache configurations are:
     *     <ul>
     *       <li>cudaFuncCachePreferNone: no preference for shared memory or L1
     *         (default)
     *       </li>
     *       <li>cudaFuncCachePreferShared: prefer larger shared
     *         memory and smaller L1 cache
     *       </li>
     *       <li>cudaFuncCachePreferL1: prefer
     *         larger L1 cache and smaller shared memory
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError
     *
     * @see JCuda#cudaDeviceGetCacheConfig
     */
    public static int cudaDeviceSetCacheConfig(int cacheConfig)
    {
        return checkResult(cudaDeviceSetCacheConfigNative(cacheConfig));
    }
    private static native int cudaDeviceSetCacheConfigNative(int cacheConfig);




    /**
     * Exit and clean up from CUDA launches.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaThreadExit           </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that this function is deprecated because its name does not reflect
     *     its behavior. Its functionality is identical to the non-deprecated
     *     function cudaDeviceReset(), which should be used instead.
     *     <p>
     *       Explicitly destroys all cleans up all resources associated with the
     *       current device in the current process. Any subsequent API call to this
     *       device will reinitialize the device.
     *     <p>
     *       Note that this function will reset the device immediately. It is the
     *       caller's responsibility to ensure that the device is not being accessed
     *       by any other host threads from the process when this function is
     *       called.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaDeviceReset
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaThreadExit()
    {
        return checkResult(cudaThreadExitNative());
    }
    private static native int cudaThreadExitNative();



    /**
     * Wait for compute device to finish.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaThreadSynchronize           </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that this function is deprecated because its name does not reflect
     *     its behavior. Its functionality is similar to the non-deprecated
     *     function cudaDeviceSynchronize(), which should be used instead.
     *     <p>
     *       Blocks until the device has completed all preceding requested tasks.
     *       cudaThreadSynchronize() returns an error if one of the preceding tasks
     *       has failed. If the cudaDeviceScheduleBlockingSync flag was set for this
     *       device, the host thread will block until the device has finished its
     *       work.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaDeviceSynchronize
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaThreadSynchronize()
    {
        return checkResult(cudaThreadSynchronizeNative());
    }
    private static native int cudaThreadSynchronizeNative();

    /**
     * Set resource limits.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaThreadSetLimit           </td>
     *         <td>(</td>
     *         <td>enum cudaLimit&nbsp;</td>
     *         <td> <em>limit</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>value</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that this function is deprecated because its name does not reflect
     *     its behavior. Its functionality is identical to the non-deprecated
     *     function cudaDeviceSetLimit(), which should be used instead.
     *     <p>
     *       Setting <code>limit</code> to <code>value</code> is a request by the
     *       application to update the current limit maintained by the device. The
     *       driver is free to modify the requested value to meet h/w requirements
     *       (this could be clamping to minimum or maximum values, rounding up to
     *       nearest element size, etc). The application can use cudaThreadGetLimit()
     *       to find out exactly what the limit has been set to.
     *     <p>
     *       Setting each cudaLimit has its own specific restrictions, so each is
     *       discussed here.
     *     <p>
     *     <ul>
     *       <li>cudaLimitStackSize controls the stack size of each GPU thread. This
     *         limit is only applicable to devices of compute capability 2.0 and
     *         higher. Attempting to set this limit on devices of compute capability
     *         less than 2.0 will result in the error cudaErrorUnsupportedLimit being
     *         returned.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>cudaLimitPrintfFifoSize controls the size of the FIFO used by the
     *         printf() device system call. Setting cudaLimitPrintfFifoSize must be
     *         performed before launching any kernel that uses the printf() device
     *         system call, otherwise cudaErrorInvalidValue will be returned. This
     *         limit is only applicable to devices of compute capability 2.0 and
     *         higher. Attempting to set this limit on devices of compute capability
     *         less than 2.0 will result in the error cudaErrorUnsupportedLimit being
     *         returned.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>cudaLimitMallocHeapSize controls the size of the heap used by the
     *         malloc() and free() device system calls. Setting cudaLimitMallocHeapSize
     *         must be performed before launching any kernel that uses the malloc()
     *         or free() device system calls, otherwise cudaErrorInvalidValue will be
     *         returned. This limit is only applicable to devices of compute capability
     *         2.0 and higher. Attempting to set this limit on devices of compute
     *         capability less than 2.0 will result in the error cudaErrorUnsupportedLimit
     *         being returned.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorUnsupportedLimit, cudaErrorInvalidValue
     *
     * @see JCuda#cudaDeviceSetLimit
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaThreadSetLimit(int limit, long value)
    {
        return checkResult(cudaThreadSetLimitNative(limit, value));
    }
    private static native int cudaThreadSetLimitNative(int limit, long value);


    /**
     * Returns the preferred cache configuration for the current device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaThreadGetCacheConfig           </td>
     *         <td>(</td>
     *         <td>enum cudaFuncCache *&nbsp;</td>
     *         <td> <em>pCacheConfig</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that this function is deprecated because its name does not reflect
     *     its behavior. Its functionality is identical to the non-deprecated
     *     function cudaDeviceGetCacheConfig(), which should be used instead.
     *     <p>
     *       On devices where the L1 cache and shared memory use the same hardware
     *       resources, this returns through <code>pCacheConfig</code> the preferred
     *       cache configuration for the current device. This is only a preference.
     *       The runtime will use the requested configuration if possible, but it
     *       is free to choose a different configuration if required to execute
     *       functions.
     *     <p>
     *       This will return a <code>pCacheConfig</code> of cudaFuncCachePreferNone
     *       on devices where the size of the L1 cache and shared memory are
     *       fixed.
     *     <p>
     *       The supported cache configurations are:
     *     <ul>
     *       <li>cudaFuncCachePreferNone: no preference for shared memory or L1
     *         (default)
     *       </li>
     *       <li>cudaFuncCachePreferShared: prefer larger shared
     *         memory and smaller L1 cache
     *       </li>
     *       <li>cudaFuncCachePreferL1: prefer
     *         larger L1 cache and smaller shared memory
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError
     *
     * @see JCuda#cudaDeviceGetCacheConfig
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaThreadGetCacheConfig(int pCacheConfig[])
    {
        return checkResult(cudaThreadGetCacheConfigNative(pCacheConfig));
    }

    private static native int cudaThreadGetCacheConfigNative(int[] pCacheConfig);

    /**
     * Sets the preferred cache configuration for the current device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaThreadSetCacheConfig           </td>
     *         <td>(</td>
     *         <td>enum cudaFuncCache&nbsp;</td>
     *         <td> <em>cacheConfig</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that this function is deprecated because its name does not reflect
     *     its behavior. Its functionality is identical to the non-deprecated
     *     function cudaDeviceSetCacheConfig(), which should be used instead.
     *     <p>
     *       On devices where the L1 cache and shared memory use the same hardware
     *       resources, this sets through <code>cacheConfig</code> the preferred
     *       cache configuration for the current device. This is only a preference.
     *       The runtime will use the requested configuration if possible, but it
     *       is free to choose a different configuration if required to execute the
     *       function. Any function preference set via cudaDeviceSetCacheConfig (C
     *       API) or cudaDeviceSetCacheConfig (C++ API) will be preferred over this
     *       device-wide setting. Setting the device-wide cache configuration to
     *       cudaFuncCachePreferNone will cause subsequent kernel launches to prefer
     *       to not change the cache configuration unless required to launch the
     *       kernel.
     *     <p>
     *       This setting does nothing on devices where the size of the L1 cache
     *       and shared memory are fixed.
     *     <p>
     *       Launching a kernel with a different preference than the most recent
     *       preference setting may insert a device-side synchronization point.
     *     <p>
     *       The supported cache configurations are:
     *     <ul>
     *       <li>cudaFuncCachePreferNone: no preference for shared memory or L1
     *         (default)
     *       </li>
     *       <li>cudaFuncCachePreferShared: prefer larger shared
     *         memory and smaller L1 cache
     *       </li>
     *       <li>cudaFuncCachePreferL1: prefer
     *         larger L1 cache and smaller shared memory
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError
     *
     * @see JCuda#cudaDeviceSetCacheConfig
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaThreadSetCacheConfig(int cacheConfig)
    {
        return checkResult(cudaThreadSetCacheConfigNative(cacheConfig));
    }

    private static native int cudaThreadSetCacheConfigNative(int cacheConfig);



    /**
     * Returns resource limits.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaThreadGetLimit           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>pValue</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>enum cudaLimit&nbsp;</td>
     *         <td> <em>limit</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that this function is deprecated because its name does not reflect
     *     its behavior. Its functionality is identical to the non-deprecated
     *     function cudaDeviceGetLimit(), which should be used instead.
     *     <p>
     *       Returns in <code>*pValue</code> the current size of <code>limit</code>.
     *       The supported cudaLimit values are:
     *     <ul>
     *       <li>cudaLimitStackSize: stack size of each GPU
     *         thread;
     *       </li>
     *       <li>cudaLimitPrintfFifoSize: size of the FIFO used by the
     *         printf() device system call.
     *       </li>
     *       <li>cudaLimitMallocHeapSize: size of
     *         the heap used by the malloc() and free() device system
     *         calls;
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorUnsupportedLimit, cudaErrorInvalidValue
     *
     * @see JCuda#cudaDeviceGetLimit
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaThreadGetLimit(long pValue[], int limit)
    {
        return checkResult(cudaThreadGetLimitNative(pValue, limit));
    }
    private static native int cudaThreadGetLimitNative(long pValue[], int limit);


    /**
     * Finds the address associated with a CUDA symbol.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T &gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetSymbolAddress           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const T &amp;&nbsp;</td>
     *         <td> <em>symbol</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*devPtr</code> the address of symbol <code>symbol</code>
     *       on the device. <code>symbol</code> can either be a variable that
     *       resides in global or constant memory space, or it can be a character
     *       string, naming a variable that resides in global or constant memory
     *       space. If <code>symbol</code> cannot be found, or if <code>symbol</code>
     *       is not declared in the global or constant memory space,
     *       <code>*devPtr</code> is unchanged and the error cudaErrorInvalidSymbol
     *       is returned. If there are multiple global or constant variables with
     *       the same string name (from separate files) and the lookup is done via
     *       character string, cudaErrorDuplicateVariableName is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidSymbol, cudaErrorDuplicateVariableName
     *
     *
     * @see JCuda#cudaGetSymbolAddress
     */
    public static int cudaGetSymbolAddress(Pointer devPtr, String symbol)
    {
        return checkResult(cudaGetSymbolAddressNative(devPtr, symbol));
    }
    private static native int cudaGetSymbolAddressNative(Pointer devPtr, String symbol);

    /**
     * Finds the size of the object associated with a CUDA symbol.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T &gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetSymbolSize           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>size</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const T &amp;&nbsp;</td>
     *         <td> <em>symbol</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*size</code> the size of symbol <code>symbol</code>.
     *       <code>symbol</code> can either be a variable that resides in global or
     *       constant memory space, or it can be a character string, naming a
     *       variable that resides in global or constant memory space. If
     *       <code>symbol</code> cannot be found, or if <code>symbol</code> is not
     *       declared in global or constant memory space, <code>*size</code> is
     *       unchanged and the error cudaErrorInvalidSymbol is returned. If there
     *       are multiple global variables with the same string name (from separate
     *       files) and the lookup is done via character string,
     *       cudaErrorDuplicateVariableName is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidSymbol, cudaErrorDuplicateVariableName
     *
     *
     * @see JCuda#cudaGetSymbolAddress
     */
    public static int cudaGetSymbolSize(long size[], String symbol)
    {
        return checkResult(cudaGetSymbolSizeNative(size, symbol));
    }
    private static native int cudaGetSymbolSizeNative(long size[], String symbol);


    /**
     * Binds a memory area to a texture.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T , int dim, enum cudaTextureReadMode readMode&gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaBindTexture           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>offset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct texture&lt; T, dim, readMode &gt;
     *           &amp;&nbsp;
     *         </td>
     *         <td> <em>tex</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaChannelFormatDesc &amp;&nbsp;</td>
     *         <td> <em>desc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>size</em> =
     *           <code>UINT_MAX</code>
     *         </td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Binds <code>size</code> bytes of the memory area pointed to by
     *       <code>devPtr</code> to texture reference <code>tex</code>.
     *       <code>desc</code> describes how the memory is interpreted when fetching
     *       values from the texture. The <code>offset</code> parameter is an
     *       optional byte offset as with the low-level cudaBindTexture() function.
     *       Any memory previously bound to <code>tex</code> is unbound.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidTexture
     *
     * @see JCuda#cudaCreateChannelDesc
     * @see JCuda#cudaGetChannelDesc
     * @see JCuda#cudaGetTextureReference
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaUnbindTexture
     * @see JCuda#cudaGetTextureAlignmentOffset
     */
    public static int cudaBindTexture(long offset[], textureReference texref, Pointer devPtr, cudaChannelFormatDesc desc, long size)
    {
        return checkResult(cudaBindTextureNative(offset, texref, devPtr, desc, size));
    }
    private static native int cudaBindTextureNative(long offset[], textureReference texref, Pointer devPtr, cudaChannelFormatDesc desc, long size);



    /**
     * Binds a 2D memory area to a texture.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T , int dim, enum cudaTextureReadMode readMode&gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaBindTexture2D           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>offset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct texture&lt; T, dim, readMode &gt;
     *           &amp;&nbsp;
     *         </td>
     *         <td> <em>tex</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaChannelFormatDesc &amp;&nbsp;</td>
     *         <td> <em>desc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>pitch</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Binds the 2D memory area pointed to by <code>devPtr</code> to the
     *       texture reference <code>tex</code>. The size of the area is constrained
     *       by <code>width</code> in texel units, <code>height</code> in texel
     *       units, and <code>pitch</code> in byte units. <code>desc</code> describes
     *       how the memory is interpreted when fetching values from the texture.
     *       Any memory previously bound to <code>tex</code> is unbound.
     *     <p>
     *       Since the hardware enforces an alignment requirement on texture base
     *       addresses, cudaBindTexture2D() returns in <code>*offset</code> a byte
     *       offset that must be applied to texture fetches in order to read from
     *       the desired memory. This offset must be divided by the texel size and
     *       passed to kernels that read from the texture so they can be applied to
     *       the tex2D() function. If the device memory pointer was returned from
     *       cudaMalloc(), the offset is guaranteed to be 0 and NULL may be passed
     *       as the <code>offset</code> parameter.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidTexture
     *
     * @see JCuda#cudaCreateChannelDesc
     * @see JCuda#cudaGetChannelDesc
     * @see JCuda#cudaGetTextureReference
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaUnbindTexture
     * @see JCuda#cudaGetTextureAlignmentOffset
     */
    public static int cudaBindTexture2D (long offset[], textureReference texref, Pointer devPtr, cudaChannelFormatDesc desc, long width, long height, long pitch)
    {
        return checkResult(cudaBindTexture2DNative(offset, texref, devPtr, desc, width, height, pitch));
    }
    private static native int cudaBindTexture2DNative(long offset[], textureReference texref, Pointer devPtr, cudaChannelFormatDesc desc, long width, long height, long pitch);



    /**
     * Binds an array to a texture.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T , int dim, enum cudaTextureReadMode readMode&gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaBindTextureToArray           </td>
     *         <td>(</td>
     *         <td>const struct texture&lt; T, dim, readMode &gt;
     *           &amp;&nbsp;
     *         </td>
     *         <td> <em>tex</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>array</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaChannelFormatDesc &amp;&nbsp;</td>
     *         <td> <em>desc</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Binds the CUDA array <code>array</code> to the texture reference
     *       <code>tex</code>. <code>desc</code> describes how the memory is
     *       interpreted when fetching values from the texture. Any CUDA array
     *       previously bound to <code>tex</code> is unbound.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidDevicePointer,
     * cudaErrorInvalidTexture
     *
     * @see JCuda#cudaCreateChannelDesc
     * @see JCuda#cudaGetChannelDesc
     * @see JCuda#cudaGetTextureReference
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaUnbindTexture
     * @see JCuda#cudaGetTextureAlignmentOffset
     */
    public static int cudaBindTextureToArray(textureReference texref, cudaArray array, cudaChannelFormatDesc desc)
    {
        return checkResult(cudaBindTextureToArrayNative(texref, array, desc));
    }
    private static native int cudaBindTextureToArrayNative(textureReference texref, cudaArray array, cudaChannelFormatDesc desc);

    /**
     * Unbinds a texture.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T , int dim, enum cudaTextureReadMode readMode&gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaUnbindTexture           </td>
     *         <td>(</td>
     *         <td>const struct texture&lt; T, dim, readMode &gt;
     *           &amp;&nbsp;
     *         </td>
     *         <td> <em>tex</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Unbinds the texture bound to <code>tex</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaCreateChannelDesc
     * @see JCuda#cudaGetChannelDesc
     * @see JCuda#cudaGetTextureReference
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaUnbindTexture
     * @see JCuda#cudaGetTextureAlignmentOffset
     */
    public static int cudaUnbindTexture(textureReference texref)
    {
        return checkResult(cudaUnbindTextureNative(texref));
    }
    private static native int cudaUnbindTextureNative(textureReference texref);

    /**
     * Get the alignment offset of a texture.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T , int dim, enum cudaTextureReadMode readMode&gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetTextureAlignmentOffset          </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>offset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct texture&lt; T, dim, readMode &gt;
     *           &amp;&nbsp;
     *         </td>
     *         <td> <em>tex</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*offset</code> the offset that was returned when
     *       texture reference <code>tex</code> was bound.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidTexture, cudaErrorInvalidTextureBinding
     *
     *
     * @see JCuda#cudaCreateChannelDesc
     * @see JCuda#cudaGetChannelDesc
     * @see JCuda#cudaGetTextureReference
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaUnbindTexture
     * @see JCuda#cudaGetTextureAlignmentOffset
     */
    public static int cudaGetTextureAlignmentOffset(long offset[], textureReference texref)
    {
        return checkResult(cudaGetTextureAlignmentOffsetNative(offset, texref));
    }
    private static native int cudaGetTextureAlignmentOffsetNative(long offset[], textureReference texref);

    /**
     * Get the texture reference associated with a symbol.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetTextureReference           </td>
     *         <td>(</td>
     *         <td>const struct textureReference **&nbsp;</td>
     *         <td> <em>texref</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>symbol</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*texref</code> the structure associated to the texture
     *       reference defined by symbol <code>symbol</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidTexture
     *
     * @see JCuda#cudaCreateChannelDesc
     * @see JCuda#cudaGetChannelDesc
     * @see JCuda#cudaGetTextureAlignmentOffset
     * @see JCuda#cudaBindTexture
     * @see JCuda#cudaBindTexture2D
     * @see JCuda#cudaBindTextureToArray
     * @see JCuda#cudaUnbindTexture
     */
    public static int cudaGetTextureReference(textureReference texref, String symbol)
    {
        return checkResult(cudaGetTextureReferenceNative(texref, symbol));
    }
    private static native int cudaGetTextureReferenceNative(textureReference texref, String symbol);


    /**
     * Binds an array to a surface.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T , int dim&gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaBindSurfaceToArray           </td>
     *         <td>(</td>
     *         <td>const struct surface&lt; T, dim &gt; &amp;&nbsp;</td>
     *         <td> <em>surf</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaArray *&nbsp;</td>
     *         <td> <em>array</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const struct cudaChannelFormatDesc &amp;&nbsp;</td>
     *         <td> <em>desc</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Binds the CUDA array <code>array</code> to the surface reference
     *       <code>surf</code>. <code>desc</code> describes how the memory is
     *       interpreted when dealing with the surface. Any CUDA array previously
     *       bound to <code>surf</code> is unbound.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidSurface
     *
     * @see JCuda#cudaBindSurfaceToArray
     * @see JCuda#cudaBindSurfaceToArray
     */
    public static int cudaBindSurfaceToArray(surfaceReference surfref, cudaArray array, cudaChannelFormatDesc desc)
    {
        return checkResult(cudaBindSurfaceToArrayNative(surfref, array, desc));
    }
    private static native int cudaBindSurfaceToArrayNative(surfaceReference surfref, cudaArray array, cudaChannelFormatDesc desc);


    /**
     * Get the surface reference associated with a symbol.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGetSurfaceReference           </td>
     *         <td>(</td>
     *         <td>const struct surfaceReference **&nbsp;</td>
     *         <td> <em>surfref</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>symbol</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*surfref</code> the structure associated to the
     *       surface reference defined by symbol <code>symbol</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidSurface
     *
     * @see JCuda#cudaBindSurfaceToArray
     */
    public static int cudaGetSurfaceReference(surfaceReference surfref, String symbol)
    {
        return checkResult(cudaGetSurfaceReferenceNative(surfref, symbol));
    }
    private static native int cudaGetSurfaceReferenceNative(surfaceReference surfref, String symbol);



    /**
     * Configure a device-launch.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaConfigureCall           </td>
     *         <td>(</td>
     *         <td>dim3&nbsp;</td>
     *         <td> <em>gridDim</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>dim3&nbsp;</td>
     *         <td> <em>blockDim</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>sharedMem</em> = <code>0</code>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Specifies the grid and block dimensions for the device call to be
     *       executed similar to the execution configuration syntax.
     *       cudaConfigureCall() is stack based. Each call pushes data on top of an
     *       execution stack. This data contains the dimension for the grid and
     *       thread blocks, together with any arguments for the call.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidConfiguration
     *
     * @see JCuda#cudaDeviceSetCacheConfig
     * @see JCuda#cudaFuncGetAttributes
     * @see JCuda#cudaLaunch
     * @see JCuda#cudaSetupArgument
     */
    public static int cudaConfigureCall(dim3 gridDim, dim3 blockDim, long sharedMem, cudaStream_t stream)
    {
        return checkResult(cudaConfigureCallNative(gridDim, blockDim, sharedMem, stream));
    }
    private static native int cudaConfigureCallNative(dim3 gridDim, dim3 blockDim, long sharedMem, cudaStream_t stream);

    /**
     * Configure a device launch.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T &gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaSetupArgument           </td>
     *         <td>(</td>
     *         <td>T&nbsp;</td>
     *         <td> <em>arg</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>offset</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Pushes <code>size</code> bytes of the argument pointed to by
     *       <code>arg</code> at <code>offset</code> bytes from the start of the
     *       parameter passing area, which starts at offset 0. The arguments are
     *       stored in the top of the execution stack. cudaSetupArgument() must be
     *       preceded by a call to cudaConfigureCall().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaConfigureCall
     * @see JCuda#cudaFuncGetAttributes
     * @see JCuda#cudaLaunch
     * @see JCuda#cudaSetupArgument
     */
    public static int cudaSetupArgument(Pointer arg, long size, long offset)
    {
        return checkResult(cudaSetupArgumentNative(arg, size, offset));
    }
    private static native int cudaSetupArgumentNative(Pointer arg, long size, long offset);


    /**
     * Find out attributes for a given function.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T &gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaFuncGetAttributes           </td>
     *         <td>(</td>
     *         <td>struct cudaFuncAttributes *&nbsp;</td>
     *         <td> <em>attr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>T *&nbsp;</td>
     *         <td> <em>entry</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       This function obtains the attributes of a function specified via
     *       <code>entry</code>. The parameter <code>entry</code> can either be a
     *       pointer to a function that executes on the device, or it can be a
     *       character string specifying the fully-decorated (C++) name of a function
     *       that executes on the device. The parameter specified by <code>entry</code>
     *       must be declared as a <code>__global__</code> function. The fetched
     *       attributes are placed in <code>attr</code>. If the specified function
     *       does not exist, then cudaErrorInvalidDeviceFunction is returned.
     *     <p>
     *       Note that some function attributes such as maxThreadsPerBlock may vary
     *       based on the device that is currently being used.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError,
     * cudaErrorInvalidDeviceFunction
     *
     * @see JCuda#cudaConfigureCall
     * @see JCuda#cudaDeviceSetCacheConfig
     * @see JCuda#cudaFuncGetAttributes
     * @see JCuda#cudaLaunch
     * @see JCuda#cudaSetupArgument
     */
    public static int cudaFuncGetAttributes (cudaFuncAttributes attr, String func)
    {
        return checkResult(cudaFuncGetAttributesNative(attr, func));
    }
    private static native int cudaFuncGetAttributesNative(cudaFuncAttributes attr, String func);



    /**
     * Launches a device function.
     *
     * <div>
     *   <div>
     *     <div>
     *       template&lt;class T &gt;
     *     </div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaLaunch           </td>
     *         <td>(</td>
     *         <td>T *&nbsp;</td>
     *         <td> <em>entry</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Launches the function <code>entry</code> on the device. The parameter
     *       <code>entry</code> can either be a function that executes on the
     *       device, or it can be a character string, naming a function that executes
     *       on the device. The parameter specified by <code>entry</code> must be
     *       declared as a <code>__global__</code> function. cudaLaunch() must be
     *       preceded by a call to cudaConfigureCall() since it pops the data that
     *       was pushed by cudaConfigureCall() from the execution stack.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDeviceFunction,
     * cudaErrorInvalidConfiguration, cudaErrorLaunchFailure,
     * cudaErrorLaunchTimeout, cudaErrorLaunchOutOfResources,
     * cudaErrorSharedObjectSymbolNotFound, cudaErrorSharedObjectInitFailed
     *
     * @see JCuda#cudaConfigureCall
     * @see JCuda#cudaDeviceSetCacheConfig
     * @see JCuda#cudaFuncGetAttributes
     * @see JCuda#cudaLaunch
     * @see JCuda#cudaSetupArgument
     * @see JCuda#cudaThreadGetCacheConfig
     * @see JCuda#cudaThreadSetCacheConfig
     */
    public static int cudaLaunch(String symbol)
    {
        return checkResult(cudaLaunchNative(symbol));
    }
    private static native int cudaLaunchNative(String symbol);




    /**
     * Sets the CUDA device for use with OpenGL interoperability.
     * 
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGLSetGLDevice           </td>
     *         <td>(</td>
     *         <td>int&nbsp;</td>
     *         <td> <em>device</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Records <code>device</code> as the device on which the active host
     *       thread executes the device code. Records the thread as using OpenGL
     *       interoperability. If the host thread has already initialized the CUDA
     *       runtime by calling non-device management runtime functions or if there
     *       exists a CUDA driver context active on the host thread, then this call
     *       returns cudaErrorSetOnActiveProcess.
     *     <p>
     *   </div>
     * </div>
     * 
     * @return cudaSuccess, cudaErrorInvalidDevice, cudaErrorSetOnActiveProcess
     * 
     * 
     * @see JCuda#cudaGLRegisterBufferObject
     * @see JCuda#cudaGLMapBufferObject
     * @see JCuda#cudaGLUnmapBufferObject
     * @see JCuda#cudaGLUnregisterBufferObject
     * @see JCuda#cudaGLMapBufferObjectAsync
     * @see JCuda#cudaGLUnmapBufferObjectAsync
     */
    public static int cudaGLSetGLDevice(int device)
    {
        return checkResult(cudaGLSetGLDeviceNative(device));
    }
    private static native int cudaGLSetGLDeviceNative(int device);

    /**
     * Register an OpenGL texture or renderbuffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGraphicsGLRegisterImage           </td>
     *         <td>(</td>
     *         <td>struct cudaGraphicsResource **&nbsp;</td>
     *         <td> <em>resource</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>image</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLenum&nbsp;</td>
     *         <td> <em>target</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Registers the texture or renderbuffer object specified by
     *       <code>image</code> for access by CUDA. <code>target</code> must match
     *       the type of the object. A handle to the registered object is returned
     *       as <code>resource</code>. The register flags <code>flags</code> specify
     *       the intended usage, as follows:
     *     <p>
     *     <ul>
     *       <li>cudaGraphicsRegisterFlagsNone: Specifies no hints about how this
     *         resource will be used. It is therefore assumed that this resource will
     *         be read from and written to by CUDA. This is the default
     *         value.
     *       </li>
     *       <li>cudaGraphicsRegisterFlagsReadOnly: Specifies that CUDA
     *         will not write to this resource.
     *       </li>
     *       <li>cudaGraphicsRegisterFlagsWriteDiscard:
     *         Specifies that CUDA will not read from this resource and will write
     *         over the entire contents of the resource, so none of the data previously
     *         stored in the resource will be
     *         preserved.
     *       </li>
     *       <li>cudaGraphicsRegisterFlagsSurfaceLoadStore: Specifies
     *         that CUDA will bind this resource to a surface reference.
     *       </li>
     *     </ul>
     *     <p>
     *       The following image classes are currently disallowed:
     *     <ul>
     *       <li>Textures with borders</li>
     *       <li>Multisampled renderbuffers</li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevice, cudaErrorInvalidValue,
     * cudaErrorInvalidResourceHandle, cudaErrorUnknown
     *
     * @see JCuda#cudaGLSetGLDevice
     * @see JCuda#cudaGraphicsMapResources
     * @see JCuda#cudaGraphicsSubResourceGetMappedArray
     */
    public static int cudaGraphicsGLRegisterImage(cudaGraphicsResource resource, int image, int target, int Flags)
    {
        return checkResult(cudaGraphicsGLRegisterImageNative(resource, image, target, Flags));
    }

    private static native int cudaGraphicsGLRegisterImageNative(cudaGraphicsResource resource, int image, int target, int Flags);


    /**
     * Registers an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGraphicsGLRegisterBuffer          </td>
     *         <td>(</td>
     *         <td>struct cudaGraphicsResource **&nbsp;</td>
     *         <td> <em>resource</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Registers the buffer object specified by <code>buffer</code> for access
     *       by CUDA. A handle to the registered object is returned as
     *       <code>resource</code>. The register flags <code>flags</code> specify
     *       the intended usage, as follows:
     *     <p>
     *     <ul>
     *       <li>cudaGraphicsRegisterFlagsNone: Specifies no hints about how this
     *         resource will be used. It is therefore assumed that this resource will
     *         be read from and written to by CUDA. This is the default
     *         value.
     *       </li>
     *       <li>cudaGraphicsRegisterFlagsReadOnly: Specifies that CUDA
     *         will not write to this resource.
     *       </li>
     *       <li>cudaGraphicsRegisterFlagsWriteDiscard:
     *         Specifies that CUDA will not read from this resource and will write
     *         over the entire contents of the resource, so none of the data previously
     *         stored in the resource will be preserved.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevice, cudaErrorInvalidValue,
     * cudaErrorInvalidResourceHandle, cudaErrorUnknown
     *
     * @see JCuda#cudaGraphicsUnregisterResource
     * @see JCuda#cudaGraphicsMapResources
     * @see JCuda#cudaGraphicsResourceGetMappedPointer
     */
    public static int cudaGraphicsGLRegisterBuffer(cudaGraphicsResource resource, int buffer, int Flags)
    {
        return checkResult(cudaGraphicsGLRegisterBufferNative(resource, buffer, Flags));
    }

    private static native int cudaGraphicsGLRegisterBufferNative(cudaGraphicsResource resource, int buffer, int Flags);




    /**
     * Registers a buffer object for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGLRegisterBufferObject           </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>bufObj</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Registers the buffer object of ID <code>bufObj</code> for access by
     *     CUDA. This function must be called before CUDA can map the buffer
     *     object. The OpenGL context used to create the buffer, or another
     *     context from the same share group, must be bound to the current thread
     *     when this is called.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInitializationError
     *
     * @see JCuda#cudaGraphicsGLRegisterBuffer
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaGLRegisterBufferObject(int bufObj)
    {
        return checkResult(cudaGLRegisterBufferObjectNative(bufObj));
    }
    private static native int cudaGLRegisterBufferObjectNative(int bufObj);


    /**
     * Maps a buffer object for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGLMapBufferObject           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>bufObj</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Maps the buffer object of ID <code>bufObj</code> into the address space
     *     of CUDA and returns in <code>*devPtr</code> the base pointer of the
     *     resulting mapping. The buffer must have previously been registered by
     *     calling cudaGLRegisterBufferObject(). While a buffer is mapped by CUDA,
     *     any OpenGL operation which references the buffer will result in
     *     undefined behavior. The OpenGL context used to create the buffer, or
     *     another context from the same share group, must be bound to the current
     *     thread when this is called.
     *     <p>
     *       All streams in the current thread are synchronized with the current GL
     *       context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMapBufferObjectFailed
     *
     * @see JCuda#cudaGraphicsMapResources
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaGLMapBufferObject(Pointer devPtr, int bufObj)
    {
        return checkResult(cudaGLMapBufferObjectNative(devPtr, bufObj));
    }
    private static native int cudaGLMapBufferObjectNative(Pointer devPtr, int bufObj);


    /**
     * Unmaps a buffer object for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGLUnmapBufferObject           </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>bufObj</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Unmaps the buffer object of ID <code>bufObj</code> for access by CUDA.
     *     When a buffer is unmapped, the base address returned by
     *     cudaGLMapBufferObject() is invalid and subsequent references to the
     *     address result in undefined behavior. The OpenGL context used to create
     *     the buffer, or another context from the same share group, must be bound
     *     to the current thread when this is called.
     *     <p>
     *       All streams in the current thread are synchronized with the current GL
     *       context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevicePointer,
     * cudaErrorUnmapBufferObjectFailed
     *
     * @see JCuda#cudaGraphicsUnmapResources
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaGLUnmapBufferObject(int bufObj)
    {
        return checkResult(cudaGLUnmapBufferObjectNative(bufObj));
    }
    private static native int cudaGLUnmapBufferObjectNative(int bufObj);


    /**
     * Unregisters a buffer object for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGLUnregisterBufferObject          </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>bufObj</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Unregisters the buffer object of ID <code>bufObj</code> for access by
     *     CUDA and releases any CUDA resources associated with the buffer. Once
     *     a buffer is unregistered, it may no longer be mapped by CUDA. The GL
     *     context used to create the buffer, or another context from the same
     *     share group, must be bound to the current thread when this is
     *     called.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess
     *
     * @see JCuda#cudaGraphicsUnregisterResource
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaGLUnregisterBufferObject(int bufObj)
    {
        return checkResult(cudaGLUnregisterBufferObjectNative(bufObj));
    }
    private static native int cudaGLUnregisterBufferObjectNative(int bufObj);



    /**
     * Set usage flags for mapping an OpenGL buffer.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGLSetBufferObjectMapFlags          </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>bufObj</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Set flags for mapping the OpenGL buffer <code>bufObj</code>
     *     <p>
     *       Changes to flags will take effect the next time <code>bufObj</code> is
     *       mapped. The <code>flags</code> argument may be any of the
     *       following:
     *     <p>
     *     <ul>
     *       <li>cudaGLMapFlagsNone: Specifies no hints about how this buffer will
     *         be used. It is therefore assumed that this buffer will be read from
     *         and written to by CUDA kernels. This is the default
     *         value.
     *       </li>
     *       <li>cudaGLMapFlagsReadOnly: Specifies that CUDA kernels
     *         which access this buffer will not write to the
     *         buffer.
     *       </li>
     *       <li>cudaGLMapFlagsWriteDiscard: Specifies that CUDA kernels
     *         which access this buffer will not read from the buffer and will write
     *         over the entire contents of the buffer, so none of the data previously
     *         stored in the buffer will be preserved.
     *       </li>
     *     </ul>
     *     <p>
     *       If <code>bufObj</code> has not been registered for use with CUDA, then
     *       cudaErrorInvalidResourceHandle is returned. If <code>bufObj</code> is
     *       presently mapped for access by CUDA, then cudaErrorUnknown is
     *       returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidResourceHandle,
     * cudaErrorUnknown
     *
     * @see JCuda#cudaGraphicsResourceSetMapFlags
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaGLSetBufferObjectMapFlags(int bufObj, int flags)
    {
        return checkResult(cudaGLSetBufferObjectMapFlagsNative(bufObj, flags));
    }

    private static native int cudaGLSetBufferObjectMapFlagsNative(int bufObj, int flags);;


    /**
     * Maps a buffer object for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGLMapBufferObjectAsync           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>bufObj</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Maps the buffer object of ID <code>bufObj</code> into the address space
     *     of CUDA and returns in <code>*devPtr</code> the base pointer of the
     *     resulting mapping. The buffer must have previously been registered by
     *     calling cudaGLRegisterBufferObject(). While a buffer is mapped by CUDA,
     *     any OpenGL operation which references the buffer will result in
     *     undefined behavior. The OpenGL context used to create the buffer, or
     *     another context from the same share group, must be bound to the current
     *     thread when this is called.
     *     <p>
     *       Stream /p stream is synchronized with the current GL context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorMapBufferObjectFailed
     *
     * @see JCuda#cudaGraphicsMapResources
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaGLMapBufferObjectAsync(Pointer devPtr, int bufObj, cudaStream_t stream)
    {
        return checkResult(cudaGLMapBufferObjectAsyncNative(devPtr, bufObj, stream));
    }

    private static native int cudaGLMapBufferObjectAsyncNative(Pointer devPtr, int bufObj, cudaStream_t stream);

    /**
     * Unmaps a buffer object for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGLUnmapBufferObjectAsync          </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>bufObj</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Unmaps the buffer object of ID <code>bufObj</code> for access by CUDA.
     *     When a buffer is unmapped, the base address returned by
     *     cudaGLMapBufferObject() is invalid and subsequent references to the
     *     address result in undefined behavior. The OpenGL context used to create
     *     the buffer, or another context from the same share group, must be bound
     *     to the current thread when this is called.
     *     <p>
     *       Stream /p stream is synchronized with the current GL context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevicePointer,
     * cudaErrorUnmapBufferObjectFailed
     *
     * @see JCuda#cudaGraphicsUnmapResources
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cudaGLUnmapBufferObjectAsync(int bufObj, cudaStream_t stream)
    {
        return checkResult(cudaGLUnmapBufferObjectAsyncNative(bufObj, stream));
    }

    private static native int cudaGLUnmapBufferObjectAsyncNative(int bufObj, cudaStream_t stream);






    /**
     * Returns the CUDA driver version.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDriverGetVersion           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>driverVersion</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*driverVersion</code> the version number of the
     *       installed CUDA driver. If no driver is installed, then 0 is returned
     *       as the driver version (via <code>driverVersion</code>). This function
     *       automatically returns cudaErrorInvalidValue if the
     *       <code>driverVersion</code> argument is NULL.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue
     *
     * @see JCuda#cudaRuntimeGetVersion
     */
    public static int cudaDriverGetVersion(int driverVersion[])
    {
        return checkResult(cudaDriverGetVersionNative(driverVersion));
    }
    private static native int cudaDriverGetVersionNative(int driverVersion[]);

    /**
     * Returns the CUDA Runtime version.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaRuntimeGetVersion           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>runtimeVersion</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*runtimeVersion</code> the version number of the
     *       installed CUDA Runtime. This function automatically returns
     *       cudaErrorInvalidValue if the <code>runtimeVersion</code> argument is
     *       NULL.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue
     *
     * @see JCuda#cudaDriverGetVersion
     */
    public static int cudaRuntimeGetVersion(int runtimeVersion[])
    {
        return checkResult(cudaRuntimeGetVersionNative(runtimeVersion));
    }
    private static native int cudaRuntimeGetVersionNative(int runtimeVersion[]);





    /**
     * Returns attributes about a specified pointer.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaPointerGetAttributes           </td>
     *         <td>(</td>
     *         <td>struct cudaPointerAttributes *&nbsp;</td>
     *         <td> <em>attributes</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>ptr</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*attributes</code> the attributes of the pointer
     *       <code>ptr</code>.
     *     <p>
     *       The cudaPointerAttributes structure is defined as:
     *     <div>
     *       <pre>
     * <span>struct </span>cudaPointerAttributes {
     *         <span>enum</span> cudaMemoryType memoryType;
     *         <span>int</span> device;
     *         <span>void</span> *devicePointer;
     *         <span>void</span> *hostPointer;
     *     }
     * </pre>
     *     </div>
     *     In this structure, the individual fields mean
     *     <p>
     *     <ul>
     *       <li>memoryType identifies the physical location of the memory associated
     *         with pointer <code>ptr</code>. It can be cudaMemoryTypeHost for host
     *         memory or cudaMemoryTypeDevice for device memory.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>device is the device against which <code>ptr</code> was allocated.
     *         If <code>ptr</code> has memory type cudaMemoryTypeDevice then this
     *         identifies the device on which the memory referred to by <code>ptr</code>
     *         physically resides. If <code>ptr</code> has memory type cudaMemoryTypeHost
     *         then this identifies the device which was current when the allocation
     *         was made (and if that device is deinitialized then this allocation will
     *         vanish with that device's state).
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>devicePointer is the device pointer alias through which the memory
     *         referred to by <code>ptr</code> may be accessed on the current device.
     *         If the memory referred to by <code>ptr</code> cannot be accessed
     *         directly by the current device then this is NULL.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>hostPointer is the host pointer alias through which the memory
     *         referred to by <code>ptr</code> may be accessed on the host. If the
     *         memory referred to by <code>ptr</code> cannot be accessed directly by
     *         the host then this is NULL.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevice
     *
     * @see JCuda#cudaGetDeviceCount
     * @see JCuda#cudaGetDevice
     * @see JCuda#cudaSetDevice
     * @see JCuda#cudaChooseDevice
     */
    public static int cudaPointerGetAttributes(cudaPointerAttributes attributes, Pointer ptr)
    {
        return checkResult(cudaPointerGetAttributesNative(attributes, ptr));
    }
    private static native int cudaPointerGetAttributesNative(cudaPointerAttributes attributes, Pointer ptr);

    /**
     * Queries if a device may directly access a peer device's memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceCanAccessPeer           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>canAccessPeer</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>device</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>peerDevice</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*canAccessPeer</code> a value of 1 if device
     *       <code>device</code> is capable of directly accessing memory from
     *       <code>peerDevice</code> and 0 otherwise. If direct access of
     *       <code>peerDevice</code> from <code>device</code> is possible, then
     *       access may be enabled by calling cudaDeviceEnablePeerAccess().
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevice
     *
     * @see JCuda#cudaDeviceEnablePeerAccess
     * @see JCuda#cudaDeviceDisablePeerAccess
     */
    public static int cudaDeviceCanAccessPeer(int canAccessPeer[], int device, int peerDevice)
    {
        return checkResult(cudaDeviceCanAccessPeerNative(canAccessPeer, device, peerDevice));
    }
    private static native int cudaDeviceCanAccessPeerNative(int canAccessPeer[], int device, int peerDevice);

    /**
     * Enables direct access to memory allocations on a peer device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceEnablePeerAccess           </td>
     *         <td>(</td>
     *         <td>int&nbsp;</td>
     *         <td> <em>peerDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Enables registering memory on <code>peerDevice</code> for direct access
     *       from the current device. On success, allocations on <code>peerDevice</code>
     *       may be registered for access from the current device using
     *       cudaPeerRegister(). Registering peer memory will be possible until it
     *       is explicitly disabled using cudaDeviceDisablePeerAccess(), or either
     *       the current device or <code>peerDevice</code> is reset using
     *       cudaDeviceReset().
     *     <p>
     *       If both the current device and <code>peerDevice</code> support unified
     *       addressing then all allocations from <code>peerDevice</code> will
     *       immediately be accessible by the current device upon success. In this
     *       case, explicitly sharing allocations using cudaPeerRegister() is not
     *       necessary.
     *     <p>
     *       Note that access granted by this call is unidirectional and that in
     *       order to access memory on the current device from <code>peerDevice</code>,
     *       a separate symmetric call to cudaDeviceEnablePeerAccess() is
     *       required.
     *     <p>
     *       Returns cudaErrorInvalidDevice if cudaDeviceCanAccessPeer() indicates
     *       that the current device cannot directly access memory from
     *       <code>peerDevice</code>.
     *     <p>
     *       Returns cudaErrorPeerAccessAlreadyEnabled if direct access of
     *       <code>peerDevice</code> from the current device has already been
     *       enabled.
     *     <p>
     *       Returns cudaErrorInvalidValue if <code>flags</code> is not 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidDevice cudaErrorPeerAccessAlreadyEnabled,
     * cudaErrorInvalidValue
     *
     * @see JCuda#cudaDeviceCanAccessPeer
     * @see JCuda#cudaDeviceDisablePeerAccess
     */
    public static int cudaDeviceEnablePeerAccess(int peerDevice, int flags)
    {
        return checkResult(cudaDeviceEnablePeerAccessNative(peerDevice, flags));
    }
    private static native int cudaDeviceEnablePeerAccessNative(int peerDevice, int flags);


    /**
     * Disables direct access to memory allocations on a peer device and
     * unregisters any registered allocations from that device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaDeviceDisablePeerAccess           </td>
     *         <td>(</td>
     *         <td>int&nbsp;</td>
     *         <td> <em>peerDevice</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Disables registering memory on <code>peerDevice</code> for direct
     *       access from the current device. If there are any allocations on
     *       <code>peerDevice</code> which were registered in the current device
     *       using cudaPeerRegister() then these allocations will be automatically
     *       unregistered.
     *     <p>
     *       Returns cudaErrorPeerAccessNotEnabled if direct access to memory on
     *       <code>peerDevice</code> has not yet been enabled from the current
     *       device.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorPeerAccessNotEnabled, cudaErrorInvalidDevice
     *
     *
     * @see JCuda#cudaDeviceCanAccessPeer
     * @see JCuda#cudaDeviceEnablePeerAccess
     */
    public static int cudaDeviceDisablePeerAccess(int peerDevice)
    {
        return checkResult(cudaDeviceDisablePeerAccessNative(peerDevice));
    }
    private static native int cudaDeviceDisablePeerAccessNative(int peerDevice);


    /**
     * @deprecated This function has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2. In the current release,
     * it will throw an UnsupportedOperationException. 
     */
    public static int cudaPeerRegister(Pointer peerDevicePointer, int peerDevice, int flags)
    {
        if (true)
        {
            // TODO: If this function is not available in CUDA 4.0 /final/,
            // then remove the native binding
            throw new UnsupportedOperationException(
                "This function is not available in CUDA 4.0 RC2");
        }
        return checkResult(cudaPeerRegisterNative(peerDevicePointer, peerDevice, flags));
    }
    private static native int cudaPeerRegisterNative(Pointer peerDevicePointer, int peerDevice, int flags);


    /**
     * @deprecated This function has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2. In the current release,
     * it will throw an UnsupportedOperationException. 
     */
    public static int cudaPeerUnregister(Pointer peerDevicePointer, int peerDevice)
    {
        if (true)
        {
            // TODO: If this function is not available in CUDA 4.0 /final/,
            // then remove the native binding
            throw new UnsupportedOperationException(
                "This function is not available in CUDA 4.0 RC2");
        }
        return checkResult(cudaPeerUnregisterNative(peerDevicePointer, peerDevice));
    }
    private static native int cudaPeerUnregisterNative(Pointer peerDevicePointer, int peerDevice);


    /**
     * @deprecated This function has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2. In the current release,
     * it will throw an UnsupportedOperationException. 
     */
    public static int cudaPeerGetDevicePointer(Pointer pDevice, Pointer peerDevicePointer, int peerDevice, int flags)
    {
        if (true)
        {
            // TODO: If this function is not available in CUDA 4.0 /final/,
            // then remove the native binding
            throw new UnsupportedOperationException(
                "This function is not available in CUDA 4.0 RC2");
        }
        return checkResult(cudaPeerGetDevicePointerNative(pDevice, peerDevicePointer, peerDevice, flags));
    }
    private static native int cudaPeerGetDevicePointerNative(Pointer pDevice, Pointer peerDevicePointer, int peerDevice, int flags);



    /**
     * Unregisters a graphics resource for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGraphicsUnregisterResource          </td>
     *         <td>(</td>
     *         <td>cudaGraphicsResource_t&nbsp;</td>
     *         <td> <em>resource</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Unregisters the graphics resource <code>resource</code> so it is not
     *       accessible by CUDA unless registered again.
     *     <p>
     *       If <code>resource</code> is invalid then cudaErrorInvalidResourceHandle
     *       is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidResourceHandle, cudaErrorUnknown
     *
     * @see JCuda#cudaGraphicsGLRegisterBuffer
     * @see JCuda#cudaGraphicsGLRegisterImage
     */
    public static int cudaGraphicsUnregisterResource(cudaGraphicsResource resource)
    {
        return checkResult(cudaGraphicsUnregisterResourceNative(resource));
    }

    private static native int cudaGraphicsUnregisterResourceNative(cudaGraphicsResource resource);


    /**
     * Set usage flags for mapping a graphics resource.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGraphicsResourceSetMapFlags          </td>
     *         <td>(</td>
     *         <td>cudaGraphicsResource_t&nbsp;</td>
     *         <td> <em>resource</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Set <code>flags</code> for mapping the graphics resource
     *       <code>resource</code>.
     *     <p>
     *       Changes to <code>flags</code> will take effect the next time
     *       <code>resource</code> is mapped. The <code>flags</code> argument may
     *       be any of the following:
     *     <ul>
     *       <li>cudaGraphicsMapFlagsNone: Specifies no hints about how
     *         <code>resource</code> will be used. It is therefore assumed that CUDA
     *         may read from or write to
     *         <code>resource</code>.
     *       </li>
     *       <li>cudaGraphicsMapFlagsReadOnly: Specifies
     *         that CUDA will not write to
     *         <code>resource</code>.
     *       </li>
     *       <li>cudaGraphicsMapFlagsWriteDiscard:
     *         Specifies CUDA will not read from <code>resource</code> and will write
     *         over the entire contents of <code>resource</code>, so none of the data
     *         previously stored in <code>resource</code> will be
     *         preserved.
     *       </li>
     *     </ul>
     *     <p>
     *       If <code>resource</code> is presently mapped for access by CUDA then
     *       cudaErrorUnknown is returned. If <code>flags</code> is not one of the
     *       above values then cudaErrorInvalidValue is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidResourceHandle,
     * cudaErrorUnknown,
     *
     * @see JCuda#cudaGraphicsMapResources
     */
    public static int cudaGraphicsResourceSetMapFlags(cudaGraphicsResource resource, int flags)
    {
        return checkResult(cudaGraphicsResourceSetMapFlagsNative(resource, flags));
    }

    private static native int cudaGraphicsResourceSetMapFlagsNative(cudaGraphicsResource resource, int flags);

    /**
     * Map graphics resources for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGraphicsMapResources           </td>
     *         <td>(</td>
     *         <td>int&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaGraphicsResource_t *&nbsp;</td>
     *         <td> <em>resources</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Maps the <code>count</code> graphics resources in <code>resources</code>
     *       for access by CUDA.
     *     <p>
     *       The resources in <code>resources</code> may be accessed by CUDA until
     *       they are unmapped. The graphics API from which <code>resources</code>
     *       were registered should not access any resources while they are mapped
     *       by CUDA. If an application does so, the results are undefined.
     *     <p>
     *       This function provides the synchronization guarantee that any graphics
     *       calls issued before cudaGraphicsMapResources() will complete before
     *       any subsequent CUDA work issued in <code>stream</code> begins.
     *     <p>
     *       If <code>resources</code> contains any duplicate entries then
     *       cudaErrorInvalidResourceHandle is returned. If any of
     *       <code>resources</code> are presently mapped for access by CUDA then
     *       cudaErrorUnknown is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidResourceHandle, cudaErrorUnknown
     *
     * @see JCuda#cudaGraphicsResourceGetMappedPointer
     */
    public static int cudaGraphicsMapResources(int count, cudaGraphicsResource resources[], cudaStream_t stream)
    {
        return checkResult(cudaGraphicsMapResourcesNative(count, resources, stream));
    }

    private static native int cudaGraphicsMapResourcesNative(int count, cudaGraphicsResource resources[], cudaStream_t stream);


    /**
     * Unmap graphics resources.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGraphicsUnmapResources           </td>
     *         <td>(</td>
     *         <td>int&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaGraphicsResource_t *&nbsp;</td>
     *         <td> <em>resources</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaStream_t&nbsp;</td>
     *         <td> <em>stream</em> = <code>0</code></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Unmaps the <code>count</code> graphics resources in
     *       <code>resources</code>.
     *     <p>
     *       Once unmapped, the resources in <code>resources</code> may not be
     *       accessed by CUDA until they are mapped again.
     *     <p>
     *       This function provides the synchronization guarantee that any CUDA work
     *       issued in <code>stream</code> before cudaGraphicsUnmapResources() will
     *       complete before any subsequently issued graphics work begins.
     *     <p>
     *       If <code>resources</code> contains any duplicate entries then
     *       cudaErrorInvalidResourceHandle is returned. If any of
     *       <code>resources</code> are not presently mapped for access by Cuda then
     *       cudaErrorUnknown is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidResourceHandle, cudaErrorUnknown
     *
     * @see JCuda#cudaGraphicsMapResources
     */
    public static int cudaGraphicsUnmapResources(int count, cudaGraphicsResource resources[], cudaStream_t stream)
    {
        return checkResult(cudaGraphicsUnmapResourcesNative(count, resources, stream));
    }

    private static native int cudaGraphicsUnmapResourcesNative(int count, cudaGraphicsResource resources[], cudaStream_t stream);

    /**
     * Get an device pointer through which to access a mapped graphics
     * resource.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGraphicsResourceGetMappedPointer
     *         </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>devPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>size</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaGraphicsResource_t&nbsp;</td>
     *         <td> <em>resource</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*devPtr</code> a pointer through which the mapped
     *       graphics resource <code>resource</code> may be accessed. Returns in
     *       <code>*size</code> the size of the memory in bytes which may be accessed
     *       from that pointer. The value set in <code>devPtr</code> may change
     *       every time that <code>resource</code> is mapped.
     *     <p>
     *       If <code>resource</code> is not a buffer then it cannot be accessed
     *       via a pointer and cudaErrorUnknown is returned. If <code>resource</code>
     *       is not mapped then cudaErrorUnknown is returned. *
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidResourceHandle,
     * cudaErrorUnknown
     *
     * @see JCuda#cudaGraphicsMapResources
     * @see JCuda#cudaGraphicsSubResourceGetMappedArray
     */
    public static int cudaGraphicsResourceGetMappedPointer(Pointer devPtr, long size[], cudaGraphicsResource resource)
    {
        return checkResult(cudaGraphicsResourceGetMappedPointerNative(devPtr, size, resource));
    }

    private static native int cudaGraphicsResourceGetMappedPointerNative(Pointer devPtr, long size[], cudaGraphicsResource resource);

    /**
     * Get an array through which to access a subresource of a mapped graphics
     * resource.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>cudaError_t cudaGraphicsSubResourceGetMappedArray
     *         </td>
     *         <td>(</td>
     *         <td>struct cudaArray **&nbsp;</td>
     *         <td> <em>array</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>cudaGraphicsResource_t&nbsp;</td>
     *         <td> <em>resource</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>arrayIndex</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>mipLevel</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*array</code> an array through which the subresource
     *       of the mapped graphics resource <code>resource</code> which corresponds
     *       to array index <code>arrayIndex</code> and mipmap level
     *       <code>mipLevel</code> may be accessed. The value set in <code>array</code>
     *       may change every time that <code>resource</code> is mapped.
     *     <p>
     *       If <code>resource</code> is not a texture then it cannot be accessed
     *       via an array and cudaErrorUnknown is returned. If <code>arrayIndex</code>
     *       is not a valid array index for <code>resource</code> then
     *       cudaErrorInvalidValue is returned. If <code>mipLevel</code> is not a
     *       valid mipmap level for <code>resource</code> then cudaErrorInvalidValue
     *       is returned. If <code>resource</code> is not mapped then cudaErrorUnknown
     *       is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return cudaSuccess, cudaErrorInvalidValue, cudaErrorInvalidResourceHandle,
     * cudaErrorUnknown
     *
     * @see JCuda#cudaGraphicsResourceGetMappedPointer
     */
    public static int cudaGraphicsSubResourceGetMappedArray(cudaArray arrayPtr, cudaGraphicsResource resource, int arrayIndex, int mipLevel)
    {
        return checkResult(cudaGraphicsSubResourceGetMappedArrayNative(arrayPtr, resource, arrayIndex, mipLevel));
    }

    private static native int cudaGraphicsSubResourceGetMappedArrayNative(cudaArray arrayPtr, cudaGraphicsResource resource, int arrayIndex, int mipLevel);




    /**
     * Initialize the profiling.<br />
     * <br />
     * cudaProfilerInitialize is used to programmatically initialize the profiling. Using
     * this API user can specify config file, output file and output file format. This
     * API is generally used to profile different set of counters by looping the kernel launch. configFile
     * parameter can be used to load new set of counters for profiling.<br />
     * <br />
     * Configurations defined initially by environment variable settings are overwritten
     * by cudaProfilerInitialize().<br />
     * <br />
     * Limitation: Profiling APIs do not work when the application is running with any profiler tool.
     * User must handle error CUDA_ERROR_PROFILER_DISABLED returned by profiler APIs if
     * application is likely to be used with any profiler tool.<br />
     * <br />
     * @param configFile Name of the config file that lists the counters for profiling.
     * @param outputFile Name of the outputFile where the profiling results will be stored.
     * @param outputMode outputMode, can be CU_OUT_KEY_VALUE_PAIR or CU_OUT_CSV.
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_PROFILER_DISABLED
     *
     * @see JCuda#cudaProfilerStart
     * @see JCuda#cudaProfilerStop
     */
    public static int cudaProfilerInitialize(String configFile, String outputFile, int outputMode)
    {
        return checkResult(cudaProfilerInitializeNative(configFile, outputFile, outputMode));
    }
    private static native int cudaProfilerInitializeNative(String configFile, String outputFile, int outputMode);

    /**
     * Start the profiling.<br />
     * <br />
     * cudaProfilerStart/cudaProfilerStop is used to programmatically control the profiling duration.
     * APIs give added benefit of controlling the profiling granularity i.e. allow profiling to be
     * done only on selective pieces of code.<br />
     * <br />
     * cudaProfilerStart() can also be used to selectively start profiling on a particular context even
     * when profiling is NOT ENABLED using environment variable. Profiling structures must be initialized
     * using cudaProfilerInitialize() before making a call to cudaProfilerStart().<br />
     * <br />
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_PROFILER_DISABLED,
     * CUDA_ERROR_PROFILER_ALREADY_STARTED
     *
     * @see JCuda#cudaProfilerInitialize
     * @see JCuda#cudaProfilerStop
     */
    public static int cudaProfilerStart()
    {
        return checkResult(cudaProfilerStartNative());
    }
    private static native int cudaProfilerStartNative();

    /**
     * Stop the profiling. <br />
     * <br />
     * This API can be used in conjunction with cudaProfilerStart to selectively profile subsets of the
     * CUDA program.<br />
     * cudaProfilerStop() can also be used to stop profiling for current context even when profiling is
     * NOT ENABLED using environment variable. Profiling structures must be initialized using
     * cudaProfilerInitialize() before making a call to cuProfilerStop().<br />
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_PROFILER_DISABLED,
     * CUDA_ERROR_PROFILER_ALREADY_STOPPED
     *
     * @see JCuda#cudaProfilerInitialize
     * @see JCuda#cudaProfilerStart
     */
    public static int cudaProfilerStop()
    {
        return checkResult(cudaProfilerStopNative());
    }
    private static native int cudaProfilerStopNative();

}



