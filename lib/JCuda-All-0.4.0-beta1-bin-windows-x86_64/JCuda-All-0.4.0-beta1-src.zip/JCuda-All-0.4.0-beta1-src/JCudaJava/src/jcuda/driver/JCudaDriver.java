/*
 * JCuda - Java bindings for NVIDIA CUDA driver and runtime API
 *
 * Copyright (c) 2009-2011 Marco Hutter - http://www.jcuda.org
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

package jcuda.driver;

import jcuda.*;

/**
 * Java bindings for the NVidia CUDA driver API.<br />
 * <br />
 * Most comments are extracted from the CUDA online documentation
 */
public class JCudaDriver
{
    /** The CUDA version */
    public static final int CUDA_VERSION = 4000;

    /**
     * If set, host memory is portable between CUDA contexts.
     * Flag for {@link JCudaDriver#cuMemHostAlloc}
     */
    public static final int CU_MEMHOSTALLOC_PORTABLE = 0x01;

    /**
     * If set, host memory is mapped into CUDA address space and
     * JCudaDriver#cuMemHostGetDevicePointer may be called on the host pointer.
     * Flag for {@link JCudaDriver#cuMemHostAlloc}
     */
    public static final int CU_MEMHOSTALLOC_DEVICEMAP = 0x02;

    /**
     * If set, host memory is allocated as write-combined - fast to write,
     * faster to DMA, slow to read except via SSE4 streaming load instruction
     * (MOVNTDQA).
     * Flag for {@link JCudaDriver#cuMemHostAlloc}
     */
    public static final int CU_MEMHOSTALLOC_WRITECOMBINED = 0x04;

    /**
     * If set, host memory is portable between CUDA contexts.
     * Flag for ::cuMemHostRegister()
     */
    public static final int CU_MEMHOSTREGISTER_PORTABLE   = 0x01;

    /**
     * If set, host memory is mapped into CUDA address space and
     * ::cuMemHostGetDevicePointer() may be called on the host pointer.
     * Flag for ::cuMemHostRegister()
     */
    public static final int CU_MEMHOSTREGISTER_DEVICEMAP  = 0x02;

    /**
     * If set, peer memory is mapped into CUDA address space and
     * ::cuMemPeerGetDevicePointer() may be called on the host pointer.
     * Flag for ::cuMemPeerRegister()
     * @deprecated This value has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2
     */
    public static final int CU_MEMPEERREGISTER_DEVICEMAP  = 0x02;

    /**
     * If set, the CUDA array is a collection of layers, where each layer is either a 1D
     * or a 2D array and the Depth member of CUDA_ARRAY3D_DESCRIPTOR specifies the number
     * of layers, not the depth of a 3D array.
     */
    public static final int CUDA_ARRAY3D_LAYERED = 0x01;

    /**
     * If set, the CUDA array contains an array of 2D slices
     * and the Depth member of CUDA_ARRAY3D_DESCRIPTOR specifies
     * the number of slices, not the depth of a 3D array.
     * @deprecated use CUDA_ARRAY3D_LAYERED
     */
    public static final int CUDA_ARRAY3D_2DARRAY = 0x01;


    /**
     * This flag must be set in order to bind a surface reference
     * to the CUDA array
     */
    public static final int CUDA_ARRAY3D_SURFACE_LDST =  0x02;

    /**
     * For texture references loaded into the module, use default
     * texunit from texture reference
     */
    public static final int CU_PARAM_TR_DEFAULT = -1;

    /**
     * Override the texref format with a format inferred from the array
     */
    public static final int CU_TRSA_OVERRIDE_FORMAT = 0x01;

    /**
     * Read the texture as integers rather than promoting the values
     * to floats in the range [0,1]
     */
    public static final int CU_TRSF_READ_AS_INTEGER = 0x01;

    /**
     * Use normalized texture coordinates in the range [0,1) instead of [0,dim)
     */
    public static final int CU_TRSF_NORMALIZED_COORDINATES = 0x02;

    /**
     * Perform sRGB->linear conversion during texture read.
     * Flag for JCudaDriver#cuTexRefSetFlags()
     */
    public static final int CU_TRSF_SRGB  = 0x10;


    /**
     * Private inner class for the constant pointer values
     * CU_LAUNCH_PARAM_END, CU_LAUNCH_PARAM_BUFFER_POINTER,
     * and CU_LAUNCH_PARAM_BUFFER_SIZE.
     *
     * TODO: These constants could be misused: There is no
     * mechanism for preventing these Pointers to be used
     * for memory allocation. However, at the moment there
     * is no other way for emulating these pointer constants.
     */
    private static class ConstantPointer extends Pointer
    {
        private ConstantPointer(long value)
        {
            super(value);
        }
    }

    /**
     * End of array terminator for the \p extra parameter to
     * ::cuLaunchKernel
     */
    public static final Pointer CU_LAUNCH_PARAM_END = new ConstantPointer(0); // ((void*)0x00)


    /**
     * Indicator that the next value in the \p extra parameter to
     * ::cuLaunchKernel will be a pointer to a buffer containing all kernel
     * parameters used for launching kernel \p f.  This buffer needs to
     * honor all alignment/padding requirements of the individual parameters.
     * If ::CU_LAUNCH_PARAM_BUFFER_SIZE is not also specified in the
     * \p extra array, then ::CU_LAUNCH_PARAM_BUFFER_POINTER will have no
     * effect.
     */
    public static final Pointer CU_LAUNCH_PARAM_BUFFER_POINTER = new ConstantPointer(1); //((void*)0x01)

    /**
     * Indicator that the next value in the \p extra parameter to
     * ::cuLaunchKernel will be a pointer to a size_t which contains the
     * size of the buffer specified with ::CU_LAUNCH_PARAM_BUFFER_POINTER.
     * It is required that ::CU_LAUNCH_PARAM_BUFFER_POINTER also be specified
     * in the \p extra array if the value associated with
     * ::CU_LAUNCH_PARAM_BUFFER_SIZE is not zero.
     */
    public static final Pointer CU_LAUNCH_PARAM_BUFFER_SIZE = new ConstantPointer(2); //   ((void*)0x02)


    /**
     * Whether a CudaException should be thrown if a method is about
     * to return a result code that is not CUresult.CUDA_SUCCESS
     */
    private static boolean exceptionsEnabled = false;


    static
    {
        LibUtils.loadLibrary("JCudaDriver");
    }

    /* Private constructor to prevent instantiation */
    private JCudaDriver()
    {
    }

    /**
     * Set the specified log level for the JCuda driver library.<br />
     * <br />
     * Currently supported log levels:
     * <br />
     * LOG_QUIET: Never print anything <br />
     * LOG_ERROR: Print error messages <br />
     * LOG_TRACE: Print a trace of all native function calls <br />
     *
     * @param logLevel The log level to use.
     */
    public static void setLogLevel(LogLevel logLevel)
    {
        setLogLevel(logLevel.ordinal());
    }

    private static native void setLogLevel(int logLevel);


    /**
     * Enables or disables exceptions. By default, the methods of this class
     * only return the CUresult error code from the underlying CUDA function.
     * If exceptions are enabled, a CudaException with a detailed error
     * message will be thrown if a method is about to return a result code
     * that is not CUresult.CUDA_SUCCESS
     *
     * @param enabled Whether exceptions are enabled
     */
    public static void setExceptionsEnabled(boolean enabled)
    {
        exceptionsEnabled = enabled;
    }

    /**
     * If the given result is different to CUresult.CUDA_SUCCESS and
     * exceptions have been enabled, this method will throw a
     * CudaException with an error message that corresponds to the
     * given result code. Otherwise, the given result is simply
     * returned.
     *
     * @param result The result to check
     * @return The result that was given as the parameter
     * @throws CudaException If exceptions have been enabled and
     * the given result code is not CUresult.CUDA_SUCCESS
     */
    private static int checkResult(int result)
    {
        if (exceptionsEnabled && result != CUresult.CUDA_SUCCESS)
        {
            throw new CudaException(CUresult.stringFor(result));
        }
        return result;
    }

    /**
     * Returns the given (address) value, adjusted to have
     * the given alignment. This function may be used to
     * align the parameters for a kernel call according
     * to their alignment requirements.
     *
     * @param value The address value
     * @param alignment The desired alignment
     * @return The aligned address value
     */
    public static int align(int value, int alignment)
    {
        return (((value) + (alignment) - 1) & ~((alignment) - 1));
    }
    
    
    /**
     * A wrapper function for 
     * {@link JCudaDriver#cuModuleLoadDataEx(CUmodule, Pointer, int, int[], Pointer)}
     * which allows passing in the options for the JIT compiler, and obtaining
     * the output of the JIT compiler via a {@link JITOptions} object. <br />
     * <br />
     * <u>Note:</u> This method should be considered as preliminary,
     * and might change in future releases. 
     * 
     * @see JCudaDriver#cuModuleLoadDataEx
     */
    public static int cuModuleLoadDataJIT(CUmodule module, Pointer pointer, JITOptions jitOptions)
    {
        return cuModuleLoadDataJITNative(module, pointer, jitOptions);
    }
    private static native int cuModuleLoadDataJITNative(CUmodule module, Pointer pointer, JITOptions jitOptions);
    


    /**
     * Initialize the CUDA driver API.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuInit           </td>
     *         <td>(</td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Initializes the driver API and must be called before any other function
     *       from the driver API. Currently, the <code>Flags</code> parameter must
     *       be 0. If cuInit() has not been called, any function from the driver
     *       API will return CUDA_ERROR_NOT_INITIALIZED.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_INVALID_DEVICE
     *
     *
     */
    public static int cuInit(int Flags)
    {
        return checkResult(cuInitNative(Flags));
    }

    private static native int cuInitNative(int Flags);


    /**
     * Returns a handle to a compute device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDeviceGet           </td>
     *         <td>(</td>
     *         <td>CUdevice *&nbsp;</td>
     *         <td> <em>device</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>ordinal</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*device</code> a device handle given an ordinal in
     *       the range <b>[0, cuDeviceGetCount()-1]</b>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_DEVICE
     *
     * @see JCudaDriver#cuDeviceComputeCapability
     * @see JCudaDriver#cuDeviceGetAttribute
     * @see JCudaDriver#cuDeviceGetCount
     * @see JCudaDriver#cuDeviceGetName
     * @see JCudaDriver#cuDeviceGetProperties
     * @see JCudaDriver#cuDeviceTotalMem
     */
    public static int cuDeviceGet(CUdevice device, int ordinal)
    {
        return checkResult(cuDeviceGetNative(device, ordinal));
    }

    private static native int cuDeviceGetNative(CUdevice device, int ordinal);


    /**
     * Returns the number of compute-capable devices.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDeviceGetCount           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>count</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*count</code> the number of devices with compute
     *       capability greater than or equal to 1.0 that are available for
     *       execution. If there is no such device, cuDeviceGetCount() returns
     *       0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuDeviceComputeCapability
     * @see JCudaDriver#cuDeviceGetAttribute
     * @see JCudaDriver#cuDeviceGetName
     * @see JCudaDriver#cuDeviceGet
     * @see JCudaDriver#cuDeviceGetProperties
     * @see JCudaDriver#cuDeviceTotalMem
     */
    public static int cuDeviceGetCount(int count[])
    {
        return checkResult(cuDeviceGetCountNative(count));
    }

    private static native int cuDeviceGetCountNative(int count[]);


    /**
     * Returns an identifer string for the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDeviceGetName           </td>
     *         <td>(</td>
     *         <td>char *&nbsp;</td>
     *         <td> <em>name</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>len</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>dev</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns an ASCII string identifying the device <code>dev</code> in the
     *       NULL-terminated string pointed to by <code>name</code>. <code>len</code>
     *       specifies the maximum length of the string that may be returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_DEVICE
     *
     * @see JCudaDriver#cuDeviceComputeCapability
     * @see JCudaDriver#cuDeviceGetAttribute
     * @see JCudaDriver#cuDeviceGetCount
     * @see JCudaDriver#cuDeviceGet
     * @see JCudaDriver#cuDeviceGetProperties
     * @see JCudaDriver#cuDeviceTotalMem
     */
    public static int cuDeviceGetName(byte name[], int len, CUdevice dev)
    {
        return checkResult(cuDeviceGetNameNative(name, len, dev));
    }

    private static native int cuDeviceGetNameNative(byte name[], int len, CUdevice dev);


    /**
     * Returns the compute capability of the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDeviceComputeCapability           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>major</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>minor</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>dev</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*major</code> and <code>*minor</code> the major and
     *       minor revision numbers that define the compute capability of the device
     *       <code>dev</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_DEVICE
     *
     * @see JCudaDriver#cuDeviceGetAttribute
     * @see JCudaDriver#cuDeviceGetCount
     * @see JCudaDriver#cuDeviceGetName
     * @see JCudaDriver#cuDeviceGet
     * @see JCudaDriver#cuDeviceGetProperties
     * @see JCudaDriver#cuDeviceTotalMem
     */
    public static int cuDeviceComputeCapability(int major[], int minor[], CUdevice dev)
    {
        return checkResult(cuDeviceComputeCapabilityNative(major, minor, dev));
    }

    private static native int cuDeviceComputeCapabilityNative(int major[], int minor[], CUdevice dev);

    /**
     * Returns the total amount of memory on the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDeviceTotalMem           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>bytes</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>dev</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*bytes</code> the total amount of memory available on
     *       the device <code>dev</code> in bytes.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_DEVICE
     *
     * @see JCudaDriver#cuDeviceComputeCapability
     * @see JCudaDriver#cuDeviceGetAttribute
     * @see JCudaDriver#cuDeviceGetCount
     * @see JCudaDriver#cuDeviceGetName
     * @see JCudaDriver#cuDeviceGet
     * @see JCudaDriver#cuDeviceGetProperties
     */
    public static int cuDeviceTotalMem(long bytes[], CUdevice dev)
    {
        return checkResult(cuDeviceTotalMemNative(bytes, dev));
    }

    private static native int cuDeviceTotalMemNative(long bytes[], CUdevice dev);


    /**
     * Returns properties for a selected device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDeviceGetProperties           </td>
     *         <td>(</td>
     *         <td>CUdevprop *&nbsp;</td>
     *         <td> <em>prop</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>dev</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*prop</code> the properties of device <code>dev</code>.
     *       The CUdevprop structure is defined as:
     *     <p>
     *     <div>
     *       <pre>     <span>typedef</span> <span>struct </span>CUdevprop_st
     * {
     *      <span>int</span> maxThreadsPerBlock;
     *      <span>int</span> maxThreadsDim[3];
     *      <span>int</span> maxGridSize[3];
     *      <span>int</span> sharedMemPerBlock;
     *      <span>int</span> totalConstantMemory;
     *      <span>int</span> SIMDWidth;
     *      <span>int</span> memPitch;
     *      <span>int</span> regsPerBlock;
     *      <span>int</span> clockRate;
     *      <span>int</span> textureAlign
     *   } CUdevprop;
     * </pre>
     *     </div>
     *     where:
     *     <p>
     *     <ul>
     *       <li>maxThreadsPerBlock is the maximum number of threads per
     *         block;
     *       </li>
     *       <li>maxThreadsDim[3] is the maximum sizes of each dimension
     *         of a block;
     *       </li>
     *       <li>maxGridSize[3] is the maximum sizes of each
     *         dimension of a grid;
     *       </li>
     *       <li>sharedMemPerBlock is the total amount of
     *         shared memory available per block in bytes;
     *       </li>
     *       <li>totalConstantMemory
     *         is the total amount of constant memory available on the device in
     *         bytes;
     *       </li>
     *       <li>SIMDWidth is the warp size;</li>
     *       <li>memPitch is the
     *         maximum pitch allowed by the memory copy functions that involve memory
     *         regions allocated through cuMemAllocPitch();
     *       </li>
     *       <li>regsPerBlock is
     *         the total number of registers available per block;
     *       </li>
     *       <li>clockRate
     *         is the clock frequency in kilohertz;
     *       </li>
     *       <li>textureAlign is the
     *         alignment requirement; texture base addresses that are aligned to
     *         textureAlign bytes do not need an offset applied to texture
     *         fetches.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_DEVICE
     *
     * @see JCudaDriver#cuDeviceComputeCapability
     * @see JCudaDriver#cuDeviceGetAttribute
     * @see JCudaDriver#cuDeviceGetCount
     * @see JCudaDriver#cuDeviceGetName
     * @see JCudaDriver#cuDeviceGet
     * @see JCudaDriver#cuDeviceTotalMem
     */
    public static int cuDeviceGetProperties(CUdevprop prop, CUdevice dev)
    {
        return checkResult(cuDeviceGetPropertiesNative(prop, dev));
    }

    private static native int cuDeviceGetPropertiesNative(CUdevprop prop, CUdevice dev);


    /**
     * Returns information about the device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDeviceGetAttribute           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>pi</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice_attribute&nbsp;</td>
     *         <td> <em>attrib</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>dev</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pi</code> the integer value of the attribute
     *       <code>attrib</code> on device <code>dev</code>. The supported attributes
     *       are:
     *     <ul>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_BLOCK: Maximum number of
     *         threads per block;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_X: Maximum
     *         x-dimension of a block;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_Y:
     *         Maximum y-dimension of a block;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_Z:
     *         Maximum z-dimension of a block;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_GRID_DIM_X:
     *         Maximum x-dimension of a grid;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_GRID_DIM_Y:
     *         Maximum y-dimension of a grid;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_GRID_DIM_Z:
     *         Maximum z-dimension of a
     *         grid;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_SHARED_MEMORY_PER_BLOCK: Maximum
     *         amount of shared memory available to a thread block in bytes; this
     *         amount is shared by all thread blocks simultaneously resident on a
     *         multiprocessor;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_TOTAL_CONSTANT_MEMORY:
     *         Memory available on device for __constant__ variables in a CUDA C
     *         kernel in bytes;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_WARP_SIZE: Warp size in
     *         threads;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_PITCH: Maximum pitch in bytes
     *         allowed by the memory copy functions that involve memory regions
     *         allocated through
     *         cuMemAllocPitch();
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE1D_WIDTH:
     *         Maximum 1D texture width;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE2D_WIDTH:
     *         Maximum 2D texture width;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE2D_HEIGHT:
     *         Maximum 2D texture height;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE3D_WIDTH:
     *         Maximum 3D texture width;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE3D_HEIGHT:
     *         Maximum 3D texture height;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE3D_DEPTH:
     *         Maximum 3D texture depth;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE1D_LAYERED_WIDTH:
     *         Maximum 1D layered texture
     *         width;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE1D_LAYERED_LAYERS:
     *         Maximum layers in a 1D layered
     *         texture;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE2D_LAYERED_WIDTH:
     *         Maximum 2D layered texture
     *         width;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE2D_LAYERED_HEIGHT:
     *         Maximum 2D layered texture
     *         height;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAXIMUM_TEXTURE2D_LAYERED_LAYERS:
     *         Maximum layers in a 2D layered
     *         texture;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_REGISTERS_PER_BLOCK: Maximum
     *         number of 32-bit registers available to a thread block; this number is
     *         shared by all thread blocks simultaneously resident on a
     *         multiprocessor;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_CLOCK_RATE: Peak clock
     *         frequency in kilohertz;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_TEXTURE_ALIGNMENT:
     *         Alignment requirement; texture base addresses aligned to textureAlign
     *         bytes do not need an offset applied to texture
     *         fetches;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_GPU_OVERLAP: 1 if the device can
     *         concurrently copy memory between host and device while executing a
     *         kernel, or 0 if not;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT:
     *         Number of multiprocessors on the
     *         device;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_KERNEL_EXEC_TIMEOUT: 1 if there is
     *         a run time limit for kernels executed on the device, or 0 if
     *         not;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_INTEGRATED: 1 if the device is
     *         integrated with the memory subsystem, or 0 if
     *         not;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_CAN_MAP_HOST_MEMORY: 1 if the device
     *         can map host memory into the CUDA address space, or 0 if
     *         not;
     *       </li>
     *       <li>
     *         CU_DEVICE_ATTRIBUTE_COMPUTE_MODE: Compute mode that device
     *         is currently in. Available modes are as follows:
     *         <ul>
     *           <li>CU_COMPUTEMODE_DEFAULT: Default mode - Device is not restricted
     *             and can have multiple CUDA contexts present at a single
     *             time.
     *           </li>
     *           <li>CU_COMPUTEMODE_EXCLUSIVE: Compute-exclusive mode - Device
     *             can have only one CUDA context present on it at a
     *             time.
     *           </li>
     *           <li>CU_COMPUTEMODE_PROHIBITED: Compute-prohibited mode -
     *             Device is prohibited from creating new CUDA contexts.
     *           </li>
     *         </ul>
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_CONCURRENT_KERNELS: 1 if the device
     *         supports executing multiple kernels within the same context
     *         simultaneously, or 0 if not. It is not guaranteed that multiple kernels
     *         will be resident on the device concurrently so this feature should not
     *         be relied upon for correctness;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_ECC_ENABLED:
     *         1 if error correction is enabled on the device, 0 if error correction
     *         is disabled or not supported by the
     *         device;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_PCI_BUS_ID: PCI bus identifier of
     *         the device;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_PCI_DEVICE_ID: PCI device (also
     *         known as slot) identifier of the device;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_TCC_DRIVER:
     *         1 if the device is using a TCC driver. TCC is only available on Tesla
     *         hardware running Windows Vista or
     *         later;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MEMORY_CLOCK_RATE: Peak memory clock
     *         frequency in kilohertz;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_GLOBAL_MEMORY_BUS_WIDTH:
     *         Global memory bus width in bits;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE:
     *         Size of L2 cache in bytes. 0 if the device doesn't have L2
     *         cache;
     *       </li>
     *       <li>CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_MULTIPROCESSOR:
     *         Maximum resident threads per multiprocessor;
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_DEVICE
     *
     * @see JCudaDriver#cuDeviceComputeCapability
     * @see JCudaDriver#cuDeviceGetCount
     * @see JCudaDriver#cuDeviceGetName
     * @see JCudaDriver#cuDeviceGet
     * @see JCudaDriver#cuDeviceGetProperties
     * @see JCudaDriver#cuDeviceTotalMem
     */
    public static int cuDeviceGetAttribute(int pi[], int attrib, CUdevice dev)
    {
        return checkResult(cuDeviceGetAttributeNative(pi, attrib, dev));
    }

    private static native int cuDeviceGetAttributeNative(int pi[], int attrib, CUdevice dev);


    /**
     * Returns the CUDA driver version.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDriverGetVersion           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>driverVersion</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*driverVersion</code> the version number of the
     *       installed CUDA driver. This function automatically returns
     *       CUDA_ERROR_INVALID_VALUE if the <code>driverVersion</code> argument is
     *       NULL.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_VALUE
     *
     */
    public static int cuDriverGetVersion (int driverVersion[])
    {
        return checkResult(cuDriverGetVersionNative(driverVersion));
    }
    private static native int cuDriverGetVersionNative(int driverVersion[]);



    /**
     * Create a CUDA context.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxCreate           </td>
     *         <td>(</td>
     *         <td>CUcontext *&nbsp;</td>
     *         <td> <em>pctx</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>dev</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates a new CUDA context and associates it with the calling thread.
     *       The <code>flags</code> parameter is described below. The context is
     *       created with a usage count of 1 and the caller of cuCtxCreate() must
     *       call cuCtxDestroy() or when done using the context. If a context is
     *       already current to the thread, it is supplanted by the newly created
     *       context and may be restored by a subsequent call to
     *       cuCtxPopCurrent().
     *     <p>
     *       The three LSBs of the <code>flags</code> parameter can be used to
     *       control how the OS thread, which owns the CUDA context at the time of
     *       an API call, interacts with the OS scheduler when waiting for results
     *       from the GPU. Only one of the scheduling flags can be set when creating
     *       a context.
     *     <p>
     *     <ul>
     *       <li>CU_CTX_SCHED_AUTO: The default value if the <code>flags</code>
     *         parameter is zero, uses a heuristic based on the number of active CUDA
     *         contexts in the process <em>C</em> and the number of logical processors
     *         in the system <em>P</em>. If <em>C</em> &gt; <em>P</em>, then CUDA will
     *         yield to other OS threads when waiting for the GPU, otherwise CUDA will
     *         not yield while waiting for results and actively spin on the
     *         processor.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_CTX_SCHED_SPIN: Instruct CUDA to actively spin when waiting for
     *         results from the GPU. This can decrease latency when waiting for the
     *         GPU, but may lower the performance of CPU threads if they are performing
     *         work in parallel with the CUDA thread.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_CTX_SCHED_YIELD: Instruct CUDA to yield its thread when waiting
     *         for results from the GPU. This can increase latency when waiting for
     *         the GPU, but can increase the performance of CPU threads performing
     *         work in parallel with the GPU.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_CTX_SCHED_BLOCKING_SYNC: Instruct CUDA to block the CPU thread
     *         on a synchronization primitive when waiting for the GPU to finish
     *         work.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>
     *         CU_CTX_BLOCKING_SYNC: Instruct CUDA to block the CPU thread on a
     *         synchronization primitive when waiting for the GPU to finish work.
     *         <dl compact>
     *           <dt><b>Deprecated:</b></dt>
     *           <dd>This flag was deprecated as of
     *             CUDA 4.0 and was replaced with CU_CTX_SCHED_BLOCKING_SYNC.
     *           </dd>
     *         </dl>
     *         - CU_CTX_MAP_HOST: Instruct CUDA to support mapped pinned allocations.
     *         This flag must be set in order to allocate pinned host memory that is
     *         accessible to the GPU.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_CTX_LMEM_RESIZE_TO_MAX: Instruct CUDA to not reduce local memory
     *         after resizing local memory for a kernel. This can prevent thrashing
     *         by local memory allocations when launching many kernels with high local
     *         memory usage at the cost of potentially increased memory
     *         usage.
     *       </li>
     *     </ul>
     *     <p>
     *       <b>Note to Linux users</b>:
     *     <p>
     *       Context creation will fail with CUDA_ERROR_UNKNOWN if the compute mode
     *       of the device is CU_COMPUTEMODE_PROHIBITED. Similarly, context creation
     *       will also fail with CUDA_ERROR_UNKNOWN if the compute mode for the
     *       device is set to CU_COMPUTEMODE_EXCLUSIVE and there is already an
     *       active context on the device. The function cuDeviceGetAttribute() can
     *       be used with CU_DEVICE_ATTRIBUTE_COMPUTE_MODE to determine the compute
     *       mode of the device. The <em>nvidia-smi</em> tool can be used to set
     *       the compute mode for devices. Documentation for <em>nvidia-smi</em>
     *       can be obtained by passing a -h option to it.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_DEVICE,
     * CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_OUT_OF_MEMORY, CUDA_ERROR_UNKNOWN
     *
     *
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     */
    public static int cuCtxCreate(CUcontext pctx, int flags, CUdevice dev)
    {
        return checkResult(cuCtxCreateNative(pctx, flags, dev));
    }

    private static native int cuCtxCreateNative(CUcontext pctx, int flags, CUdevice dev);


    /**
     * Destroy a CUDA context.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxDestroy           </td>
     *         <td>(</td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>ctx</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Destroys the CUDA context specified by <code>ctx</code>. The context
     *       <code>ctx</code> will be destroyed regardless of how many threads it
     *       is current to. It is the caller's responsibility to ensure that no API
     *       call is issued to <code>ctx</code> while cuCtxDestroy() is
     *       executing.
     *     <p>
     *       If <code>ctx</code> is current to the calling thread then <code>ctx</code>
     *       will also be popped from the current thread's context stack (as though
     *       cuCtxPopCurrent() were called). If <code>ctx</code> is current to other
     *       threads, then <code>ctx</code> will remain current to those threads,
     *       and attempting to access <code>ctx</code> from those threads will
     *       result in the error CUDA_ERROR_CONTEXT_IS_DESTROYED.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     */
    public static int cuCtxDestroy(CUcontext ctx)
    {
        return checkResult(cuCtxDestroyNative(ctx));
    }

    private static native int cuCtxDestroyNative(CUcontext ctx);


    /**
     * Increment a context's usage-count.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxAttach           </td>
     *         <td>(</td>
     *         <td>CUcontext *&nbsp;</td>
     *         <td> <em>pctx</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that this function is deprecated and should not be used.
     *     <p>
     *       Increments the usage count of the context and passes back a context
     *       handle in <code>*pctx</code> that must be passed to cuCtxDetach() when
     *       the application is done with the context. cuCtxAttach() fails if there
     *       is no context current to the thread.
     *     <p>
     *       Currently, the <code>flags</code> parameter must be 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxDetach
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuCtxAttach(CUcontext pctx, int flags)
    {
        return checkResult(cuCtxAttachNative(pctx, flags));
    }

    private static native int cuCtxAttachNative(CUcontext pctx, int flags);


    /**
     * Decrement a context's usage-count.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxDetach           </td>
     *         <td>(</td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>ctx</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that this function is deprecated and should not be used.
     *     <p>
     *       Decrements the usage count of the context <code>ctx</code>, and destroys
     *       the context if the usage count goes to 0. The context must be a handle
     *       that was passed back by cuCtxCreate() or cuCtxAttach(), and must be
     *       current to the calling thread.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuCtxDetach(CUcontext ctx)
    {
        return checkResult(cuCtxDetachNative(ctx));
    }

    private static native int cuCtxDetachNative(CUcontext ctx);


    /**
     * Pushes a context on the current CPU thread.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxPushCurrent           </td>
     *         <td>(</td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>ctx</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Pushes the given context <code>ctx</code> onto the CPU thread's stack
     *       of current contexts. The specified context becomes the CPU thread's
     *       current context, so all CUDA functions that operate on the current
     *       context are affected.
     *     <p>
     *       The previous current context may be made current again by calling
     *       cuCtxDestroy() or cuCtxPopCurrent().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     */
    public static int cuCtxPushCurrent(CUcontext ctx)
    {
        return checkResult(cuCtxPushCurrentNative(ctx));
    }

    private static native int cuCtxPushCurrentNative(CUcontext ctx);


    /**
     * Pops the current CUDA context from the current CPU thread.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxPopCurrent           </td>
     *         <td>(</td>
     *         <td>CUcontext *&nbsp;</td>
     *         <td> <em>pctx</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Pops the current CUDA context from the CPU thread and passes back the
     *       old context handle in <code>*pctx</code>. That context may then be made
     *       current to a different CPU thread by calling cuCtxPushCurrent().
     *     <p>
     *       If a context was current to the CPU thread before cuCtxCreate() or
     *       cuCtxPushCurrent() was called, this function makes that context current
     *       to the CPU thread again.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     */
    public static int cuCtxPopCurrent(CUcontext pctx)
    {
        return checkResult(cuCtxPopCurrentNative(pctx));
    }

    private static native int cuCtxPopCurrentNative(CUcontext pctx);


    /**
     * Binds the specified CUDA context to the calling CPU thread.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxSetCurrent           </td>
     *         <td>(</td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>ctx</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Binds the specified CUDA context to the calling CPU thread. If
     *       <code>ctx</code> is NULL then the CUDA context previously bound to the
     *       calling CPU thread is unbound and CUDA_SUCCESS is returned.
     *     <p>
     *       If there exists a CUDA context stack on the calling CPU thread, this
     *       will replace the top of that stack with <code>ctx</code>. If
     *       <code>ctx</code> is NULL then this will be equivalent to popping the
     *       top of the calling CPU thread's CUDA context stack (or a no-op if the
     *       calling CPU thread's CUDA context stack is empty).
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT
     *
     * @see JCudaDriver#cuCtxGetCurrent
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     */
    public static int cuCtxSetCurrent(CUcontext ctx)
    {
        return checkResult(cuCtxSetCurrentNative(ctx));
    }

    private static native int cuCtxSetCurrentNative(CUcontext ctx);


    /**
     * Returns the CUDA context bound to the calling CPU thread.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxGetCurrent           </td>
     *         <td>(</td>
     *         <td>CUcontext *&nbsp;</td>
     *         <td> <em>pctx</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pctx</code> the CUDA context bound to the calling
     *       CPU thread. If no context is bound to the calling CPU thread then
     *       <code>*pctx</code> is set to NULL and CUDA_SUCCESS is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     *
     *
     * @see JCudaDriver#cuCtxSetCurrent
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     */
    public static int cuCtxGetCurrent(CUcontext pctx)
    {
        return checkResult(cuCtxGetCurrentNative(pctx));
    }

    private static native int cuCtxGetCurrentNative(CUcontext pctx);


    /**
     * Returns the device ID for the current context.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxGetDevice           </td>
     *         <td>(</td>
     *         <td>CUdevice *&nbsp;</td>
     *         <td> <em>device</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*device</code> the ordinal of the current context's
     *       device.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     */
    public static int cuCtxGetDevice(CUdevice device)
    {
        return checkResult(cuCtxGetDeviceNative(device));
    }

    private static native int cuCtxGetDeviceNative(CUdevice device);


    /**
     * Block for a context's tasks to complete.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxSynchronize           </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Blocks until the device has completed all preceding requested tasks.
     *       cuCtxSynchronize() returns an error if one of the preceding tasks
     *       failed. If the context was created with the CU_CTX_SCHED_BLOCKING_SYNC
     *       flag, the CPU thread will block until the GPU context has finished its
     *       work.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetLimit
     */
    public static int cuCtxSynchronize()
    {
        return checkResult(cuCtxSynchronizeNative());
    }

    private static native int cuCtxSynchronizeNative();


    /**
     * Loads a compute module.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleLoad           </td>
     *         <td>(</td>
     *         <td>CUmodule *&nbsp;</td>
     *         <td> <em>module</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>fname</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Takes a filename <code>fname</code> and loads the corresponding module
     *       <code>module</code> into the current context. The CUDA driver API does
     *       not attempt to lazily allocate the resources needed by a module; if
     *       the memory for functions and data (constant and global) needed by the
     *       module cannot be allocated, cuModuleLoad() fails. The file should be a
     *       <em>cubin</em> file as output by <b>nvcc</b>, or a <em>PTX</em> file
     *       either as output by <b>nvcc</b> or handwritten, or a <em>fatbin</em>
     *       file as output by <b>nvcc</b> from toolchain 4.0 or later.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_NOT_FOUND,
     * CUDA_ERROR_OUT_OF_MEMORY, CUDA_ERROR_FILE_NOT_FOUND,
     * CUDA_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND, CUDA_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     *
     * @see JCudaDriver#cuModuleGetFunction
     * @see JCudaDriver#cuModuleGetGlobal
     * @see JCudaDriver#cuModuleGetTexRef
     * @see JCudaDriver#cuModuleLoadData
     * @see JCudaDriver#cuModuleLoadDataEx
     * @see JCudaDriver#cuModuleLoadFatBinary
     * @see JCudaDriver#cuModuleUnload
     */
    public static int cuModuleLoad(CUmodule module, String fname)
    {
        return checkResult(cuModuleLoadNative(module, fname));
    }

    private static native int cuModuleLoadNative(CUmodule module, String fname);


    /**
     * Load a module's data.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleLoadData           </td>
     *         <td>(</td>
     *         <td>CUmodule *&nbsp;</td>
     *         <td> <em>module</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>image</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Takes a pointer <code>image</code> and loads the corresponding module
     *       <code>module</code> into the current context. The pointer may be
     *       obtained by mapping a <em>cubin</em> or <em>PTX</em> or <em>fatbin</em>
     *       file, passing a <em>cubin</em> or <em>PTX</em> or <em>fatbin</em> file
     *       as a NULL-terminated text string, or incorporating a <em>cubin</em> or
     *       <em>fatbin</em> object into the executable resources and using operating
     *       system calls such as Windows <code>FindResource()</code> to obtain the
     *       pointer.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY, CUDA_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND,
     * CUDA_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     * @see JCudaDriver#cuModuleGetFunction
     * @see JCudaDriver#cuModuleGetGlobal
     * @see JCudaDriver#cuModuleGetTexRef
     * @see JCudaDriver#cuModuleLoad
     * @see JCudaDriver#cuModuleLoadDataEx
     * @see JCudaDriver#cuModuleLoadFatBinary
     * @see JCudaDriver#cuModuleUnload
     */
    public static int cuModuleLoadData(CUmodule module, byte image[])
    {
        return checkResult(cuModuleLoadDataNative(module, image));
    }

    private static native int cuModuleLoadDataNative(CUmodule module, byte image[]);




    /**
     * Load a module's data with options.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleLoadDataEx           </td>
     *         <td>(</td>
     *         <td>CUmodule *&nbsp;</td>
     *         <td> <em>module</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>image</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>numOptions</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUjit_option *&nbsp;</td>
     *         <td> <em>options</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>optionValues</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Takes a pointer <code>image</code> and loads the corresponding module
     *       <code>module</code> into the current context. The pointer may be
     *       obtained by mapping a <em>cubin</em> or <em>PTX</em> or <em>fatbin</em>
     *       file, passing a <em>cubin</em> or <em>PTX</em> or <em>fatbin</em> file
     *       as a NULL-terminated text string, or incorporating a <em>cubin</em> or
     *       <em>fatbin</em> object into the executable resources and using operating
     *       system calls such as Windows <code>FindResource()</code> to obtain the
     *       pointer. Options are passed as an array via <code>options</code> and
     *       any corresponding parameters are passed in <code>optionValues</code>.
     *       The number of total options is supplied via <code>numOptions</code>.
     *       Any outputs will be returned via <code>optionValues</code>. Supported
     *       options are (types for the option values are specified in parentheses
     *       after the option name):
     *     <p>
     *     <ul>
     *       <li>CU_JIT_MAX_REGISTERS: (unsigned int) input specifies the maximum
     *         number of registers per thread;
     *       </li>
     *       <li>CU_JIT_THREADS_PER_BLOCK:
     *         (unsigned int) input specifies number of threads per block to target
     *         compilation for; output returns the number of threads the compiler
     *         actually targeted;
     *       </li>
     *       <li>CU_JIT_WALL_TIME: (float) output returns
     *         the float value of wall clock time, in milliseconds, spent compiling
     *         the <em>PTX</em> code;
     *       </li>
     *       <li>CU_JIT_INFO_LOG_BUFFER: (char*) input
     *         is a pointer to a buffer in which to print any informational log
     *         messages from <em>PTX</em> assembly (the buffer size is specified via
     *         option CU_JIT_INFO_LOG_BUFFER_SIZE_BYTES);
     *       </li>
     *       <li>CU_JIT_INFO_LOG_BUFFER_SIZE_BYTES:
     *         (unsigned int) input is the size in bytes of the buffer; output is the
     *         number of bytes filled with messages;
     *       </li>
     *       <li>CU_JIT_ERROR_LOG_BUFFER:
     *         (char*) input is a pointer to a buffer in which to print any error log
     *         messages from <em>PTX</em> assembly (the buffer size is specified via
     *         option CU_JIT_ERROR_LOG_BUFFER_SIZE_BYTES);
     *       </li>
     *       <li>CU_JIT_ERROR_LOG_BUFFER_SIZE_BYTES:
     *         (unsigned int) input is the size in bytes of the buffer; output is the
     *         number of bytes filled with messages;
     *       </li>
     *       <li>CU_JIT_OPTIMIZATION_LEVEL:
     *         (unsigned int) input is the level of optimization to apply to generated
     *         code (0 - 4), with 4 being the default and highest
     *         level;
     *       </li>
     *       <li>CU_JIT_TARGET_FROM_CUCONTEXT: (No option value) causes
     *         compilation target to be determined based on current attached context
     *         (default);
     *       </li>
     *       <li>
     *         CU_JIT_TARGET: (unsigned int for enumerated type
     *         CUjit_target_enum) input is the compilation target based on supplied
     *         CUjit_target_enum; possible values are:
     *         <ul>
     *           <li>CU_TARGET_COMPUTE_10</li>
     *           <li>CU_TARGET_COMPUTE_11</li>
     *           <li>CU_TARGET_COMPUTE_12</li>
     *           <li>CU_TARGET_COMPUTE_13</li>
     *           <li>CU_TARGET_COMPUTE_20</li>
     *         </ul>
     *       </li>
     *       <li>
     *         CU_JIT_FALLBACK_STRATEGY: (unsigned int for enumerated type
     *         CUjit_fallback_enum) chooses fallback strategy if matching cubin is
     *         not found; possible values are:
     *         <ul>
     *           <li>CU_PREFER_PTX</li>
     *           <li>CU_PREFER_BINARY</li>
     *         </ul>
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY, CUDA_ERROR_NO_BINARY_FOR_GPU,
     * CUDA_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND, CUDA_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     *
     * @see JCudaDriver#cuModuleGetFunction
     * @see JCudaDriver#cuModuleGetGlobal
     * @see JCudaDriver#cuModuleGetTexRef
     * @see JCudaDriver#cuModuleLoad
     * @see JCudaDriver#cuModuleLoadData
     * @see JCudaDriver#cuModuleLoadFatBinary
     * @see JCudaDriver#cuModuleUnload
     */
    public static int cuModuleLoadDataEx (CUmodule phMod, Pointer p, int numOptions, int options[], Pointer optionValues)
    {
        return checkResult(cuModuleLoadDataExNative(phMod, p, numOptions, options, optionValues));
    }
    private static native int cuModuleLoadDataExNative(CUmodule phMod, Pointer p, int numOptions, int options[], Pointer optionValues);



    /**
     * Load a module's data.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleLoadFatBinary           </td>
     *         <td>(</td>
     *         <td>CUmodule *&nbsp;</td>
     *         <td> <em>module</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>fatCubin</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Takes a pointer <code>fatCubin</code> and loads the corresponding
     *       module <code>module</code> into the current context. The pointer
     *       represents a <em>fat binary</em> object, which is a collection of
     *       different <em>cubin</em> and/or <em>PTX</em> files, all representing
     *       the same device code, but compiled and optimized for different
     *       architectures.
     *     <p>
     *       Prior to CUDA 4.0, there was no documented API for constructing and
     *       using fat binary objects by programmers. Starting with CUDA 4.0, fat
     *       binary objects can be constructed by providing the <em>-fatbin
     *       option</em> to <b>nvcc</b>. More information can be found in the
     *       <b>nvcc</b> document.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_NOT_FOUND,
     * CUDA_ERROR_OUT_OF_MEMORY, CUDA_ERROR_NO_BINARY_FOR_GPU,
     * CUDA_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND, CUDA_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     *
     * @see JCudaDriver#cuModuleGetFunction
     * @see JCudaDriver#cuModuleGetGlobal
     * @see JCudaDriver#cuModuleGetTexRef
     * @see JCudaDriver#cuModuleLoad
     * @see JCudaDriver#cuModuleLoadData
     * @see JCudaDriver#cuModuleLoadDataEx
     * @see JCudaDriver#cuModuleUnload
     */
    public static int cuModuleLoadFatBinary(CUmodule module, byte fatCubin[])
    {
        return checkResult(cuModuleLoadFatBinaryNative(module, fatCubin));
    }

    private static native int cuModuleLoadFatBinaryNative(CUmodule module, byte fatCubin[]);


    /**
     * Unloads a module.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleUnload           </td>
     *         <td>(</td>
     *         <td>CUmodule&nbsp;</td>
     *         <td> <em>hmod</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Unloads a module <code>hmod</code> from the current context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuModuleGetFunction
     * @see JCudaDriver#cuModuleGetGlobal
     * @see JCudaDriver#cuModuleGetTexRef
     * @see JCudaDriver#cuModuleLoad
     * @see JCudaDriver#cuModuleLoadData
     * @see JCudaDriver#cuModuleLoadDataEx
     * @see JCudaDriver#cuModuleLoadFatBinary
     */
    public static int cuModuleUnload(CUmodule hmod)
    {
        return checkResult(cuModuleUnloadNative(hmod));
    }

    private static native int cuModuleUnloadNative(CUmodule hmod);


    /**
     * Returns a function handle.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleGetFunction           </td>
     *         <td>(</td>
     *         <td>CUfunction *&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUmodule&nbsp;</td>
     *         <td> <em>hmod</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>name</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*hfunc</code> the handle of the function of name
     *       <code>name</code> located in module <code>hmod</code>. If no function
     *       of that name exists, cuModuleGetFunction() returns
     *       CUDA_ERROR_NOT_FOUND.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_NOT_FOUND
     *
     *
     * @see JCudaDriver#cuModuleGetGlobal
     * @see JCudaDriver#cuModuleGetTexRef
     * @see JCudaDriver#cuModuleLoad
     * @see JCudaDriver#cuModuleLoadData
     * @see JCudaDriver#cuModuleLoadDataEx
     * @see JCudaDriver#cuModuleLoadFatBinary
     * @see JCudaDriver#cuModuleUnload
     */
    public static int cuModuleGetFunction(CUfunction hfunc, CUmodule hmod, String name)
    {
        return checkResult(cuModuleGetFunctionNative(hfunc, hmod, name));
    }

    private static native int cuModuleGetFunctionNative(CUfunction hfunc, CUmodule hmod, String name);


    /**
     * Returns a global pointer from a module.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleGetGlobal           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>dptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>bytes</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUmodule&nbsp;</td>
     *         <td> <em>hmod</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>name</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*dptr</code> and <code>*bytes</code> the base pointer
     *       and size of the global of name <code>name</code> located in module
     *       <code>hmod</code>. If no variable of that name exists, cuModuleGetGlobal()
     *       returns CUDA_ERROR_NOT_FOUND. Both parameters <code>dptr</code> and
     *       <code>bytes</code> are optional. If one of them is NULL, it is
     *       ignored.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_NOT_FOUND
     *
     *
     * @see JCudaDriver#cuModuleGetFunction
     * @see JCudaDriver#cuModuleGetTexRef
     * @see JCudaDriver#cuModuleLoad
     * @see JCudaDriver#cuModuleLoadData
     * @see JCudaDriver#cuModuleLoadDataEx
     * @see JCudaDriver#cuModuleLoadFatBinary
     * @see JCudaDriver#cuModuleUnload
     */
    public static int cuModuleGetGlobal(CUdeviceptr dptr, long bytes[], CUmodule hmod, String name)
    {
        return checkResult(cuModuleGetGlobalNative(dptr, bytes, hmod, name));
    }

    private static native int cuModuleGetGlobalNative(CUdeviceptr dptr, long bytes[], CUmodule hmod, String name);


    /**
     * Returns a handle to a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleGetTexRef           </td>
     *         <td>(</td>
     *         <td>CUtexref *&nbsp;</td>
     *         <td> <em>pTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUmodule&nbsp;</td>
     *         <td> <em>hmod</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>name</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pTexRef</code> the handle of the texture reference
     *       of name <code>name</code> in the module <code>hmod</code>. If no
     *       texture reference of that name exists, cuModuleGetTexRef() returns
     *       CUDA_ERROR_NOT_FOUND. This texture reference handle should not be
     *       destroyed, since it will be destroyed when the module is unloaded.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_NOT_FOUND
     *
     *
     * @see JCudaDriver#cuModuleGetFunction
     * @see JCudaDriver#cuModuleGetGlobal
     * @see JCudaDriver#cuModuleGetSurfRef
     * @see JCudaDriver#cuModuleLoad
     * @see JCudaDriver#cuModuleLoadData
     * @see JCudaDriver#cuModuleLoadDataEx
     * @see JCudaDriver#cuModuleLoadFatBinary
     * @see JCudaDriver#cuModuleUnload
     */
    public static int cuModuleGetTexRef(CUtexref pTexRef, CUmodule hmod, String name)
    {
        return checkResult(cuModuleGetTexRefNative(pTexRef, hmod, name));
    }

    private static native int cuModuleGetTexRefNative(CUtexref pTexRef, CUmodule hmod, String name);


    /**
     * Returns a handle to a surface reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuModuleGetSurfRef           </td>
     *         <td>(</td>
     *         <td>CUsurfref *&nbsp;</td>
     *         <td> <em>pSurfRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUmodule&nbsp;</td>
     *         <td> <em>hmod</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const char *&nbsp;</td>
     *         <td> <em>name</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pSurfRef</code> the handle of the surface reference
     *       of name <code>name</code> in the module <code>hmod</code>. If no
     *       surface reference of that name exists, cuModuleGetSurfRef() returns
     *       CUDA_ERROR_NOT_FOUND.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_NOT_FOUND
     *
     *
     * @see JCudaDriver#cuModuleGetFunction
     * @see JCudaDriver#cuModuleGetGlobal
     * @see JCudaDriver#cuModuleGetTexRef
     * @see JCudaDriver#cuModuleLoad
     * @see JCudaDriver#cuModuleLoadData
     * @see JCudaDriver#cuModuleLoadDataEx
     * @see JCudaDriver#cuModuleLoadFatBinary
     * @see JCudaDriver#cuModuleUnload
     */
    public static int cuModuleGetSurfRef(CUsurfref pSurfRef, CUmodule hmod, String name)
    {
        return checkResult(cuModuleGetSurfRefNative(pSurfRef, hmod, name));
    }
    private static native int cuModuleGetSurfRefNative(CUsurfref pSurfRef, CUmodule hmod, String name);



    /**
     * Gets free and total memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemGetInfo           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>free</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>total</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*free</code> and <code>*total</code> respectively,
     *       the free and total amount of memory available for allocation by the
     *       CUDA context, in bytes.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemGetInfo(long free[], long total[])
    {
        return checkResult(cuMemGetInfoNative(free, total));
    }

    private static native int cuMemGetInfoNative(long free[], long total[]);


    /**
     * Allocates page-locked host memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemHostAlloc           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>pp</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>bytesize</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates <code>bytesize</code> bytes of host memory that is page-locked
     *       and accessible to the device. The driver tracks the virtual memory
     *       ranges allocated with this function and automatically accelerates calls
     *       to functions such as cuMemcpyHtoD(). Since the memory can be accessed
     *       directly by the device, it can be read or written with much higher
     *       bandwidth than pageable memory obtained with functions such as malloc().
     *       Allocating excessive amounts of pinned memory may degrade system
     *       performance, since it reduces the amount of memory available to the
     *       system for paging. As a result, this function is best used sparingly
     *       to allocate staging areas for data exchange between host and
     *       device.
     *     <p>
     *       The <code>Flags</code> parameter enables different options to be
     *       specified that affect the allocation, as follows.
     *     <p>
     *     <ul>
     *       <li>CU_MEMHOSTALLOC_PORTABLE: The memory returned by this call will be
     *         considered as pinned memory by all CUDA contexts, not just the one that
     *         performed the allocation.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_MEMHOSTALLOC_DEVICEMAP: Maps the allocation into the CUDA
     *         address space. The device pointer to the memory may be obtained by
     *         calling cuMemHostGetDevicePointer(). This feature is available only on
     *         GPUs with compute capability greater than or equal to 1.1.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_MEMHOSTALLOC_WRITECOMBINED: Allocates the memory as write-combined
     *         (WC). WC memory can be transferred across the PCI Express bus more
     *         quickly on some system configurations, but cannot be read efficiently
     *         by most CPUs. WC memory is a good option for buffers that will be
     *         written by the CPU and read by the GPU via mapped pinned memory or
     *         host-&gt;device transfers.
     *       </li>
     *     </ul>
     *     <p>
     *       All of these flags are orthogonal to one another: a developer may
     *       allocate memory that is portable, mapped and/or write-combined with no
     *       restrictions.
     *     <p>
     *       The CUDA context must have been created with the CU_CTX_MAP_HOST flag
     *       in order for the CU_MEMHOSTALLOC_MAPPED flag to have any effect.
     *     <p>
     *       The CU_MEMHOSTALLOC_MAPPED flag may be specified on CUDA contexts for
     *       devices that do not support mapped pinned memory. The failure is
     *       deferred to cuMemHostGetDevicePointer() because the memory may be
     *       mapped into other CUDA contexts via the CU_MEMHOSTALLOC_PORTABLE
     *       flag.
     *     <p>
     *       The memory allocated by this function must be freed with
     *       cuMemFreeHost().
     *     <p>
     *       Note all host memory allocated using cuMemHostAlloc() will automatically
     *       be immediately accessible to all contexts on all devices which support
     *       unified addressing (as may be queried using
     *       CU_DEVICE_ATTRIBUTE_UNIFIED_ADDRESSING). Unless the flag
     *       CU_MEMHOSTALLOC_WRITECOMBINED is specified, the device pointer that
     *       may be used to access this host memory from those contexts is always
     *       equal to the returned host pointer <code>*pp</code>. If the flag
     *       CU_MEMHOSTALLOC_WRITECOMBINED is specified, then the function
     *       cuMemHostGetDevicePointer() must be used to query the device pointer,
     *       even if the context supports unified addressing. See Unified Addressing
     *       for additional details.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemHostAlloc(Pointer pp, long bytes, int Flags)
    {
        return checkResult(cuMemHostAllocNative(pp, bytes, Flags));
    }
    private static native int cuMemHostAllocNative(Pointer pp, long bytes, int Flags);


    /**
     * Passes back device pointer of mapped pinned memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemHostGetDevicePointer           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>pdptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>p</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Passes back the device pointer <code>pdptr</code> corresponding to the
     *       mapped, pinned host buffer <code>p</code> allocated by
     *       cuMemHostAlloc.
     *     <p>
     *       cuMemHostGetDevicePointer() will fail if the CU_MEMALLOCHOST_DEVICEMAP
     *       flag was not specified at the time the memory was allocated, or if the
     *       function is called on a GPU that does not support mapped pinned
     *       memory.
     *     <p>
     *       <code>Flags</code> provides for future releases. For now, it must be
     *       set to 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemHostGetDevicePointer(CUdeviceptr ret, Pointer p, int Flags)
    {
        return checkResult(cuMemHostGetDevicePointerNative(ret, p, Flags));
    }
    private static native int cuMemHostGetDevicePointerNative(CUdeviceptr ret, Pointer p, int Flags);


    /**
     * Passes back flags that were used for a pinned allocation.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemHostGetFlags           </td>
     *         <td>(</td>
     *         <td>unsigned int *&nbsp;</td>
     *         <td> <em>pFlags</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>p</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Passes back the flags <code>pFlags</code> that were specified when
     *       allocating the pinned host buffer <code>p</code> allocated by
     *       cuMemHostAlloc.
     *     <p>
     *       cuMemHostGetFlags() will fail if the pointer does not reside in an
     *       allocation performed by cuMemAllocHost() or cuMemHostAlloc().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemHostAlloc
     */
    public static int cuMemHostGetFlags (int pFlags[], Pointer p)
    {
        return checkResult(cuMemHostGetFlagsNative(pFlags, p));
    }

    private static native int cuMemHostGetFlagsNative(int pFlags[], Pointer p);


    /**
     * Registers an existing host memory range for use by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemHostRegister           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>p</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>bytesize</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Page-locks the memory range specified by <code>p</code> and
     *       <code>bytesize</code> and maps it for the device(s) as specified by
     *       <code>Flags</code>. This memory range also is added to the same tracking
     *       mechanism as cuMemHostAlloc to automatically accelerate calls to
     *       functions such as cuMemcpyHtoD(). Since the memory can be accessed
     *       directly by the device, it can be read or written with much higher
     *       bandwidth than pageable memory that has not been registered. Page-locking
     *       excessive amounts of memory may degrade system performance, since it
     *       reduces the amount of memory available to the system for paging. As a
     *       result, this function is best used sparingly to register staging areas
     *       for data exchange between host and device.
     *     <p>
     *       This function is not yet supported on Mac OS X.
     *     <p>
     *       The <code>Flags</code> parameter enables different options to be
     *       specified that affect the allocation, as follows.
     *     <p>
     *     <ul>
     *       <li>CU_MEMHOSTREGISTER_PORTABLE: The memory returned by this call will
     *         be considered as pinned memory by all CUDA contexts, not just the one
     *         that performed the allocation.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_MEMHOSTREGISTER_DEVICEMAP: Maps the allocation into the CUDA
     *         address space. The device pointer to the memory may be obtained by
     *         calling cuMemHostGetDevicePointer(). This feature is available only on
     *         GPUs with compute capability greater than or equal to 1.1.
     *       </li>
     *     </ul>
     *     <p>
     *       All of these flags are orthogonal to one another: a developer may
     *       page-lock memory that is portable or mapped with no restrictions.
     *     <p>
     *       The CUDA context must have been created with the CU_CTX_MAP_HOST flag
     *       in order for the CU_MEMHOSTREGISTER_DEVICEMAP flag to have any
     *       effect.
     *     <p>
     *       The CU_MEMHOSTREGISTER_DEVICEMAP flag may be specified on CUDA contexts
     *       for devices that do not support mapped pinned memory. The failure is
     *       deferred to cuMemHostGetDevicePointer() because the memory may be
     *       mapped into other CUDA contexts via the CU_MEMHOSTREGISTER_PORTABLE
     *       flag.
     *     <p>
     *       The pointer <code>p</code> and size <code>bytesize</code> must be
     *       aligned to the host page size (4 KB).
     *     <p>
     *       The memory page-locked by this function must be unregistered with
     *       cuMemHostUnregister().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuMemHostUnregister
     * @see JCudaDriver#cuMemHostGetFlags
     * @see JCudaDriver#cuMemHostGetDevicePointer
     */
    public static int cuMemHostRegister(Pointer p, long bytesize, int Flags)
    {
        return checkResult(cuMemHostRegisterNative(p, bytesize, Flags));
    }
    private static native int cuMemHostRegisterNative(Pointer p, long bytesize, int Flags);


    /**
     * Unregisters a memory range that was registered with
     * cuMemHostRegister().
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemHostUnregister           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>p</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Unmaps the memory range whose base address is specified by
     *       <code>p</code>, and makes it pageable again.
     *     <p>
     *       The base address must be the same one specified to
     *       cuMemHostRegister().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuMemHostRegister
     */
    public static int cuMemHostUnregister(Pointer p)
    {
        return checkResult(cuMemHostUnregisterNative(p));
    }
    private static native int cuMemHostUnregisterNative(Pointer p);


    /**
     * Copies memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpy           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies data between two pointers. <code>dst</code> and <code>src</code>
     *       are base pointers of the destination and source, respectively.
     *       <code>ByteCount</code> specifies the number of bytes to copy. Note that
     *       this function infers the type of the transfer (host to host, host to
     *       device, device to device, or device to host) from the pointer values.
     *       This function is only allowed in contexts which support unified
     *       addressing. Note that this function is synchronous.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpy(CUdeviceptr dst, CUdeviceptr src, long ByteCount)
    {
        return checkResult(cuMemcpyNative(dst, src, ByteCount));
    }
    private static native int cuMemcpyNative(CUdeviceptr dst, CUdeviceptr src, long ByteCount);


    /**
     * Copies device memory between two contexts.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyPeer           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>dstContext</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>srcContext</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from device memory in one context to device memory in another
     *       context. <code>dstDevice</code> is the base device pointer of the
     *       destination memory and <code>dstContext</code> is the destination
     *       context. <code>srcDevice</code> is the base device pointer of the
     *       source memory and <code>srcContext</code> is the source pointer.
     *       <code>ByteCount</code> specifies the number of bytes to copy.
     *     <p>
     *       Note that this function is asynchronous with respect to the host, but
     *       serialized with respect all pending and future asynchronous work in to
     *       the current context, <code>srcContext</code>, and <code>dstContext</code>
     *       (use cuMemcpyPeerAsync to avoid this synchronization).
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpy3DPeer
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyPeerAsync
     * @see JCudaDriver#cuMemcpy3DPeerAsync
     */
    public static int cuMemcpyPeer(CUdeviceptr dstDevice, CUcontext dstContext, CUdeviceptr srcDevice, CUcontext srcContext, long ByteCount)
    {
        return cuMemcpyPeerNative(dstDevice, dstContext, srcDevice, srcContext, ByteCount);
    }
    private static native int cuMemcpyPeerNative(CUdeviceptr dstDevice, CUcontext dstContext, CUdeviceptr srcDevice, CUcontext srcContext, long ByteCount);

    /**
     * Allocates device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemAlloc           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>dptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>bytesize</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates <code>bytesize</code> bytes of linear memory on the device
     *       and returns in <code>*dptr</code> a pointer to the allocated memory.
     *       The allocated memory is suitably aligned for any kind of variable. The
     *       memory is not cleared. If <code>bytesize</code> is 0, cuMemAlloc()
     *       returns CUDA_ERROR_INVALID_VALUE.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemAlloc(CUdeviceptr dptr, long bytesize)
    {
        return checkResult(cuMemAllocNative(dptr, bytesize));
    }

    private static native int cuMemAllocNative(CUdeviceptr dptr, long bytesize);


    /**
     * Allocates pitched device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemAllocPitch           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>dptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>pPitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>WidthInBytes</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>ElementSizeBytes</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates at least <code>WidthInBytes</code> * <code>Height</code>
     *       bytes of linear memory on the device and returns in <code>*dptr</code>
     *       a pointer to the allocated memory. The function may pad the allocation
     *       to ensure that corresponding pointers in any given row will continue
     *       to meet the alignment requirements for coalescing as the address is
     *       updated from row to row. <code>ElementSizeBytes</code> specifies the
     *       size of the largest reads and writes that will be performed on the
     *       memory range. <code>ElementSizeBytes</code> may be 4, 8 or 16 (since
     *       coalesced memory transactions are not possible on other data sizes).
     *       If <code>ElementSizeBytes</code> is smaller than the actual read/write
     *       size of a kernel, the kernel will run correctly, but possibly at
     *       reduced speed. The pitch returned in <code>*pPitch</code> by
     *       cuMemAllocPitch() is the width in bytes of the allocation. The intended
     *       usage of pitch is as a separate parameter of the allocation, used to
     *       compute addresses within the 2D array. Given the row and column of an
     *       array element of type <b>T</b>, the address is computed as:
     *     <div>
     *       <pre>   T* pElement = (T*)((<span>char</span>*)BaseAddress + Row * Pitch)
     * + Column;
     * </pre>
     *     </div>
     *     <p>
     *       The pitch returned by cuMemAllocPitch() is guaranteed to work with
     *       cuMemcpy2D() under all circumstances. For allocations of 2D arrays, it
     *       is recommended that programmers consider performing pitch allocations
     *       using cuMemAllocPitch(). Due to alignment restrictions in the hardware,
     *       this is especially true if the application will be performing 2D memory
     *       copies between different regions of device memory (whether linear
     *       memory or CUDA arrays).
     *     <p>
     *       The byte alignment of the pitch returned by cuMemAllocPitch() is
     *       guaranteed to match or exceed the alignment requirement for texture
     *       binding with cuTexRefSetAddress2D().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemAllocPitch(CUdeviceptr dptr, long pPitch[], long WidthInBytes, long Height, int ElementSizeBytes)
    {
        return checkResult(cuMemAllocPitchNative(dptr, pPitch, WidthInBytes, Height, ElementSizeBytes));
    }

    private static native int cuMemAllocPitchNative(CUdeviceptr dptr, long pPitch[], long WidthInBytes, long Height, int ElementSizeBytes);


    /**
     * Frees device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemFree           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dptr</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Frees the memory space pointed to by <code>dptr</code>, which must have
     *       been returned by a previous call to cuMemAlloc() or
     *       cuMemAllocPitch().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemFree(CUdeviceptr dptr)
    {
        return checkResult(cuMemFreeNative(dptr));
    }

    private static native int cuMemFreeNative(CUdeviceptr dptr);


    /**
     * Get information on memory allocations.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemGetAddressRange           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>pbase</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>psize</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dptr</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns the base address in <code>*pbase</code> and size in
     *       <code>*psize</code> of the allocation by cuMemAlloc() or cuMemAllocPitch()
     *       that contains the input pointer <code>dptr</code>. Both parameters
     *       <code>pbase</code> and <code>psize</code> are optional. If one of them
     *       is NULL, it is ignored.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemGetAddressRange(CUdeviceptr pbase, long psize[], CUdeviceptr dptr)
    {
        return checkResult(cuMemGetAddressRangeNative(pbase, psize, dptr));
    }

    private static native int cuMemGetAddressRangeNative(CUdeviceptr pbase, long psize[], CUdeviceptr dptr);


    /**
     * Allocates page-locked host memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemAllocHost           </td>
     *         <td>(</td>
     *         <td>void **&nbsp;</td>
     *         <td> <em>pp</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>bytesize</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Allocates <code>bytesize</code> bytes of host memory that is page-locked
     *       and accessible to the device. The driver tracks the virtual memory
     *       ranges allocated with this function and automatically accelerates calls
     *       to functions such as cuMemcpy(). Since the memory can be accessed
     *       directly by the device, it can be read or written with much higher
     *       bandwidth than pageable memory obtained with functions such as malloc().
     *       Allocating excessive amounts of memory with cuMemAllocHost() may
     *       degrade system performance, since it reduces the amount of memory
     *       available to the system for paging. As a result, this function is best
     *       used sparingly to allocate staging areas for data exchange between host
     *       and device.
     *     <p>
     *       Note all host memory allocated using cuMemHostAlloc() will automatically
     *       be immediately accessible to all contexts on all devices which support
     *       unified addressing (as may be queried using
     *       CU_DEVICE_ATTRIBUTE_UNIFIED_ADDRESSING). The device pointer that may
     *       be used to access this host memory from those contexts is always equal
     *       to the returned host pointer <code>*pp</code>. See Unified Addressing
     *       for additional details.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemAllocHost(Pointer pointer, long bytesize)
    {
        return checkResult(cuMemAllocHostNative(pointer, bytesize));
    }

    private static native int cuMemAllocHostNative(Pointer pp, long bytesize);


    /**
     * Frees page-locked host memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemFreeHost           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>p</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Frees the memory space pointed to by <code>p</code>, which must have
     *       been returned by a previous call to cuMemAllocHost().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemFreeHost(Pointer p)
    {
        return checkResult(cuMemFreeHostNative(p));
    }

    private static native int cuMemFreeHostNative(Pointer p);


    /**
     * Copies memory from Host to Device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyHtoD           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>srcHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from host memory to device memory. <code>dstDevice</code> and
     *       <code>srcHost</code> are the base addresses of the destination and
     *       source, respectively. <code>ByteCount</code> specifies the number of
     *       bytes to copy. Note that this function is synchronous.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpyHtoD(CUdeviceptr dstDevice, Pointer srcHost, long ByteCount)
    {
        return checkResult(cuMemcpyHtoDNative(dstDevice, srcHost, ByteCount));
    }

    private static native int cuMemcpyHtoDNative(CUdeviceptr dstDevice, Pointer srcHost, long ByteCount);


    /**
     * Copies memory from Device to Host.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyDtoH           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dstHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from device to host memory. <code>dstHost</code> and
     *       <code>srcDevice</code> specify the base pointers of the destination
     *       and source, respectively. <code>ByteCount</code> specifies the number
     *       of bytes to copy. Note that this function is synchronous.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpyDtoH(Pointer dstHost, CUdeviceptr srcDevice, long ByteCount)
    {
        return checkResult(cuMemcpyDtoHNative(dstHost, srcDevice, ByteCount));
    }

    private static native int cuMemcpyDtoHNative(Pointer dstHost, CUdeviceptr srcDevice, long ByteCount);


    /**
     * Copies memory from Device to Device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyDtoD           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from device memory to device memory. <code>dstDevice</code> and
     *       <code>srcDevice</code> are the base pointers of the destination and
     *       source, respectively. <code>ByteCount</code> specifies the number of
     *       bytes to copy. Note that this function is asynchronous.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpyDtoD(CUdeviceptr dstDevice, CUdeviceptr srcDevice, long ByteCount)
    {
        return checkResult(cuMemcpyDtoDNative(dstDevice, srcDevice, ByteCount));
    }

    private static native int cuMemcpyDtoDNative(CUdeviceptr dstDevice, CUdeviceptr srcDevice, long ByteCount);


    /**
     * Copies memory from Device to Array.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyDtoA           </td>
     *         <td>(</td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>dstArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from device memory to a 1D CUDA array. <code>dstArray</code>
     *       and <code>dstOffset</code> specify the CUDA array handle and starting
     *       index of the destination data. <code>srcDevice</code> specifies the
     *       base pointer of the source. <code>ByteCount</code> specifies the number
     *       of bytes to copy.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpyDtoA(CUarray dstArray, long dstIndex, CUdeviceptr srcDevice, long ByteCount)
    {
        return checkResult(cuMemcpyDtoANative(dstArray, dstIndex, srcDevice, ByteCount));
    }

    private static native int cuMemcpyDtoANative(CUarray dstArray, long dstIndex, CUdeviceptr srcDevice, long ByteCount);


    /**
     * Copies memory from Array to Device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyAtoD           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>srcArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>srcOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from one 1D CUDA array to device memory. <code>dstDevice</code>
     *       specifies the base pointer of the destination and must be naturally
     *       aligned with the CUDA array elements. <code>srcArray</code> and
     *       <code>srcOffset</code> specify the CUDA array handle and the offset in
     *       bytes into the array where the copy is to begin. <code>ByteCount</code>
     *       specifies the number of bytes to copy and must be evenly divisible by
     *       the array element size.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpyAtoD(CUdeviceptr dstDevice, CUarray hSrc, long SrcIndex, long ByteCount)
    {
        return checkResult(cuMemcpyAtoDNative(dstDevice, hSrc, SrcIndex, ByteCount));
    }

    private static native int cuMemcpyAtoDNative(CUdeviceptr dstDevice, CUarray hSrc, long SrcIndex, long ByteCount);


    /**
     * Copies memory from Host to Array.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyHtoA           </td>
     *         <td>(</td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>dstArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>srcHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from host memory to a 1D CUDA array. <code>dstArray</code> and
     *       <code>dstOffset</code> specify the CUDA array handle and starting
     *       offset in bytes of the destination data. <code>pSrc</code> specifies
     *       the base address of the source. <code>ByteCount</code> specifies the
     *       number of bytes to copy.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpyHtoA(CUarray dstArray, long dstIndex, Pointer pSrc, long ByteCount)
    {
        return checkResult(cuMemcpyHtoANative(dstArray, dstIndex, pSrc, ByteCount));
    }

    private static native int cuMemcpyHtoANative(CUarray dstArray, long dstIndex, Pointer pSrc, long ByteCount);




    /**
     * Copies memory from Array to Host.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyAtoH           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dstHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>srcArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>srcOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from one 1D CUDA array to host memory. <code>dstHost</code>
     *       specifies the base pointer of the destination. <code>srcArray</code>
     *       and <code>srcOffset</code> specify the CUDA array handle and starting
     *       offset in bytes of the source data. <code>ByteCount</code> specifies
     *       the number of bytes to copy.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpyAtoH(Pointer dstHost, CUarray srcArray, long srcIndex, long ByteCount)
    {
        return checkResult(cuMemcpyAtoHNative(dstHost, srcArray, srcIndex, ByteCount));
    }

    private static native int cuMemcpyAtoHNative(Pointer dstHost, CUarray srcArray, long srcIndex, long ByteCount);


    /**
     * Copies memory from Array to Array.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyAtoA           </td>
     *         <td>(</td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>dstArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>srcArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>srcOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from one 1D CUDA array to another. <code>dstArray</code> and
     *       <code>srcArray</code> specify the handles of the destination and source
     *       CUDA arrays for the copy, respectively. <code>dstOffset</code> and
     *       <code>srcOffset</code> specify the destination and source offsets in
     *       bytes into the CUDA arrays. <code>ByteCount</code> is the number of
     *       bytes to be copied. The size of the elements in the CUDA arrays need
     *       not be the same format, but the elements must be the same size; and
     *       count must be evenly divisible by that size.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpyAtoA(CUarray dstArray, long dstIndex, CUarray srcArray, long srcIndex, long ByteCount)
    {
        return checkResult(cuMemcpyAtoANative(dstArray, dstIndex, srcArray, srcIndex, ByteCount));
    }

    private static native int cuMemcpyAtoANative(CUarray dstArray, long dstIndex, CUarray srcArray, long srcIndex, long ByteCount);


    /**
     * Copies memory for 2D arrays.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpy2D           </td>
     *         <td>(</td>
     *         <td>const CUDA_MEMCPY2D *&nbsp;</td>
     *         <td> <em>pCopy</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 2D memory copy according to the parameters specified in
     *       <code>pCopy</code>. The CUDA_MEMCPY2D structure is defined as:
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>struct </span>CUDA_MEMCPY2D_st
     * {
     *       <span>unsigned</span> <span>int</span> srcXInBytes, srcY;
     *       CUmemorytype srcMemoryType;
     *           <span>const</span> <span>void</span> *srcHost;
     *           CUdeviceptr srcDevice;
     *           CUarray srcArray;
     *           <span>unsigned</span> <span>int</span> srcPitch;
     *
     *       <span>unsigned</span> <span>int</span> dstXInBytes, dstY;
     *       CUmemorytype dstMemoryType;
     *           <span>void</span> *dstHost;
     *           CUdeviceptr dstDevice;
     *           CUarray dstArray;
     *           <span>unsigned</span> <span>int</span> dstPitch;
     *
     *       <span>unsigned</span> <span>int</span> WidthInBytes;
     *       <span>unsigned</span> <span>int</span> Height;
     *    } CUDA_MEMCPY2D;
     * </pre>
     *     </div>
     *     where:
     *     <ul>
     *       <li>srcMemoryType and dstMemoryType specify the type of memory of the
     *         source and destination, respectively; CUmemorytype_enum is defined
     *         as:
     *       </li>
     *     </ul>
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>enum</span> CUmemorytype_enum
     * {
     *       CU_MEMORYTYPE_HOST = 0x01,
     *       CU_MEMORYTYPE_DEVICE = 0x02,
     *       CU_MEMORYTYPE_ARRAY = 0x03,
     *       CU_MEMORYTYPE_UNIFIED = 0x04
     *    } CUmemorytype;
     * </pre>
     *     </div>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         srcDevice and srcPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. srcArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_HOST,
     *         srcHost and srcPitch specify the (host) base address of the source data
     *         and the bytes per row to apply. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_DEVICE,
     *         srcDevice and srcPitch specify the (device) base address of the source
     *         data and the bytes per row to apply. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_ARRAY,
     *         srcArray specifies the handle of the source data. srcHost, srcDevice
     *         and srcPitch are ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_HOST,
     *         dstHost and dstPitch specify the (host) base address of the destination
     *         data and the bytes per row to apply. dstArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         dstDevice and dstPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. dstArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_DEVICE,
     *         dstDevice and dstPitch specify the (device) base address of the
     *         destination data and the bytes per row to apply. dstArray is
     *         ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_ARRAY,
     *         dstArray specifies the handle of the destination data. dstHost,
     *         dstDevice and dstPitch are ignored.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>srcXInBytes and srcY specify the base address of the source data
     *         for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the starting
     *         address is
     *         <div>
     *           <pre>  <span>void</span>* Start = (<span>void</span>*)((<span>char</span>*)srcHost+srcY*srcPitch +
     * srcXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr Start =
     * srcDevice+srcY*srcPitch+srcXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, srcXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>dstXInBytes and dstY specify the base address of the destination
     *         data for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the base address
     *         is
     *         <div>
     *           <pre>  <span>void</span>* dstStart = (<span>void</span>*)((<span>char</span>*)dstHost+dstY*dstPitch +
     * dstXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr dstStart =
     * dstDevice+dstY*dstPitch+dstXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, dstXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>WidthInBytes and Height specify the width (in bytes) and height of
     *         the 2D copy being performed.
     *       </li>
     *       <li>If specified, srcPitch must be
     *         greater than or equal to WidthInBytes + srcXInBytes, and dstPitch must
     *         be greater than or equal to WidthInBytes + dstXInBytes.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>cuMemcpy2D() returns an error if any
     *         pitch is greater than the maximum allowed (CU_DEVICE_ATTRIBUTE_MAX_PITCH).
     *         cuMemAllocPitch() passes back pitches that always work with cuMemcpy2D().
     *         On intra-device memory copies (device to device, CUDA array to device,
     *         CUDA array to CUDA array), cuMemcpy2D() may fail for pitches not
     *         computed by cuMemAllocPitch(). cuMemcpy2DUnaligned() does not have this
     *         restriction, but may run significantly slower in the cases where
     *         cuMemcpy2D() would have returned an error code.
     *       </dd>
     *     </dl>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpy2D(CUDA_MEMCPY2D pCopy)
    {
        return checkResult(cuMemcpy2DNative(pCopy));
    }

    private static native int cuMemcpy2DNative(CUDA_MEMCPY2D pCopy);


    /**
     * Copies memory for 2D arrays.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpy2DUnaligned           </td>
     *         <td>(</td>
     *         <td>const CUDA_MEMCPY2D *&nbsp;</td>
     *         <td> <em>pCopy</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 2D memory copy according to the parameters specified in
     *       <code>pCopy</code>. The CUDA_MEMCPY2D structure is defined as:
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>struct </span>CUDA_MEMCPY2D_st
     * {
     *       <span>unsigned</span> <span>int</span> srcXInBytes, srcY;
     *       CUmemorytype srcMemoryType;
     *       <span>const</span> <span>void</span> *srcHost;
     *       CUdeviceptr srcDevice;
     *       CUarray srcArray;
     *       <span>unsigned</span> <span>int</span> srcPitch;
     *       <span>unsigned</span> <span>int</span> dstXInBytes, dstY;
     *       CUmemorytype dstMemoryType;
     *       <span>void</span> *dstHost;
     *       CUdeviceptr dstDevice;
     *       CUarray dstArray;
     *       <span>unsigned</span> <span>int</span> dstPitch;
     *       <span>unsigned</span> <span>int</span> WidthInBytes;
     *       <span>unsigned</span> <span>int</span> Height;
     *    } CUDA_MEMCPY2D;
     * </pre>
     *     </div>
     *     where:
     *     <ul>
     *       <li>srcMemoryType and dstMemoryType specify the type of memory of the
     *         source and destination, respectively; CUmemorytype_enum is defined
     *         as:
     *       </li>
     *     </ul>
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>enum</span> CUmemorytype_enum
     * {
     *       CU_MEMORYTYPE_HOST = 0x01,
     *       CU_MEMORYTYPE_DEVICE = 0x02,
     *       CU_MEMORYTYPE_ARRAY = 0x03,
     *       CU_MEMORYTYPE_UNIFIED = 0x04
     *    } CUmemorytype;
     * </pre>
     *     </div>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         srcDevice and srcPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. srcArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_HOST,
     *         srcHost and srcPitch specify the (host) base address of the source data
     *         and the bytes per row to apply. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_DEVICE,
     *         srcDevice and srcPitch specify the (device) base address of the source
     *         data and the bytes per row to apply. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_ARRAY,
     *         srcArray specifies the handle of the source data. srcHost, srcDevice
     *         and srcPitch are ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         dstDevice and dstPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. dstArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_HOST,
     *         dstHost and dstPitch specify the (host) base address of the destination
     *         data and the bytes per row to apply. dstArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_DEVICE,
     *         dstDevice and dstPitch specify the (device) base address of the
     *         destination data and the bytes per row to apply. dstArray is
     *         ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_ARRAY,
     *         dstArray specifies the handle of the destination data. dstHost,
     *         dstDevice and dstPitch are ignored.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>srcXInBytes and srcY specify the base address of the source data
     *         for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the starting
     *         address is
     *         <div>
     *           <pre>  <span>void</span>* Start = (<span>void</span>*)((<span>char</span>*)srcHost+srcY*srcPitch +
     * srcXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr Start =
     * srcDevice+srcY*srcPitch+srcXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, srcXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>dstXInBytes and dstY specify the base address of the destination
     *         data for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the base address
     *         is
     *         <div>
     *           <pre>  <span>void</span>* dstStart = (<span>void</span>*)((<span>char</span>*)dstHost+dstY*dstPitch +
     * dstXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr dstStart =
     * dstDevice+dstY*dstPitch+dstXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, dstXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>WidthInBytes and Height specify the width (in bytes) and height of
     *         the 2D copy being performed.
     *       </li>
     *       <li>If specified, srcPitch must be
     *         greater than or equal to WidthInBytes + srcXInBytes, and dstPitch must
     *         be greater than or equal to WidthInBytes + dstXInBytes.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>cuMemcpy2D() returns an error if any
     *         pitch is greater than the maximum allowed (CU_DEVICE_ATTRIBUTE_MAX_PITCH).
     *         cuMemAllocPitch() passes back pitches that always work with cuMemcpy2D().
     *         On intra-device memory copies (device to device, CUDA array to device,
     *         CUDA array to CUDA array), cuMemcpy2D() may fail for pitches not
     *         computed by cuMemAllocPitch(). cuMemcpy2DUnaligned() does not have this
     *         restriction, but may run significantly slower in the cases where
     *         cuMemcpy2D() would have returned an error code.
     *       </dd>
     *     </dl>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpy2DUnaligned(CUDA_MEMCPY2D pCopy)
    {
        return checkResult(cuMemcpy2DUnalignedNative(pCopy));
    }

    private static native int cuMemcpy2DUnalignedNative(CUDA_MEMCPY2D pCopy);


    /**
     * Copies memory for 3D arrays.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpy3D           </td>
     *         <td>(</td>
     *         <td>const CUDA_MEMCPY3D *&nbsp;</td>
     *         <td> <em>pCopy</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 3D memory copy according to the parameters specified in
     *       <code>pCopy</code>. The CUDA_MEMCPY3D structure is defined as:
     *     <p>
     *     <div>
     *       <pre>        <span>typedef</span> <span>struct
     * </span>CUDA_MEMCPY3D_st {
     *
     *             <span>unsigned</span> <span>int</span> srcXInBytes, srcY,
     * srcZ;
     *             <span>unsigned</span> <span>int</span> srcLOD;
     *             CUmemorytype srcMemoryType;
     *                 <span>const</span> <span>void</span> *srcHost;
     *                 CUdeviceptr srcDevice;
     *                 CUarray srcArray;
     *                 <span>unsigned</span> <span>int</span> srcPitch;
     * <span>// ignored when src is array</span>
     *                 <span>unsigned</span> <span>int</span> srcHeight;
     * <span>// ignored when src is array; may be 0 if Depth==1</span>
     *
     *             <span>unsigned</span> <span>int</span> dstXInBytes, dstY,
     * dstZ;
     *             <span>unsigned</span> <span>int</span> dstLOD;
     *             CUmemorytype dstMemoryType;
     *                 <span>void</span> *dstHost;
     *                 CUdeviceptr dstDevice;
     *                 CUarray dstArray;
     *                 <span>unsigned</span> <span>int</span> dstPitch;
     * <span>// ignored when dst is array</span>
     *                 <span>unsigned</span> <span>int</span> dstHeight;
     * <span>// ignored when dst is array; may be 0 if Depth==1</span>
     *
     *             <span>unsigned</span> <span>int</span> WidthInBytes;
     *             <span>unsigned</span> <span>int</span> Height;
     *             <span>unsigned</span> <span>int</span> Depth;
     *         } CUDA_MEMCPY3D;
     * </pre>
     *     </div>
     *     where:
     *     <ul>
     *       <li>srcMemoryType and dstMemoryType specify the type of memory of the
     *         source and destination, respectively; CUmemorytype_enum is defined
     *         as:
     *       </li>
     *     </ul>
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>enum</span> CUmemorytype_enum
     * {
     *       CU_MEMORYTYPE_HOST = 0x01,
     *       CU_MEMORYTYPE_DEVICE = 0x02,
     *       CU_MEMORYTYPE_ARRAY = 0x03,
     *       CU_MEMORYTYPE_UNIFIED = 0x04
     *    } CUmemorytype;
     * </pre>
     *     </div>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         srcDevice and srcPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. srcArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_HOST,
     *         srcHost, srcPitch and srcHeight specify the (host) base address of the
     *         source data, the bytes per row, and the height of each 2D slice of the
     *         3D array. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_DEVICE,
     *         srcDevice, srcPitch and srcHeight specify the (device) base address of
     *         the source data, the bytes per row, and the height of each 2D slice of
     *         the 3D array. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_ARRAY,
     *         srcArray specifies the handle of the source data. srcHost, srcDevice,
     *         srcPitch and srcHeight are ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         dstDevice and dstPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. dstArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_HOST,
     *         dstHost and dstPitch specify the (host) base address of the destination
     *         data, the bytes per row, and the height of each 2D slice of the 3D
     *         array. dstArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_DEVICE,
     *         dstDevice and dstPitch specify the (device) base address of the
     *         destination data, the bytes per row, and the height of each 2D slice
     *         of the 3D array. dstArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_ARRAY,
     *         dstArray specifies the handle of the destination data. dstHost,
     *         dstDevice, dstPitch and dstHeight are ignored.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>srcXInBytes, srcY and srcZ specify the base address of the source
     *         data for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the starting
     *         address is
     *         <div>
     *           <pre>  <span>void</span>* Start = (<span>void</span>*)((<span>char</span>*)srcHost+(srcZ*srcHeight+srcY)*srcPitch
     * + srcXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr Start =
     * srcDevice+(srcZ*srcHeight+srcY)*srcPitch+srcXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, srcXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>dstXInBytes, dstY and dstZ specify the base address of the
     *         destination data for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the base address
     *         is
     *         <div>
     *           <pre>  <span>void</span>* dstStart = (<span>void</span>*)((<span>char</span>*)dstHost+(dstZ*dstHeight+dstY)*dstPitch
     * + dstXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr dstStart =
     * dstDevice+(dstZ*dstHeight+dstY)*dstPitch+dstXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, dstXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>WidthInBytes, Height and Depth specify the width (in bytes), height
     *         and depth of the 3D copy being performed.
     *       </li>
     *       <li>If specified, srcPitch
     *         must be greater than or equal to WidthInBytes + srcXInBytes, and
     *         dstPitch must be greater than or equal to WidthInBytes +
     *         dstXInBytes.
     *       </li>
     *       <li>If specified, srcHeight must be greater than or
     *         equal to Height + srcY, and dstHeight must be greater than or equal to
     *         Height + dstY.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>cuMemcpy3D() returns an error if any
     *         pitch is greater than the maximum allowed
     *         (CU_DEVICE_ATTRIBUTE_MAX_PITCH).
     *       </dd>
     *     </dl>
     *     The srcLOD and dstLOD members of the CUDA_MEMCPY3D structure must be
     *     set to 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemcpy3D(CUDA_MEMCPY3D pCopy)
    {
        return checkResult(cuMemcpy3DNative(pCopy));
    }

    private static native int cuMemcpy3DNative(CUDA_MEMCPY3D pCopy);


    /**
     * Copies memory between contexts.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpy3DPeer           </td>
     *         <td>(</td>
     *         <td>const CUDA_MEMCPY3D_PEER *&nbsp;</td>
     *         <td> <em>pCopy</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 3D memory copy according to the parameters specified in
     *       <code>pCopy</code>. See the definition of the CUDA_MEMCPY3D_PEER
     *       structure for documentation of its parameters.
     *     <p>
     *       Note that this function is synchronous with respect to the host only
     *       if the source or destination memory is of type CU_MEMORYTYPE_HOST. Note
     *       also that this copy is serialized with respect all pending and future
     *       asynchronous work in to the current context, the copy's source context,
     *       and the copy's destination context (use cuMemcpy3DPeerAsync to avoid
     *       this synchronization).
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyPeer
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyPeerAsync
     * @see JCudaDriver#cuMemcpy3DPeerAsync
     */
    public static int cuMemcpy3DPeer(CUDA_MEMCPY3D_PEER pCopy)
    {
        return checkResult(cuMemcpy3DPeerNative(pCopy));
    }
    private static native int cuMemcpy3DPeerNative(CUDA_MEMCPY3D_PEER pCopy);


    /**
     * Copies memory asynchronously.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyAsync           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dst</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>src</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies data between two pointers. <code>dst</code> and <code>src</code>
     *       are base pointers of the destination and source, respectively.
     *       <code>ByteCount</code> specifies the number of bytes to copy. Note that
     *       this function infers the type of the transfer (host to host, host to
     *       device, device to device, or device to host) from the pointer values.
     *       This function is only allowed in contexts which support unified
     *       addressing. Note that this function is asynchronous and can optionally
     *       be associated to a stream by passing a non-zero <code>hStream</code>
     *       argument
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemcpyAsync(CUdeviceptr dst, CUdeviceptr src, long ByteCount, CUstream hStream)
    {
        return checkResult(cuMemcpyAsyncNative(dst, src, ByteCount, hStream));
    }
    private static native int cuMemcpyAsyncNative(CUdeviceptr dst, CUdeviceptr src, long ByteCount, CUstream hStream);


    /**
     * Copies device memory between two contexts asynchronously.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyPeerAsync           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>dstContext</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>srcContext</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from device memory in one context to device memory in another
     *       context. <code>dstDevice</code> is the base device pointer of the
     *       destination memory and <code>dstContext</code> is the destination
     *       context. <code>srcDevice</code> is the base device pointer of the
     *       source memory and <code>srcContext</code> is the source pointer.
     *       <code>ByteCount</code> specifies the number of bytes to copy. Note that
     *       this function is asynchronous with respect to the host and all work in
     *       other streams in other devices.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyPeer
     * @see JCudaDriver#cuMemcpy3DPeer
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpy3DPeerAsync
     */
    public static int cuMemcpyPeerAsync(CUdeviceptr dstDevice, CUcontext dstContext, CUdeviceptr srcDevice, CUcontext srcContext, long ByteCount, CUstream hStream)
    {
        return checkResult(cuMemcpyPeerAsyncNative(dstDevice, dstContext, srcDevice, srcContext, ByteCount, hStream));
    }
    private static native int cuMemcpyPeerAsyncNative(CUdeviceptr dstDevice, CUcontext dstContext, CUdeviceptr srcDevice, CUcontext srcContext, long ByteCount, CUstream hStream);


    /**
     * Copies memory from Host to Device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyHtoDAsync           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>srcHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from host memory to device memory. <code>dstDevice</code> and
     *       <code>srcHost</code> are the base addresses of the destination and
     *       source, respectively. <code>ByteCount</code> specifies the number of
     *       bytes to copy.
     *     <p>
     *       cuMemcpyHtoDAsync() is asynchronous and can optionally be associated
     *       to a stream by passing a non-zero <code>hStream</code> argument. It
     *       only works on page-locked memory and returns an error if a pointer to
     *       pageable memory is passed as input.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemcpyHtoDAsync(CUdeviceptr dstDevice, Pointer srcHost, long ByteCount, CUstream hStream)
    {
        return checkResult(cuMemcpyHtoDAsyncNative(dstDevice, srcHost, ByteCount, hStream));
    }

    private static native int cuMemcpyHtoDAsyncNative(CUdeviceptr dstDevice, Pointer srcHost, long ByteCount, CUstream hStream);


    /**
     * Copies memory from Device to Host.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyDtoHAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dstHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from device to host memory. <code>dstHost</code> and
     *       <code>srcDevice</code> specify the base pointers of the destination
     *       and source, respectively. <code>ByteCount</code> specifies the number
     *       of bytes to copy.
     *     <p>
     *       cuMemcpyDtoHAsync() is asynchronous and can optionally be associated
     *       to a stream by passing a non-zero <code>hStream</code> argument. It
     *       only works on page-locked memory and returns an error if a pointer to
     *       pageable memory is passed as input.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemcpyDtoHAsync(Pointer dstHost,CUdeviceptr srcDevice, long ByteCount, CUstream hStream)
    {
        return checkResult(cuMemcpyDtoHAsyncNative(dstHost, srcDevice, ByteCount, hStream));
    }

    private static native int cuMemcpyDtoHAsyncNative(Pointer dstHost,CUdeviceptr srcDevice, long ByteCount, CUstream hStream);

    /**
     * Copies memory from Device to Device.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyDtoDAsync           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>srcDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from device memory to device memory. <code>dstDevice</code> and
     *       <code>srcDevice</code> are the base pointers of the destination and
     *       source, respectively. <code>ByteCount</code> specifies the number of
     *       bytes to copy. Note that this function is asynchronous and can
     *       optionally be associated to a stream by passing a non-zero
     *       <code>hStream</code> argument
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemcpyDtoDAsync(CUdeviceptr dstDevice,CUdeviceptr srcDevice, long ByteCount, CUstream hStream)
    {
        return checkResult(cuMemcpyDtoDAsyncNative(dstDevice, srcDevice, ByteCount, hStream));
    }

    private static native int cuMemcpyDtoDAsyncNative(CUdeviceptr dstDevice,CUdeviceptr srcDevice, long ByteCount, CUstream hStream);


    /**
     * Copies memory from Host to Array.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyHtoAAsync           </td>
     *         <td>(</td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>dstArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const void *&nbsp;</td>
     *         <td> <em>srcHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from host memory to a 1D CUDA array. <code>dstArray</code> and
     *       <code>dstOffset</code> specify the CUDA array handle and starting
     *       offset in bytes of the destination data. <code>srcHost</code> specifies
     *       the base address of the source. <code>ByteCount</code> specifies the
     *       number of bytes to copy.
     *     <p>
     *       cuMemcpyHtoAAsync() is asynchronous and can optionally be associated
     *       to a stream by passing a non-zero <code>hStream</code> argument. It
     *       only works on page-locked memory and returns an error if a pointer to
     *       pageable memory is passed as input.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemcpyHtoAAsync(CUarray dstArray, long dstIndex, Pointer pSrc, long ByteCount, CUstream hStream)
    {
        return checkResult(cuMemcpyHtoAAsyncNative(dstArray, dstIndex, pSrc, ByteCount, hStream));
    }

    private static native int cuMemcpyHtoAAsyncNative(CUarray dstArray, long dstIndex, Pointer pSrc, long ByteCount, CUstream hStream);


    /**
     * Copies memory from Array to Host.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpyAtoHAsync           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>dstHost</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>srcArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>srcOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>ByteCount</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Copies from one 1D CUDA array to host memory. <code>dstHost</code>
     *       specifies the base pointer of the destination. <code>srcArray</code>
     *       and <code>srcOffset</code> specify the CUDA array handle and starting
     *       offset in bytes of the source data. <code>ByteCount</code> specifies
     *       the number of bytes to copy.
     *     <p>
     *       cuMemcpyAtoHAsync() is asynchronous and can optionally be associated
     *       to a stream by passing a non-zero <code>stream</code> argument. It only
     *       works on page-locked host memory and returns an error if a pointer to
     *       pageable memory is passed as input.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemcpyAtoHAsync(Pointer dstHost, CUarray srcArray, long srcIndex, long ByteCount, CUstream hStream)
    {
        return checkResult(cuMemcpyAtoHAsyncNative(dstHost, srcArray, srcIndex, ByteCount, hStream));
    }

    private static native int cuMemcpyAtoHAsyncNative(Pointer dstHost, CUarray srcArray, long srcIndex, long ByteCount, CUstream hStream);


    /**
     * Copies memory for 2D arrays.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpy2DAsync           </td>
     *         <td>(</td>
     *         <td>const CUDA_MEMCPY2D *&nbsp;</td>
     *         <td> <em>pCopy</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 2D memory copy according to the parameters specified in
     *       <code>pCopy</code>. The CUDA_MEMCPY2D structure is defined as:
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>struct </span>CUDA_MEMCPY2D_st
     * {
     *       <span>unsigned</span> <span>int</span> srcXInBytes, srcY;
     *       CUmemorytype srcMemoryType;
     *       <span>const</span> <span>void</span> *srcHost;
     *       CUdeviceptr srcDevice;
     *       CUarray srcArray;
     *       <span>unsigned</span> <span>int</span> srcPitch;
     *       <span>unsigned</span> <span>int</span> dstXInBytes, dstY;
     *       CUmemorytype dstMemoryType;
     *       <span>void</span> *dstHost;
     *       CUdeviceptr dstDevice;
     *       CUarray dstArray;
     *       <span>unsigned</span> <span>int</span> dstPitch;
     *       <span>unsigned</span> <span>int</span> WidthInBytes;
     *       <span>unsigned</span> <span>int</span> Height;
     *    } CUDA_MEMCPY2D;
     * </pre>
     *     </div>
     *     where:
     *     <ul>
     *       <li>srcMemoryType and dstMemoryType specify the type of memory of the
     *         source and destination, respectively; CUmemorytype_enum is defined
     *         as:
     *       </li>
     *     </ul>
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>enum</span> CUmemorytype_enum
     * {
     *       CU_MEMORYTYPE_HOST = 0x01,
     *       CU_MEMORYTYPE_DEVICE = 0x02,
     *       CU_MEMORYTYPE_ARRAY = 0x03,
     *       CU_MEMORYTYPE_UNIFIED = 0x04
     *    } CUmemorytype;
     * </pre>
     *     </div>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_HOST,
     *         srcHost and srcPitch specify the (host) base address of the source data
     *         and the bytes per row to apply. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         srcDevice and srcPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. srcArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_DEVICE,
     *         srcDevice and srcPitch specify the (device) base address of the source
     *         data and the bytes per row to apply. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_ARRAY,
     *         srcArray specifies the handle of the source data. srcHost, srcDevice
     *         and srcPitch are ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         dstDevice and dstPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. dstArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_HOST,
     *         dstHost and dstPitch specify the (host) base address of the destination
     *         data and the bytes per row to apply. dstArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_DEVICE,
     *         dstDevice and dstPitch specify the (device) base address of the
     *         destination data and the bytes per row to apply. dstArray is
     *         ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_ARRAY,
     *         dstArray specifies the handle of the destination data. dstHost,
     *         dstDevice and dstPitch are ignored.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>srcXInBytes and srcY specify the base address of the source data
     *         for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the starting
     *         address is
     *         <div>
     *           <pre>  <span>void</span>* Start = (<span>void</span>*)((<span>char</span>*)srcHost+srcY*srcPitch +
     * srcXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr Start =
     * srcDevice+srcY*srcPitch+srcXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, srcXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>dstXInBytes and dstY specify the base address of the destination
     *         data for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the base address
     *         is
     *         <div>
     *           <pre>  <span>void</span>* dstStart = (<span>void</span>*)((<span>char</span>*)dstHost+dstY*dstPitch +
     * dstXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr dstStart =
     * dstDevice+dstY*dstPitch+dstXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, dstXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>WidthInBytes and Height specify the width (in bytes) and height of
     *         the 2D copy being performed.
     *       </li>
     *       <li>If specified, srcPitch must be
     *         greater than or equal to WidthInBytes + srcXInBytes, and dstPitch must
     *         be greater than or equal to WidthInBytes + dstXInBytes.
     *       </li>
     *       <li>If
     *         specified, srcPitch must be greater than or equal to WidthInBytes +
     *         srcXInBytes, and dstPitch must be greater than or equal to WidthInBytes
     *         + dstXInBytes.
     *       </li>
     *       <li>If specified, srcHeight must be greater than or
     *         equal to Height + srcY, and dstHeight must be greater than or equal to
     *         Height + dstY.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>cuMemcpy2D() returns an error if any
     *         pitch is greater than the maximum allowed (CU_DEVICE_ATTRIBUTE_MAX_PITCH).
     *         cuMemAllocPitch() passes back pitches that always work with cuMemcpy2D().
     *         On intra-device memory copies (device to device, CUDA array to device,
     *         CUDA array to CUDA array), cuMemcpy2D() may fail for pitches not
     *         computed by cuMemAllocPitch(). cuMemcpy2DUnaligned() does not have this
     *         restriction, but may run significantly slower in the cases where
     *         cuMemcpy2D() would have returned an error code.
     *       </dd>
     *     </dl>
     *     cuMemcpy2DAsync() is asynchronous and can optionally be associated to
     *     a stream by passing a non-zero <code>hStream</code> argument. It only
     *     works on page-locked host memory and returns an error if a pointer to
     *     pageable memory is passed as input.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemcpy2DAsync(CUDA_MEMCPY2D pCopy, CUstream hStream)
    {
        return checkResult(cuMemcpy2DAsyncNative(pCopy, hStream));
    }

    private static native int cuMemcpy2DAsyncNative(CUDA_MEMCPY2D pCopy, CUstream hStream);


    /**
     * Copies memory for 3D arrays.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpy3DAsync           </td>
     *         <td>(</td>
     *         <td>const CUDA_MEMCPY3D *&nbsp;</td>
     *         <td> <em>pCopy</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 3D memory copy according to the parameters specified in
     *       <code>pCopy</code>. The CUDA_MEMCPY3D structure is defined as:
     *     <p>
     *     <div>
     *       <pre>        <span>typedef</span> <span>struct
     * </span>CUDA_MEMCPY3D_st {
     *
     *             <span>unsigned</span> <span>int</span> srcXInBytes, srcY,
     * srcZ;
     *             <span>unsigned</span> <span>int</span> srcLOD;
     *             CUmemorytype srcMemoryType;
     *                 <span>const</span> <span>void</span> *srcHost;
     *                 CUdeviceptr srcDevice;
     *                 CUarray srcArray;
     *                 <span>unsigned</span> <span>int</span> srcPitch;
     * <span>// ignored when src is array</span>
     *                 <span>unsigned</span> <span>int</span> srcHeight;
     * <span>// ignored when src is array; may be 0 if Depth==1</span>
     *
     *             <span>unsigned</span> <span>int</span> dstXInBytes, dstY,
     * dstZ;
     *             <span>unsigned</span> <span>int</span> dstLOD;
     *             CUmemorytype dstMemoryType;
     *                 <span>void</span> *dstHost;
     *                 CUdeviceptr dstDevice;
     *                 CUarray dstArray;
     *                 <span>unsigned</span> <span>int</span> dstPitch;
     * <span>// ignored when dst is array</span>
     *                 <span>unsigned</span> <span>int</span> dstHeight;
     * <span>// ignored when dst is array; may be 0 if Depth==1</span>
     *
     *             <span>unsigned</span> <span>int</span> WidthInBytes;
     *             <span>unsigned</span> <span>int</span> Height;
     *             <span>unsigned</span> <span>int</span> Depth;
     *         } CUDA_MEMCPY3D;
     * </pre>
     *     </div>
     *     where:
     *     <ul>
     *       <li>srcMemoryType and dstMemoryType specify the type of memory of the
     *         source and destination, respectively; CUmemorytype_enum is defined
     *         as:
     *       </li>
     *     </ul>
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>enum</span> CUmemorytype_enum
     * {
     *       CU_MEMORYTYPE_HOST = 0x01,
     *       CU_MEMORYTYPE_DEVICE = 0x02,
     *       CU_MEMORYTYPE_ARRAY = 0x03,
     *       CU_MEMORYTYPE_UNIFIED = 0x04
     *    } CUmemorytype;
     * </pre>
     *     </div>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         srcDevice and srcPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. srcArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_HOST,
     *         srcHost, srcPitch and srcHeight specify the (host) base address of the
     *         source data, the bytes per row, and the height of each 2D slice of the
     *         3D array. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_DEVICE,
     *         srcDevice, srcPitch and srcHeight specify the (device) base address of
     *         the source data, the bytes per row, and the height of each 2D slice of
     *         the 3D array. srcArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If srcMemoryType is CU_MEMORYTYPE_ARRAY,
     *         srcArray specifies the handle of the source data. srcHost, srcDevice,
     *         srcPitch and srcHeight are ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_UNIFIED,
     *         dstDevice and dstPitch specify the (unified virtual address space) base
     *         address of the source data and the bytes per row to apply. dstArray is
     *         ignored. This value may be used only if unified addressing is supported
     *         in the calling context.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_HOST,
     *         dstHost and dstPitch specify the (host) base address of the destination
     *         data, the bytes per row, and the height of each 2D slice of the 3D
     *         array. dstArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_DEVICE,
     *         dstDevice and dstPitch specify the (device) base address of the
     *         destination data, the bytes per row, and the height of each 2D slice
     *         of the 3D array. dstArray is ignored.
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>If dstMemoryType is CU_MEMORYTYPE_ARRAY,
     *         dstArray specifies the handle of the destination data. dstHost,
     *         dstDevice, dstPitch and dstHeight are ignored.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>srcXInBytes, srcY and srcZ specify the base address of the source
     *         data for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the starting
     *         address is
     *         <div>
     *           <pre>  <span>void</span>* Start = (<span>void</span>*)((<span>char</span>*)srcHost+(srcZ*srcHeight+srcY)*srcPitch
     * + srcXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr Start =
     * srcDevice+(srcZ*srcHeight+srcY)*srcPitch+srcXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, srcXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>dstXInBytes, dstY and dstZ specify the base address of the
     *         destination data for the copy.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For host pointers, the base address
     *         is
     *         <div>
     *           <pre>  <span>void</span>* dstStart = (<span>void</span>*)((<span>char</span>*)dstHost+(dstZ*dstHeight+dstY)*dstPitch
     * + dstXInBytes);
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>
     *         For device pointers, the starting
     *         address is
     *         <div>
     *           <pre>  CUdeviceptr dstStart =
     * dstDevice+(dstZ*dstHeight+dstY)*dstPitch+dstXInBytes;
     * </pre>
     *         </div>
     *       </dd>
     *     </dl>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>For CUDA arrays, dstXInBytes must be
     *         evenly divisible by the array element size.
     *       </dd>
     *     </dl>
     *     <ul>
     *       <li>WidthInBytes, Height and Depth specify the width (in bytes), height
     *         and depth of the 3D copy being performed.
     *       </li>
     *       <li>If specified, srcPitch
     *         must be greater than or equal to WidthInBytes + srcXInBytes, and
     *         dstPitch must be greater than or equal to WidthInBytes +
     *         dstXInBytes.
     *       </li>
     *       <li>If specified, srcHeight must be greater than or
     *         equal to Height + srcY, and dstHeight must be greater than or equal to
     *         Height + dstY.
     *       </li>
     *     </ul>
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd>cuMemcpy3D() returns an error if any
     *         pitch is greater than the maximum allowed
     *         (CU_DEVICE_ATTRIBUTE_MAX_PITCH).
     *       </dd>
     *     </dl>
     *     cuMemcpy3DAsync() is asynchronous and can optionally be associated to
     *     a stream by passing a non-zero <code>hStream</code> argument. It only
     *     works on page-locked host memory and returns an error if a pointer to
     *     pageable memory is passed as input.
     *     <p>
     *       The srcLOD and dstLOD members of the CUDA_MEMCPY3D structure must be
     *       set to 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemcpy3DAsync(CUDA_MEMCPY3D pCopy, CUstream hStream)
    {
        return checkResult(cuMemcpy3DAsyncNative(pCopy, hStream));
    }

    private static native int cuMemcpy3DAsyncNative(CUDA_MEMCPY3D pCopy, CUstream hStream);


    /**
     * Copies memory between contexts asynchronously.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemcpy3DPeerAsync           </td>
     *         <td>(</td>
     *         <td>const CUDA_MEMCPY3D_PEER *&nbsp;</td>
     *         <td> <em>pCopy</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Perform a 3D memory copy according to the parameters specified in
     *       <code>pCopy</code>. See the definition of the CUDA_MEMCPY3D_PEER
     *       structure for documentation of its parameters.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyPeer
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyPeerAsync
     * @see JCudaDriver#cuMemcpy3DPeerAsync
     */
    public static int cuMemcpy3DPeerAsync(CUDA_MEMCPY3D_PEER pCopy, CUstream hStream)
    {
        return checkResult(cuMemcpy3DPeerAsyncNative(pCopy, hStream));
    }
    private static native int cuMemcpy3DPeerAsyncNative(CUDA_MEMCPY3D_PEER pCopy, CUstream hStream);


    /**
     * Initializes device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD8           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned char&nbsp;</td>
     *         <td> <em>uc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>N</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the memory range of <code>N</code> 8-bit values to the specified
     *       value <code>uc</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD8(CUdeviceptr dstDevice, byte uc, long N)
    {
        return checkResult(cuMemsetD8Native(dstDevice, uc, N));
    }

    private static native int cuMemsetD8Native(CUdeviceptr dstDevice, byte uc, long N);


    /**
     * Initializes device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD16           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned short&nbsp;</td>
     *         <td> <em>us</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>N</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the memory range of <code>N</code> 16-bit values to the specified
     *       value <code>us</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD16(CUdeviceptr dstDevice, short us, long N)
    {
        return checkResult(cuMemsetD16Native(dstDevice, us, N));
    }

    private static native int cuMemsetD16Native(CUdeviceptr dstDevice, short us, long N);


    /**
     * Initializes device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD32           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>ui</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>N</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the memory range of <code>N</code> 32-bit values to the specified
     *       value <code>ui</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD32(CUdeviceptr dstDevice, int ui, long N)
    {
        return checkResult(cuMemsetD32Native(dstDevice, ui, N));
    }

    private static native int cuMemsetD32Native(CUdeviceptr dstDevice, int ui, long N);



    /**
     * Initializes device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD2D8           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstPitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned char&nbsp;</td>
     *         <td> <em>uc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Height</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the 2D memory range of <code>Width</code> 8-bit values to the
     *       specified value <code>uc</code>. <code>Height</code> specifies the
     *       number of rows to set, and <code>dstPitch</code> specifies the number
     *       of bytes between each row. This function performs fastest when the
     *       pitch is one that has been passed back by cuMemAllocPitch().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD2D8(CUdeviceptr dstDevice, long dstPitch, byte uc, long Width, long Height)
    {
        return checkResult(cuMemsetD2D8Native(dstDevice, dstPitch, uc, Width, Height));
    }

    private static native int cuMemsetD2D8Native(CUdeviceptr dstDevice, long dstPitch, byte uc, long Width, long Height);


    /**
     * Initializes device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD2D16           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstPitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned short&nbsp;</td>
     *         <td> <em>us</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Height</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the 2D memory range of <code>Width</code> 16-bit values to the
     *       specified value <code>us</code>. <code>Height</code> specifies the
     *       number of rows to set, and <code>dstPitch</code> specifies the number
     *       of bytes between each row. This function performs fastest when the
     *       pitch is one that has been passed back by cuMemAllocPitch().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD2D16(CUdeviceptr dstDevice, long dstPitch, short us, long Width, long Height)
    {
        return checkResult(cuMemsetD2D16Native(dstDevice, dstPitch, us, Width, Height));
    }

    private static native int cuMemsetD2D16Native(CUdeviceptr dstDevice, long dstPitch, short us, long Width, long Height);


    /**
     * Initializes device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD2D32           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstPitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>ui</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Height</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the 2D memory range of <code>Width</code> 32-bit values to the
     *       specified value <code>ui</code>. <code>Height</code> specifies the
     *       number of rows to set, and <code>dstPitch</code> specifies the number
     *       of bytes between each row. This function performs fastest when the
     *       pitch is one that has been passed back by cuMemAllocPitch().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD2D32(CUdeviceptr dstDevice, long dstPitch, int ui, long Width, long Height)
    {
        return checkResult(cuMemsetD2D32Native(dstDevice, dstPitch, ui, Width, Height));
    }

    private static native int cuMemsetD2D32Native(CUdeviceptr dstDevice, long dstPitch, int ui, long Width, long Height);


    /**
     * Sets device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD8Async           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned char&nbsp;</td>
     *         <td> <em>uc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>N</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the memory range of <code>N</code> 8-bit values to the specified
     *       value <code>uc</code>.
     *     <p>
     *       cuMemsetD8Async() is asynchronous and can optionally be associated to
     *       a stream by passing a non-zero <code>stream</code> argument.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD8Async(CUdeviceptr dstDevice, byte uc, long N, CUstream hStream)
    {
        return checkResult(cuMemsetD8AsyncNative(dstDevice, uc, N, hStream));
    }

    private static native int cuMemsetD8AsyncNative(CUdeviceptr dstDevice, byte uc, long N, CUstream hStream);


    /**
     * Sets device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD16Async           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned short&nbsp;</td>
     *         <td> <em>us</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>N</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the memory range of <code>N</code> 16-bit values to the specified
     *       value <code>us</code>.
     *     <p>
     *       cuMemsetD16Async() is asynchronous and can optionally be associated to
     *       a stream by passing a non-zero <code>stream</code> argument.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD16Async(CUdeviceptr dstDevice, short us, long N, CUstream hStream)
    {
        return checkResult(cuMemsetD16AsyncNative(dstDevice, us, N, hStream));
    }

    private static native int cuMemsetD16AsyncNative(CUdeviceptr dstDevice, short us, long N, CUstream hStream);


    /**
     * Sets device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD32Async           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>ui</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>N</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the memory range of <code>N</code> 32-bit values to the specified
     *       value <code>ui</code>.
     *     <p>
     *       cuMemsetD32Async() is asynchronous and can optionally be associated to
     *       a stream by passing a non-zero <code>stream</code> argument.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuMemsetD32Async(CUdeviceptr dstDevice, int ui, long N, CUstream hStream)
    {
        return checkResult(cuMemsetD32AsyncNative(dstDevice, ui, N, hStream));
    }

    private static native int cuMemsetD32AsyncNative(CUdeviceptr dstDevice, int ui, long N, CUstream hStream);



    /**
     * Sets device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD2D8Async           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstPitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned char&nbsp;</td>
     *         <td> <em>uc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the 2D memory range of <code>Width</code> 8-bit values to the
     *       specified value <code>uc</code>. <code>Height</code> specifies the
     *       number of rows to set, and <code>dstPitch</code> specifies the number
     *       of bytes between each row. This function performs fastest when the
     *       pitch is one that has been passed back by cuMemAllocPitch().
     *     <p>
     *       cuMemsetD2D8Async() is asynchronous and can optionally be associated
     *       to a stream by passing a non-zero <code>stream</code> argument.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD2D8Async(CUdeviceptr dstDevice, long dstPitch, byte uc, long Width, long Height, CUstream hStream)
    {
        return checkResult(cuMemsetD2D8AsyncNative(dstDevice, dstPitch, uc, Width, Height, hStream));
    }

    private static native int cuMemsetD2D8AsyncNative(CUdeviceptr dstDevice, long dstPitch, byte uc, long Width, long Height, CUstream hStream);


    /**
     * Sets device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD2D16Async           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstPitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned short&nbsp;</td>
     *         <td> <em>us</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the 2D memory range of <code>Width</code> 16-bit values to the
     *       specified value <code>us</code>. <code>Height</code> specifies the
     *       number of rows to set, and <code>dstPitch</code> specifies the number
     *       of bytes between each row. This function performs fastest when the
     *       pitch is one that has been passed back by cuMemAllocPitch().
     *     <p>
     *       cuMemsetD2D16Async() is asynchronous and can optionally be associated
     *       to a stream by passing a non-zero <code>stream</code> argument.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD2D32Async
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD2D16Async(CUdeviceptr dstDevice, long dstPitch, short us, long Width, long Height, CUstream hStream)
    {
        return checkResult(cuMemsetD2D16AsyncNative(dstDevice, dstPitch, us, Width, Height, hStream));
    }

    private static native int cuMemsetD2D16AsyncNative(CUdeviceptr dstDevice, long dstPitch, short us, long Width, long Height, CUstream hStream);


    /**
     * Sets device memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuMemsetD2D32Async           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dstDevice</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>dstPitch</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>ui</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the 2D memory range of <code>Width</code> 32-bit values to the
     *       specified value <code>ui</code>. <code>Height</code> specifies the
     *       number of rows to set, and <code>dstPitch</code> specifies the number
     *       of bytes between each row. This function performs fastest when the
     *       pitch is one that has been passed back by cuMemAllocPitch().
     *     <p>
     *       cuMemsetD2D32Async() is asynchronous and can optionally be associated
     *       to a stream by passing a non-zero <code>stream</code> argument.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D8Async
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D16Async
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD8Async
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD16Async
     * @see JCudaDriver#cuMemsetD32
     * @see JCudaDriver#cuMemsetD32Async
     */
    public static int cuMemsetD2D32Async(CUdeviceptr dstDevice, long dstPitch, int ui, long Width, long Height, CUstream hStream)
    {
        return checkResult(cuMemsetD2D32AsyncNative(dstDevice, dstPitch, ui, Width, Height, hStream));
    }

    private static native int cuMemsetD2D32AsyncNative(CUdeviceptr dstDevice, long dstPitch, int ui, long Width, long Height, CUstream hStream);


    /**
     * Returns information about a function.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuFuncGetAttribute           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>pi</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUfunction_attribute&nbsp;</td>
     *         <td> <em>attrib</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pi</code> the integer value of the attribute
     *       <code>attrib</code> on the kernel given by <code>hfunc</code>. The
     *       supported attributes are:
     *     <ul>
     *       <li>CU_FUNC_ATTRIBUTE_MAX_THREADS_PER_BLOCK: The maximum number of
     *         threads per block, beyond which a launch of the function would fail.
     *         This number depends on both the function and the device on which the
     *         function is currently loaded.
     *       </li>
     *       <li>CU_FUNC_ATTRIBUTE_SHARED_SIZE_BYTES:
     *         The size in bytes of statically-allocated shared memory per block
     *         required by this function. This does not include dynamically-allocated
     *         shared memory requested by the user at
     *         runtime.
     *       </li>
     *       <li>CU_FUNC_ATTRIBUTE_CONST_SIZE_BYTES: The size in bytes
     *         of user-allocated constant memory required by this
     *         function.
     *       </li>
     *       <li>CU_FUNC_ATTRIBUTE_LOCAL_SIZE_BYTES: The size in bytes
     *         of local memory used by each thread of this
     *         function.
     *       </li>
     *       <li>CU_FUNC_ATTRIBUTE_NUM_REGS: The number of registers
     *         used by each thread of this function.
     *       </li>
     *       <li>CU_FUNC_ATTRIBUTE_PTX_VERSION:
     *         The PTX virtual architecture version for which the function was
     *         compiled. This value is the major PTX version * 10 + the minor PTX
     *         version, so a PTX version 1.3 function would return the value 13. Note
     *         that this may return the undefined value of 0 for cubins compiled prior
     *         to CUDA 3.0.
     *       </li>
     *       <li>CU_FUNC_ATTRIBUTE_BINARY_VERSION: The binary
     *         architecture version for which the function was compiled. This value
     *         is the major binary version * 10 + the minor binary version, so a
     *         binary version 1.3 function would return the value 13. Note that this
     *         will return a value of 10 for legacy cubins that do not have a
     *         properly-encoded binary architecture version.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuFuncSetCacheConfig
     * @see JCudaDriver#cuLaunchKernel
     */
    public static int cuFuncGetAttribute (int pi[], int attrib, CUfunction func)
    {
        return checkResult(cuFuncGetAttributeNative(pi, attrib, func));
    }
    private static native int cuFuncGetAttributeNative(int pi[], int attrib, CUfunction func);


    /**
     * Sets the block-dimensions for the function.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuFuncSetBlockShape           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>x</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>y</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>z</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Specifies the <code>x</code>, <code>y</code>, and <code>z</code>
     *     dimensions of the thread blocks that are created when the kernel given
     *     by <code>hfunc</code> is launched.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuFuncSetSharedSize
     * @see JCudaDriver#cuFuncSetCacheConfig
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetSize
     * @see JCudaDriver#cuParamSeti
     * @see JCudaDriver#cuParamSetf
     * @see JCudaDriver#cuParamSetv
     * @see JCudaDriver#cuLaunch
     * @see JCudaDriver#cuLaunchGrid
     * @see JCudaDriver#cuLaunchGridAsync
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuFuncSetBlockShape(CUfunction hfunc, int x, int y, int z)
    {
        return checkResult(cuFuncSetBlockShapeNative(hfunc, x, y, z));
    }

    private static native int cuFuncSetBlockShapeNative(CUfunction hfunc, int x, int y, int z);


    /**
     * Sets the dynamic shared-memory size for the function.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuFuncSetSharedSize           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>bytes</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Sets through <code>bytes</code> the amount of dynamic shared memory
     *     that will be available to each thread block when the kernel given by
     *     <code>hfunc</code> is launched.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuFuncSetBlockShape
     * @see JCudaDriver#cuFuncSetCacheConfig
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetSize
     * @see JCudaDriver#cuParamSeti
     * @see JCudaDriver#cuParamSetf
     * @see JCudaDriver#cuParamSetv
     * @see JCudaDriver#cuLaunch
     * @see JCudaDriver#cuLaunchGrid
     * @see JCudaDriver#cuLaunchGridAsync
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuFuncSetSharedSize(CUfunction hfunc, int bytes)
    {
        return checkResult(cuFuncSetSharedSizeNative(hfunc, bytes));
    }

    private static native int cuFuncSetSharedSizeNative(CUfunction hfunc, int bytes);


    /**
     * Sets the preferred cache configuration for a device function.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuFuncSetCacheConfig           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUfunc_cache&nbsp;</td>
     *         <td> <em>config</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       On devices where the L1 cache and shared memory use the same hardware
     *       resources, this sets through <code>config</code> the preferred cache
     *       configuration for the device function <code>hfunc</code>. This is only
     *       a preference. The driver will use the requested configuration if
     *       possible, but it is free to choose a different configuration if required
     *       to execute <code>hfunc</code>. Any context-wide preference set via
     *       cuCtxSetCacheConfig() will be overridden by this per-function setting
     *       unless the per-function setting is CU_FUNC_CACHE_PREFER_NONE. In that
     *       case, the current context-wide setting will be used.
     *     <p>
     *       This setting does nothing on devices where the size of the L1 cache
     *       and shared memory are fixed.
     *     <p>
     *       Launching a kernel with a different preference than the most recent
     *       preference setting may insert a device-side synchronization point.
     *     <p>
     *       The supported cache configurations are:
     *     <ul>
     *       <li>CU_FUNC_CACHE_PREFER_NONE: no preference for shared memory or L1
     *         (default)
     *       </li>
     *       <li>CU_FUNC_CACHE_PREFER_SHARED: prefer larger shared
     *         memory and smaller L1 cache
     *       </li>
     *       <li>CU_FUNC_CACHE_PREFER_L1: prefer
     *         larger L1 cache and smaller shared memory
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT
     *
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuLaunchKernel
     */
    public static int cuFuncSetCacheConfig(CUfunction hfunc, int config)
    {
        return checkResult(cuFuncSetCacheConfigNative(hfunc, config));
    }

    private static native int cuFuncSetCacheConfigNative(CUfunction hfunc, int config);




    /**
     * Creates a 1D or 2D CUDA array.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuArrayCreate           </td>
     *         <td>(</td>
     *         <td>CUarray *&nbsp;</td>
     *         <td> <em>pHandle</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const CUDA_ARRAY_DESCRIPTOR *&nbsp;</td>
     *         <td> <em>pAllocateArray</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates a CUDA array according to the CUDA_ARRAY_DESCRIPTOR structure
     *       <code>pAllocateArray</code> and returns a handle to the new CUDA array
     *       in <code>*pHandle</code>. The CUDA_ARRAY_DESCRIPTOR is defined as:
     *     <p>
     *     <div>
     *       <pre>    <span>typedef</span> <span>struct </span>{
     *         <span>unsigned</span> <span>int</span> Width;
     *         <span>unsigned</span> <span>int</span> Height;
     *         CUarray_format Format;
     *         <span>unsigned</span> <span>int</span> NumChannels;
     *     } CUDA_ARRAY_DESCRIPTOR;
     * </pre>
     *     </div>
     *     where:
     *     <p>
     *     <ul>
     *       <li><code>Width</code>, and <code>Height</code> are the width, and
     *         height of the CUDA array (in elements); the CUDA array is one-dimensional
     *         if height is 0, two-dimensional otherwise;
     *       </li>
     *       <li>
     *         Format specifies
     *         the format of the elements; CUarray_format is defined as:
     *         <div>
     *           <pre>
     *    <span>typedef</span> <span>enum</span> CUarray_format_enum {
     *         CU_AD_FORMAT_UNSIGNED_INT8 = 0x01,
     *         CU_AD_FORMAT_UNSIGNED_INT16 = 0x02,
     *         CU_AD_FORMAT_UNSIGNED_INT32 = 0x03,
     *         CU_AD_FORMAT_SIGNED_INT8 = 0x08,
     *         CU_AD_FORMAT_SIGNED_INT16 = 0x09,
     *         CU_AD_FORMAT_SIGNED_INT32 = 0x0a,
     *         CU_AD_FORMAT_HALF = 0x10,
     *         CU_AD_FORMAT_FLOAT = 0x20
     *     } CUarray_format;
     * </pre>
     *         </div>
     *       </li>
     *       <li><code>NumChannels</code> specifies the number of
     *         packed components per CUDA array element; it may be 1, 2, or
     *         4;
     *       </li>
     *     </ul>
     *     <p>
     *       Here are examples of CUDA array descriptions:
     *     <p>
     *       Description for a CUDA array of 2048 floats:
     *     <div>
     *       <pre>
     * CUDA_ARRAY_DESCRIPTOR desc;
     *     desc.Format = CU_AD_FORMAT_FLOAT;
     *     desc.NumChannels = 1;
     *     desc.Width = 2048;
     *     desc.Height = 1;
     * </pre>
     *     </div>
     *     <p>
     *       Description for a 64 x 64 CUDA array of floats:
     *     <div>
     *       <pre>
     * CUDA_ARRAY_DESCRIPTOR desc;
     *     desc.Format = CU_AD_FORMAT_FLOAT;
     *     desc.NumChannels = 1;
     *     desc.Width = 64;
     *     desc.Height = 64;
     * </pre>
     *     </div>
     *     <p>
     *       Description for a <code>width</code> x <code>height</code> CUDA array
     *       of 64-bit, 4x16-bit float16's:
     *     <div>
     *       <pre>    CUDA_ARRAY_DESCRIPTOR
     * desc;
     *     desc.FormatFlags = CU_AD_FORMAT_HALF;
     *     desc.NumChannels = 4;
     *     desc.Width = width;
     *     desc.Height = height;
     * </pre>
     *     </div>
     *     <p>
     *       Description for a <code>width</code> x <code>height</code> CUDA array
     *       of 16-bit elements, each of which is two 8-bit unsigned chars:
     *     <div>
     *       <pre>    CUDA_ARRAY_DESCRIPTOR arrayDesc;
     *     desc.FormatFlags = CU_AD_FORMAT_UNSIGNED_INT8;
     *     desc.NumChannels = 2;
     *     desc.Width = width;
     *     desc.Height = height;
     * </pre>
     *     </div>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY, CUDA_ERROR_UNKNOWN
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuArrayCreate(CUarray pHandle, CUDA_ARRAY_DESCRIPTOR pAllocateArray)
    {
        return checkResult(cuArrayCreateNative(pHandle, pAllocateArray));
    }

    private static native int cuArrayCreateNative(CUarray pHandle, CUDA_ARRAY_DESCRIPTOR pAllocateArray);


    /**
     * Get a 1D or 2D CUDA array descriptor.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuArrayGetDescriptor           </td>
     *         <td>(</td>
     *         <td>CUDA_ARRAY_DESCRIPTOR *&nbsp;</td>
     *         <td> <em>pArrayDescriptor</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>hArray</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pArrayDescriptor</code> a descriptor containing
     *       information on the format and dimensions of the CUDA array
     *       <code>hArray</code>. It is useful for subroutines that have been passed
     *       a CUDA array, but need to know the CUDA array parameters for validation
     *       or other purposes.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_HANDLE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuArrayGetDescriptor(CUDA_ARRAY_DESCRIPTOR pArrayDescriptor, CUarray hArray)
    {
        return checkResult(cuArrayGetDescriptorNative(pArrayDescriptor, hArray));
    }

    private static native int cuArrayGetDescriptorNative(CUDA_ARRAY_DESCRIPTOR pArrayDescriptor, CUarray hArray);


    /**
     * Destroys a CUDA array.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuArrayDestroy           </td>
     *         <td>(</td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>hArray</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Destroys the CUDA array <code>hArray</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_ARRAY_IS_MAPPED
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuArrayDestroy(CUarray hArray)
    {
        return checkResult(cuArrayDestroyNative(hArray));
    }

    private static native int cuArrayDestroyNative(CUarray hArray);


    /**
     * Creates a 3D CUDA array.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuArray3DCreate           </td>
     *         <td>(</td>
     *         <td>CUarray *&nbsp;</td>
     *         <td> <em>pHandle</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const CUDA_ARRAY3D_DESCRIPTOR *&nbsp;</td>
     *         <td> <em>pAllocateArray</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates a CUDA array according to the CUDA_ARRAY3D_DESCRIPTOR structure
     *       <code>pAllocateArray</code> and returns a handle to the new CUDA array
     *       in <code>*pHandle</code>. The CUDA_ARRAY3D_DESCRIPTOR is defined
     *       as:
     *     <p>
     *     <div>
     *       <pre>    <span>typedef</span> <span>struct </span>{
     *         <span>unsigned</span> <span>int</span> Width;
     *         <span>unsigned</span> <span>int</span> Height;
     *         <span>unsigned</span> <span>int</span> Depth;
     *         CUarray_format Format;
     *         <span>unsigned</span> <span>int</span> NumChannels;
     *         <span>unsigned</span> <span>int</span> Flags;
     *     } CUDA_ARRAY3D_DESCRIPTOR;
     * </pre>
     *     </div>
     *     where:
     *     <p>
     *     <ul>
     *       <li><code>Width</code>, <code>Height</code>, and <code>Depth</code>
     *         are the width, height, and depth of the CUDA array (in elements); the
     *         CUDA array is one-dimensional if height and depth are 0, two-dimensional
     *         if depth is 0, and three-dimensional otherwise; If the CUDA_ARRAY3D_LAYERED
     *         flag is set, then the CUDA array is a collection of layers, where
     *         <code>Depth</code> indicates the number of layers. Each layer is a 1D
     *         array if <code>Height</code> is 0, and a 2D array otherwise.
     *       </li>
     *       <li>
     *         Format
     *         specifies the format of the elements; CUarray_format is defined as:
     *         <div>
     *           <pre>    <span>typedef</span> <span>enum</span>
     * CUarray_format_enum {
     *         CU_AD_FORMAT_UNSIGNED_INT8 = 0x01,
     *         CU_AD_FORMAT_UNSIGNED_INT16 = 0x02,
     *         CU_AD_FORMAT_UNSIGNED_INT32 = 0x03,
     *         CU_AD_FORMAT_SIGNED_INT8 = 0x08,
     *         CU_AD_FORMAT_SIGNED_INT16 = 0x09,
     *         CU_AD_FORMAT_SIGNED_INT32 = 0x0a,
     *         CU_AD_FORMAT_HALF = 0x10,
     *         CU_AD_FORMAT_FLOAT = 0x20
     *     } CUarray_format;
     * </pre>
     *         </div>
     *       </li>
     *       <li><code>NumChannels</code> specifies the number of
     *         packed components per CUDA array element; it may be 1, 2, or
     *         4;
     *       </li>
     *       <li>
     *         Flags may be set to
     *         <ul>
     *           <li>CUDA_ARRAY3D_LAYERED to enable creation of layered CUDA arrays. If
     *             this flag is set, <code>Depth</code> specifies the number of layers,
     *             not the depth of a 3D array.
     *           </li>
     *           <li>CUDA_ARRAY3D_SURFACE_LDST to
     *             enable surface references to be bound to the CUDA array. If this flag
     *             is not set, cuSurfRefSetArray will fail when attempting to bind the
     *             CUDA array to a surface reference.
     *           </li>
     *         </ul>
     *       </li>
     *     </ul>
     *     <p>
     *       Here are examples of CUDA array descriptions:
     *     <p>
     *       Description for a CUDA array of 2048 floats:
     *     <div>
     *       <pre>
     * CUDA_ARRAY3D_DESCRIPTOR desc;
     *     desc.Format = CU_AD_FORMAT_FLOAT;
     *     desc.NumChannels = 1;
     *     desc.Width = 2048;
     *     desc.Height = 0;
     *     desc.Depth = 0;
     * </pre>
     *     </div>
     *     <p>
     *       Description for a 64 x 64 CUDA array of floats:
     *     <div>
     *       <pre>
     * CUDA_ARRAY3D_DESCRIPTOR desc;
     *     desc.Format = CU_AD_FORMAT_FLOAT;
     *     desc.NumChannels = 1;
     *     desc.Width = 64;
     *     desc.Height = 64;
     *     desc.Depth = 0;
     * </pre>
     *     </div>
     *     <p>
     *       Description for a <code>width</code> x <code>height</code> x
     *       <code>depth</code> CUDA array of 64-bit, 4x16-bit float16's:
     *     <div>
     *       <pre>    CUDA_ARRAY3D_DESCRIPTOR desc;
     *     desc.FormatFlags = CU_AD_FORMAT_HALF;
     *     desc.NumChannels = 4;
     *     desc.Width = width;
     *     desc.Height = height;
     *     desc.Depth = depth;
     * </pre>
     *     </div>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY, CUDA_ERROR_UNKNOWN
     *
     * @see JCudaDriver#cuArray3DGetDescriptor
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuArray3DCreate(CUarray pHandle, CUDA_ARRAY3D_DESCRIPTOR pAllocateArray)
    {
        return checkResult(cuArray3DCreateNative(pHandle, pAllocateArray));
    }

    private static native int cuArray3DCreateNative(CUarray pHandle, CUDA_ARRAY3D_DESCRIPTOR pAllocateArray);


    /**
     * Get a 3D CUDA array descriptor.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuArray3DGetDescriptor           </td>
     *         <td>(</td>
     *         <td>CUDA_ARRAY3D_DESCRIPTOR *&nbsp;</td>
     *         <td> <em>pArrayDescriptor</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>hArray</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pArrayDescriptor</code> a descriptor containing
     *       information on the format and dimensions of the CUDA array
     *       <code>hArray</code>. It is useful for subroutines that have been passed
     *       a CUDA array, but need to know the CUDA array parameters for validation
     *       or other purposes.
     *     <p>
     *       This function may be called on 1D and 2D arrays, in which case the
     *       <code>Height</code> and/or <code>Depth</code> members of the descriptor
     *       struct will be set to 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_HANDLE
     *
     * @see JCudaDriver#cuArray3DCreate
     * @see JCudaDriver#cuArrayCreate
     * @see JCudaDriver#cuArrayDestroy
     * @see JCudaDriver#cuArrayGetDescriptor
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemAllocPitch
     * @see JCudaDriver#cuMemcpy2D
     * @see JCudaDriver#cuMemcpy2DAsync
     * @see JCudaDriver#cuMemcpy2DUnaligned
     * @see JCudaDriver#cuMemcpy3D
     * @see JCudaDriver#cuMemcpy3DAsync
     * @see JCudaDriver#cuMemcpyAtoA
     * @see JCudaDriver#cuMemcpyAtoD
     * @see JCudaDriver#cuMemcpyAtoH
     * @see JCudaDriver#cuMemcpyAtoHAsync
     * @see JCudaDriver#cuMemcpyDtoA
     * @see JCudaDriver#cuMemcpyDtoD
     * @see JCudaDriver#cuMemcpyDtoDAsync
     * @see JCudaDriver#cuMemcpyDtoH
     * @see JCudaDriver#cuMemcpyDtoHAsync
     * @see JCudaDriver#cuMemcpyHtoA
     * @see JCudaDriver#cuMemcpyHtoAAsync
     * @see JCudaDriver#cuMemcpyHtoD
     * @see JCudaDriver#cuMemcpyHtoDAsync
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemGetAddressRange
     * @see JCudaDriver#cuMemGetInfo
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostGetDevicePointer
     * @see JCudaDriver#cuMemsetD2D8
     * @see JCudaDriver#cuMemsetD2D16
     * @see JCudaDriver#cuMemsetD2D32
     * @see JCudaDriver#cuMemsetD8
     * @see JCudaDriver#cuMemsetD16
     * @see JCudaDriver#cuMemsetD32
     */
    public static int cuArray3DGetDescriptor(CUDA_ARRAY3D_DESCRIPTOR pArrayDescriptor, CUarray hArray)
    {
        return checkResult(cuArray3DGetDescriptorNative(pArrayDescriptor, hArray));
    }

    private static native int cuArray3DGetDescriptorNative(CUDA_ARRAY3D_DESCRIPTOR pArrayDescriptor, CUarray hArray);


    /**
     * Creates a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefCreate           </td>
     *         <td>(</td>
     *         <td>CUtexref *&nbsp;</td>
     *         <td> <em>pTexRef</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Creates a texture reference and returns its handle in
     *     <code>*pTexRef</code>. Once created, the application must call
     *     cuTexRefSetArray() or cuTexRefSetAddress() to associate the reference
     *     with allocated memory. Other texture reference functions are used to
     *     specify the format and interpretation (addressing, filtering, etc.) to
     *     be used when the memory is read through this texture reference.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefDestroy
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuTexRefCreate(CUtexref pTexRef)
    {
        return checkResult(cuTexRefCreateNative(pTexRef));
    }

    private static native int cuTexRefCreateNative(CUtexref pTexRef);


    /**
     * Destroys a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefDestroy           </td>
     *         <td>(</td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Destroys the texture reference specified by <code>hTexRef</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefCreate
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuTexRefDestroy(CUtexref hTexRef)
    {
        return checkResult(cuTexRefDestroyNative(hTexRef));
    }

    private static native int cuTexRefDestroyNative(CUtexref hTexRef);


    /**
     * Binds an array as a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefSetArray           </td>
     *         <td>(</td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>hArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Binds the CUDA array <code>hArray</code> to the texture reference
     *       <code>hTexRef</code>. Any previous address or CUDA array state
     *       associated with the texture reference is superseded by this function.
     *       <code>Flags</code> must be set to CU_TRSA_OVERRIDE_FORMAT. Any CUDA
     *       array previously bound to <code>hTexRef</code> is unbound.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefSetArray(CUtexref hTexRef, CUarray hArray, int Flags)
    {
        return checkResult(cuTexRefSetArrayNative(hTexRef, hArray, Flags));
    }

    private static native int cuTexRefSetArrayNative(CUtexref hTexRef, CUarray hArray, int Flags);


    /**
     * Binds an address as a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefSetAddress           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>ByteOffset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>bytes</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Binds a linear address range to the texture reference <code>hTexRef</code>.
     *       Any previous address or CUDA array state associated with the texture
     *       reference is superseded by this function. Any memory previously bound
     *       to <code>hTexRef</code> is unbound.
     *     <p>
     *       Since the hardware enforces an alignment requirement on texture base
     *       addresses, cuTexRefSetAddress() passes back a byte offset in
     *       <code>*ByteOffset</code> that must be applied to texture fetches in
     *       order to read from the desired memory. This offset must be divided by
     *       the texel size and passed to kernels that read from the texture so they
     *       can be applied to the tex1Dfetch() function.
     *     <p>
     *       If the device memory pointer was returned from cuMemAlloc(), the offset
     *       is guaranteed to be 0 and NULL may be passed as the <code>ByteOffset</code>
     *       parameter.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefSetAddress(long ByteOffset[], CUtexref hTexRef, CUdeviceptr dptr, long bytes)
    {
        return checkResult(cuTexRefSetAddressNative(ByteOffset, hTexRef, dptr, bytes));
    }

    private static native int cuTexRefSetAddressNative(long ByteOffset[], CUtexref hTexRef, CUdeviceptr dptr, long bytes);


    /**
     * Sets the format for a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefSetFormat           </td>
     *         <td>(</td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray_format&nbsp;</td>
     *         <td> <em>fmt</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>NumPackedComponents</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Specifies the format of the data to be read by the texture reference
     *       <code>hTexRef</code>. <code>fmt</code> and <code>NumPackedComponents</code>
     *       are exactly analogous to the Format and NumChannels members of the
     *       CUDA_ARRAY_DESCRIPTOR structure: They specify the format of each
     *       component and the number of components per array element.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefSetFormat(CUtexref hTexRef, int fmt, int NumPackedComponents)
    {
        return checkResult(cuTexRefSetFormatNative(hTexRef, fmt, NumPackedComponents));
    }

    private static native int cuTexRefSetFormatNative(CUtexref hTexRef, int fmt, int NumPackedComponents);



    /**
     * Binds an address as a 2D texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefSetAddress2D           </td>
     *         <td>(</td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>const CUDA_ARRAY_DESCRIPTOR *&nbsp;</td>
     *         <td> <em>desc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>dptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>Pitch</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Binds a linear address range to the texture reference <code>hTexRef</code>.
     *       Any previous address or CUDA array state associated with the texture
     *       reference is superseded by this function. Any memory previously bound
     *       to <code>hTexRef</code> is unbound.
     *     <p>
     *       Using a tex2D() function inside a kernel requires a call to either
     *       cuTexRefSetArray() to bind the corresponding texture reference to an
     *       array, or cuTexRefSetAddress2D() to bind the texture reference to
     *       linear memory.
     *     <p>
     *       Function calls to cuTexRefSetFormat() cannot follow calls to
     *       cuTexRefSetAddress2D() for the same texture reference.
     *     <p>
     *       It is required that <code>dptr</code> be aligned to the appropriate
     *       hardware-specific texture alignment. You can query this value using
     *       the device attribute CU_DEVICE_ATTRIBUTE_TEXTURE_ALIGNMENT. If an
     *       unaligned <code>dptr</code> is supplied, CUDA_ERROR_INVALID_VALUE is
     *       returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefSetAddress2D(CUtexref hTexRef, CUDA_ARRAY_DESCRIPTOR desc, CUdeviceptr dptr, long PitchInBytes)
    {
        return checkResult(cuTexRefSetAddress2DNative(hTexRef, desc, dptr, PitchInBytes));
    }
    private static native int cuTexRefSetAddress2DNative(CUtexref hTexRef, CUDA_ARRAY_DESCRIPTOR desc, CUdeviceptr dptr, long PitchInBytes);



    /**
     * Sets the addressing mode for a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefSetAddressMode           </td>
     *         <td>(</td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>dim</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUaddress_mode&nbsp;</td>
     *         <td> <em>am</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Specifies the addressing mode <code>am</code> for the given dimension
     *       <code>dim</code> of the texture reference <code>hTexRef</code>. If
     *       <code>dim</code> is zero, the addressing mode is applied to the first
     *       parameter of the functions used to fetch from the texture; if
     *       <code>dim</code> is 1, the second, and so on. CUaddress_mode is defined
     *       as:
     *     <div>
     *       <pre>   <span>typedef</span> <span>enum</span>
     * CUaddress_mode_enum {
     *       CU_TR_ADDRESS_MODE_WRAP = 0,
     *       CU_TR_ADDRESS_MODE_CLAMP = 1,
     *       CU_TR_ADDRESS_MODE_MIRROR = 2,
     *       CU_TR_ADDRESS_MODE_BORDER = 3
     *    } CUaddress_mode;
     * </pre>
     *     </div>
     *     <p>
     *       Note that this call has no effect if <code>hTexRef</code> is bound to
     *       linear memory. Also, if the flag, CU_TRSF_NORMALIZED_COORDINATES, is
     *       not set, the only supported address mode is
     *       CU_TR_ADDRESS_MODE_CLAMP.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefSetAddressMode(CUtexref hTexRef, int dim, int am)
    {
        return checkResult(cuTexRefSetAddressModeNative(hTexRef, dim, am));
    }

    private static native int cuTexRefSetAddressModeNative(CUtexref hTexRef, int dim, int am);


    /**
     * Sets the filtering mode for a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefSetFilterMode           </td>
     *         <td>(</td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUfilter_mode&nbsp;</td>
     *         <td> <em>fm</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Specifies the filtering mode <code>fm</code> to be used when reading
     *       memory through the texture reference <code>hTexRef</code>.
     *       CUfilter_mode_enum is defined as:
     *     <p>
     *     <div>
     *       <pre>   <span>typedef</span> <span>enum</span> CUfilter_mode_enum
     * {
     *       CU_TR_FILTER_MODE_POINT = 0,
     *       CU_TR_FILTER_MODE_LINEAR = 1
     *    } CUfilter_mode;
     * </pre>
     *     </div>
     *     <p>
     *       Note that this call has no effect if <code>hTexRef</code> is bound to
     *       linear memory.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefSetFilterMode(CUtexref hTexRef, int fm)
    {
        return checkResult(cuTexRefSetFilterModeNative(hTexRef, fm));
    }

    private static native int cuTexRefSetFilterModeNative(CUtexref hTexRef, int fm);


    /**
     * Sets the flags for a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefSetFlags           </td>
     *         <td>(</td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Specifies optional flags via <code>Flags</code> to specify the behavior
     *       of data returned through the texture reference <code>hTexRef</code>.
     *       The valid flags are:
     *     <p>
     *     <ul>
     *       <li>CU_TRSF_READ_AS_INTEGER, which suppresses the default behavior of
     *         having the texture promote integer data to floating point data in the
     *         range [0, 1];
     *       </li>
     *       <li>CU_TRSF_NORMALIZED_COORDINATES, which suppresses
     *         the default behavior of having the texture coordinates range from [0,
     *         Dim) where Dim is the width or height of the CUDA array. Instead, the
     *         texture coordinates [0, 1.0) reference the entire breadth of the array
     *         dimension;
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefSetFlags(CUtexref hTexRef, int Flags)
    {
        return checkResult(cuTexRefSetFlagsNative(hTexRef, Flags));
    }

    private static native int cuTexRefSetFlagsNative(CUtexref hTexRef, int Flags);


    /**
     * Gets the address associated with a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefGetAddress           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>pdptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pdptr</code> the base address bound to the texture
     *       reference <code>hTexRef</code>, or returns CUDA_ERROR_INVALID_VALUE if
     *       the texture reference is not bound to any device memory range.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefGetAddress(CUdeviceptr pdptr, CUtexref hTexRef)
    {
        return checkResult(cuTexRefGetAddressNative(pdptr, hTexRef));
    }

    private static native int cuTexRefGetAddressNative(CUdeviceptr pdptr, CUtexref hTexRef);


    /**
     * Gets the array bound to a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefGetArray           </td>
     *         <td>(</td>
     *         <td>CUarray *&nbsp;</td>
     *         <td> <em>phArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*phArray</code> the CUDA array bound to the texture
     *       reference <code>hTexRef</code>, or returns CUDA_ERROR_INVALID_VALUE if
     *       the texture reference is not bound to any CUDA array.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefGetArray(CUarray phArray, CUtexref hTexRef)
    {
        return checkResult(cuTexRefGetArrayNative(phArray, hTexRef));
    }

    private static native int cuTexRefGetArrayNative(CUarray phArray, CUtexref hTexRef);


    /**
     * Gets the addressing mode used by a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefGetAddressMode           </td>
     *         <td>(</td>
     *         <td>CUaddress_mode *&nbsp;</td>
     *         <td> <em>pam</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>dim</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pam</code> the addressing mode corresponding to the
     *       dimension <code>dim</code> of the texture reference <code>hTexRef</code>.
     *       Currently, the only valid value for <code>dim</code> are 0 and 1.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefGetAddressMode(int pam[], CUtexref hTexRef, int dim)
    {
        return checkResult(cuTexRefGetAddressModeNative(pam, hTexRef, dim));
    }

    private static native int cuTexRefGetAddressModeNative(int pam[], CUtexref hTexRef, int dim);


    /**
     * Gets the filter-mode used by a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefGetFilterMode           </td>
     *         <td>(</td>
     *         <td>CUfilter_mode *&nbsp;</td>
     *         <td> <em>pfm</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pfm</code> the filtering mode of the texture reference
     *       <code>hTexRef</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFlags
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefGetFilterMode(int pfm[], CUtexref hTexRef)
    {
        return checkResult(cuTexRefGetFilterModeNative(pfm, hTexRef));
    }

    private static native int cuTexRefGetFilterModeNative(int pfm[], CUtexref hTexRef);


    /**
     * Gets the format used by a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefGetFormat           </td>
     *         <td>(</td>
     *         <td>CUarray_format *&nbsp;</td>
     *         <td> <em>pFormat</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>pNumChannels</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pFormat</code> and <code>*pNumChannels</code> the
     *       format and number of components of the CUDA array bound to the texture
     *       reference <code>hTexRef</code>. If <code>pFormat</code> or
     *       <code>pNumChannels</code> is NULL, it will be ignored.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFlags
     */
    public static int cuTexRefGetFormat(int pFormat[], int pNumChannels[], CUtexref hTexRef)
    {
        return checkResult(cuTexRefGetFormatNative(pFormat, pNumChannels, hTexRef));
    }

    private static native int cuTexRefGetFormatNative(int pFormat[], int pNumChannels[], CUtexref hTexRef);


    /**
     * Gets the flags used by a texture reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuTexRefGetFlags           </td>
     *         <td>(</td>
     *         <td>unsigned int *&nbsp;</td>
     *         <td> <em>pFlags</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pFlags</code> the flags of the texture reference
     *       <code>hTexRef</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuTexRefSetAddress
     * @see JCudaDriver#cuTexRefSetAddress2D
     * @see JCudaDriver#cuTexRefSetAddressMode
     * @see JCudaDriver#cuTexRefSetArray
     * @see JCudaDriver#cuTexRefSetFilterMode
     * @see JCudaDriver#cuTexRefSetFlags
     * @see JCudaDriver#cuTexRefSetFormat
     * @see JCudaDriver#cuTexRefGetAddress
     * @see JCudaDriver#cuTexRefGetAddressMode
     * @see JCudaDriver#cuTexRefGetArray
     * @see JCudaDriver#cuTexRefGetFilterMode
     * @see JCudaDriver#cuTexRefGetFormat
     */
    public static int cuTexRefGetFlags(int pFlags[], CUtexref hTexRef)
    {
        return checkResult(cuTexRefGetFlagsNative(pFlags, hTexRef));
    }

    private static native int cuTexRefGetFlagsNative(int pFlags[], CUtexref hTexRef);


    /**
     * Sets the CUDA array for a surface reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuSurfRefSetArray           </td>
     *         <td>(</td>
     *         <td>CUsurfref&nbsp;</td>
     *         <td> <em>hSurfRef</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUarray&nbsp;</td>
     *         <td> <em>hArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Sets the CUDA array <code>hArray</code> to be read and written by the
     *       surface reference <code>hSurfRef</code>. Any previous CUDA array state
     *       associated with the surface reference is superseded by this function.
     *       <code>Flags</code> must be set to 0. The CUDA_ARRAY3D_SURFACE_LDST flag
     *       must have been set for the CUDA array. Any CUDA array previously bound
     *       to <code>hSurfRef</code> is unbound.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuModuleGetSurfRef
     * @see JCudaDriver#cuSurfRefGetArray
     */
    public static int cuSurfRefSetArray(CUsurfref hSurfRef, CUarray hArray, int Flags )
    {
        return checkResult(cuSurfRefSetArrayNative(hSurfRef, hArray, Flags));
    }
    private static native int cuSurfRefSetArrayNative(CUsurfref hSurfRef, CUarray hArray, int Flags );

    /**
     * Passes back the CUDA array bound to a surface reference.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuSurfRefGetArray           </td>
     *         <td>(</td>
     *         <td>CUarray *&nbsp;</td>
     *         <td> <em>phArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUsurfref&nbsp;</td>
     *         <td> <em>hSurfRef</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*phArray</code> the CUDA array bound to the surface
     *       reference <code>hSurfRef</code>, or returns CUDA_ERROR_INVALID_VALUE
     *       if the surface reference is not bound to any CUDA array.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuModuleGetSurfRef
     * @see JCudaDriver#cuSurfRefSetArray
     */
    public static int cuSurfRefGetArray( CUarray phArray, CUsurfref hSurfRef )
    {
        return checkResult(cuSurfRefGetArrayNative(phArray, hSurfRef));
    }
    private static native int cuSurfRefGetArrayNative( CUarray phArray, CUsurfref hSurfRef );



    /**
     * Queries if a device may directly access a peer device's memory.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuDeviceCanAccessPeer           </td>
     *         <td>(</td>
     *         <td>int *&nbsp;</td>
     *         <td> <em>canAccessPeer</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>dev</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>peerDev</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*canAccessPeer</code> a value of 1 if contexts on
     *       <code>dev</code> are capable of directly accessing memory from contexts
     *       on <code>peerDev</code> and 0 otherwise. If direct access of
     *       <code>peerDev</code> from <code>dev</code> is possible, then access
     *       may be enabled on two specific contexts by calling
     *       cuCtxEnablePeerAccess().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_DEVICE
     *
     * @see JCudaDriver#cuCtxEnablePeerAccess
     * @see JCudaDriver#cuCtxDisablePeerAccess
     */
    public static int cuDeviceCanAccessPeer(int canAccessPeer[], CUdevice dev, CUdevice peerDev)
    {
        return checkResult(cuDeviceCanAccessPeerNative(canAccessPeer, dev, peerDev));
    }
    private static native int cuDeviceCanAccessPeerNative(int canAccessPeer[], CUdevice dev, CUdevice peerDev);


    /**
     * Enables direct access to memory allocations in a peer context.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxEnablePeerAccess           </td>
     *         <td>(</td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>peerContext</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       If both the current context and <code>peerContext</code> are on devices
     *       which support unified addressing (as may be queried using
     *       CU_DEVICE_ATTRIBUTE_UNIFIED_ADDRESSING), then on success all allocations
     *       from <code>peerContext</code> will immediately be accessible by the
     *       current context. See Unified Addressing for additional details.
     *     <p>
     *       Note that access granted by this call is unidirectional and that in
     *       order to access memory from the current context in <code>peerContext</code>,
     *       a separate symmetric call to cuCtxEnablePeerAccess() is required.
     *     <p>
     *       Returns CUDA_ERROR_INVALID_DEVICE if cuDeviceCanAccessPeer() indicates
     *       that the CUdevice of the current context cannot directly access memory
     *       from the CUdevice of <code>peerContext</code>.
     *     <p>
     *       Returns CUDA_ERROR_PEER_ACCESS_ALREADY_ENABLED if direct access of
     *       <code>peerContext</code> from the current context has already been
     *       enabled.
     *     <p>
     *       Returns CUDA_ERROR_INVALID_CONTEXT if there is no current context,
     *       <code>peerContext</code> is not a valid context, or if the current
     *       context is <code>peerContext</code>.
     *     <p>
     *       Returns CUDA_ERROR_INVALID_VALUE if <code>Flags</code> is not 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_DEVICE, CUDA_ERROR_PEER_ACCESS_ALREADY_ENABLED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuDeviceCanAccessPeer
     * @see JCudaDriver#cuCtxDisablePeerAccess
     */
    public static int cuCtxEnablePeerAccess(CUcontext peerContext, int Flags)
    {
        return checkResult(cuCtxEnablePeerAccessNative(peerContext, Flags));
    }
    private static native int cuCtxEnablePeerAccessNative(CUcontext peerContext, int Flags);


    /**
     * Disables direct access to memory allocations in a peer context and
     * unregisters any registered allocations.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxDisablePeerAccess           </td>
     *         <td>(</td>
     *         <td>CUcontext&nbsp;</td>
     *         <td> <em>peerContext</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns CUDA_ERROR_PEER_ACCESS_NOT_ENABLED if direct peer access has
     *       not yet been enabled from <code>peerContext</code> to the current
     *       context.
     *     <p>
     *       Returns CUDA_ERROR_INVALID_CONTEXT if there is no current context, or
     *       if <code>peerContext</code> is not a valid context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_PEER_ACCESS_NOT_ENABLED, CUDA_ERROR_INVALID_CONTEXT,
     *
     * @see JCudaDriver#cuDeviceCanAccessPeer
     * @see JCudaDriver#cuCtxEnablePeerAccess
     */
    public static int cuCtxDisablePeerAccess(CUcontext peerContext)
    {
        return checkResult(cuCtxDisablePeerAccessNative(peerContext));
    }
    private static native int cuCtxDisablePeerAccessNative(CUcontext peerContext);


    /**
     * @deprecated This function has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2. In the current release,
     * it will throw an UnsupportedOperationException. 
     */
    public static int cuMemPeerRegister(CUdeviceptr peerPointer, CUcontext peerContext, int Flags)
    {
        if (true)
        {
            // TODO: If this function is not available in CUDA 4.0 /final/,
            // then remove the native binding
            throw new UnsupportedOperationException(
                "This function is not available in CUDA 4.0 RC2");
        }
        return checkResult(cuMemPeerRegisterNative(peerPointer, peerContext, Flags));
    }
    private static native int cuMemPeerRegisterNative(CUdeviceptr peerPointer, CUcontext peerContext, int Flags);


    /**
     * @deprecated This function has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2. In the current release,
     * it will throw an UnsupportedOperationException. 
     */
    public static int cuMemPeerUnregister(CUdeviceptr peerPointer, CUcontext peerContext)
    {
        if (true)
        {
            // TODO: If this function is not available in CUDA 4.0 /final/,
            // then remove the native binding
            throw new UnsupportedOperationException(
                "This function is not available in CUDA 4.0 RC2");
        }
        return checkResult(cuMemPeerUnregisterNative(peerPointer, peerContext));
    }
    private static native int cuMemPeerUnregisterNative(CUdeviceptr peerPointer, CUcontext peerContext);


    /**
     * @deprecated This function has been added in CUDA 4.0 RC,
     * and removed in CUDA 4.0 RC2. In the current release,
     * it will throw an UnsupportedOperationException. 
     */
    public static int cuMemPeerGetDevicePointer(CUdeviceptr pdptr, CUdeviceptr peerPointer, CUcontext peerContext, int Flags)
    {
        if (true)
        {
            // TODO: If this function is not available in CUDA 4.0 /final/,
            // then remove the native binding
            throw new UnsupportedOperationException(
                "This function is not available in CUDA 4.0 RC2");
        }
        return checkResult(cuMemPeerGetDevicePointerNative(pdptr, peerPointer, peerContext, Flags));
    }
    private static native int cuMemPeerGetDevicePointerNative(CUdeviceptr pdptr, CUdeviceptr peerPointer, CUcontext peerContext, int Flags);


    /**
     * Sets the parameter size for the function.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuParamSetSize           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>numbytes</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Sets through <code>numbytes</code> the total size in bytes needed by
     *     the function parameters of the kernel corresponding to
     *     <code>hfunc</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuFuncSetBlockShape
     * @see JCudaDriver#cuFuncSetSharedSize
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetf
     * @see JCudaDriver#cuParamSeti
     * @see JCudaDriver#cuParamSetv
     * @see JCudaDriver#cuLaunch
     * @see JCudaDriver#cuLaunchGrid
     * @see JCudaDriver#cuLaunchGridAsync
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuParamSetSize(CUfunction hfunc, int numbytes)
    {
        return checkResult(cuParamSetSizeNative(hfunc, numbytes));
    }

    private static native int cuParamSetSizeNative(CUfunction hfunc, int numbytes);


    /**
     * Adds an integer parameter to the function's argument list.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuParamSeti           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>offset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>value</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Sets an integer parameter that will be specified the next time the
     *     kernel corresponding to <code>hfunc</code> will be invoked.
     *     <code>offset</code> is a byte offset.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuFuncSetBlockShape
     * @see JCudaDriver#cuFuncSetSharedSize
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetSize
     * @see JCudaDriver#cuParamSetf
     * @see JCudaDriver#cuParamSetv
     * @see JCudaDriver#cuLaunch
     * @see JCudaDriver#cuLaunchGrid
     * @see JCudaDriver#cuLaunchGridAsync
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuParamSeti(CUfunction hfunc, int offset, int value)
    {
        return checkResult(cuParamSetiNative(hfunc, offset, value));
    }

    private static native int cuParamSetiNative(CUfunction hfunc, int offset, int value);


    /**
     * Adds a floating-point parameter to the function's argument list.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuParamSetf           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>offset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>float&nbsp;</td>
     *         <td> <em>value</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Sets a floating-point parameter that will be specified the next time
     *     the kernel corresponding to <code>hfunc</code> will be invoked.
     *     <code>offset</code> is a byte offset.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuFuncSetBlockShape
     * @see JCudaDriver#cuFuncSetSharedSize
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetSize
     * @see JCudaDriver#cuParamSeti
     * @see JCudaDriver#cuParamSetv
     * @see JCudaDriver#cuLaunch
     * @see JCudaDriver#cuLaunchGrid
     * @see JCudaDriver#cuLaunchGridAsync
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuParamSetf(CUfunction hfunc, int offset, float value)
    {
        return checkResult(cuParamSetfNative(hfunc, offset, value));
    }
    private static native int cuParamSetfNative(CUfunction hfunc, int offset, float value);


    /**
     * Adds arbitrary data to the function's argument list.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuParamSetv           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>offset</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>ptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>numbytes</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Copies an arbitrary amount of data (specified in <code>numbytes</code>)
     *     from <code>ptr</code> into the parameter space of the kernel
     *     corresponding to <code>hfunc</code>. <code>offset</code> is a byte
     *     offset.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuFuncSetBlockShape
     * @see JCudaDriver#cuFuncSetSharedSize
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetSize
     * @see JCudaDriver#cuParamSetf
     * @see JCudaDriver#cuParamSeti
     * @see JCudaDriver#cuLaunch
     * @see JCudaDriver#cuLaunchGrid
     * @see JCudaDriver#cuLaunchGridAsync
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuParamSetv(CUfunction hfunc, int offset, Pointer ptr, int numbytes)
    {
        return checkResult(cuParamSetvNative(hfunc, offset, ptr, numbytes));
    }

    private static native int cuParamSetvNative(CUfunction hfunc, int offset, Pointer ptr, int numbytes);


    /**
     * Adds a texture-reference to the function's argument list.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuParamSetTexRef           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>hfunc</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>texunit</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUtexref&nbsp;</td>
     *         <td> <em>hTexRef</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Makes the CUDA array or linear memory bound to the texture reference
     *     <code>hTexRef</code> available to a device program as a texture. In
     *     this version of CUDA, the texture-reference must be obtained via
     *     cuModuleGetTexRef() and the <code>texunit</code> parameter must be set
     *     to CU_PARAM_TR_DEFAULT.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuParamSetTexRef(CUfunction hfunc, int texunit, CUtexref hTexRef)
    {
        return checkResult(cuParamSetTexRefNative(hfunc, texunit, hTexRef));
    }

    private static native int cuParamSetTexRefNative(CUfunction hfunc, int texunit, CUtexref hTexRef);


    /**
     * Launches a CUDA function.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuLaunch           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>f</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Invokes the kernel <code>f</code> on a 1 x 1 x 1 grid of blocks. The
     *     block contains the number of threads specified by a previous call to
     *     cuFuncSetBlockShape().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_LAUNCH_FAILED, CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES,
     * CUDA_ERROR_LAUNCH_TIMEOUT, CUDA_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING,
     * CUDA_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     * @see JCudaDriver#cuFuncSetBlockShape
     * @see JCudaDriver#cuFuncSetSharedSize
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetSize
     * @see JCudaDriver#cuParamSetf
     * @see JCudaDriver#cuParamSeti
     * @see JCudaDriver#cuParamSetv
     * @see JCudaDriver#cuLaunchGrid
     * @see JCudaDriver#cuLaunchGridAsync
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuLaunch(CUfunction f)
    {
        return checkResult(cuLaunchNative(f));
    }

    private static native int cuLaunchNative(CUfunction f);


    /**
     * Launches a CUDA function.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuLaunchGrid           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>f</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>grid_width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>grid_height</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Invokes the kernel <code>f</code> on a <code>grid_width</code> x
     *     <code>grid_height</code> grid of blocks. Each block contains the number
     *     of threads specified by a previous call to cuFuncSetBlockShape().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_LAUNCH_FAILED, CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES,
     * CUDA_ERROR_LAUNCH_TIMEOUT, CUDA_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING,
     * CUDA_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     * @see JCudaDriver#cuFuncSetBlockShape
     * @see JCudaDriver#cuFuncSetSharedSize
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetSize
     * @see JCudaDriver#cuParamSetf
     * @see JCudaDriver#cuParamSeti
     * @see JCudaDriver#cuParamSetv
     * @see JCudaDriver#cuLaunch
     * @see JCudaDriver#cuLaunchGridAsync
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuLaunchGrid(CUfunction f, int grid_width, int grid_height)
    {
        return checkResult(cuLaunchGridNative(f, grid_width, grid_height));
    }

    private static native int cuLaunchGridNative(CUfunction f, int grid_width, int grid_height);


    /**
     * Launches a CUDA function.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuLaunchGridAsync           </td>
     *         <td>(</td>
     *         <td>CUfunction&nbsp;</td>
     *         <td> <em>f</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>grid_width</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>int&nbsp;</td>
     *         <td> <em>grid_height</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd></dd>
     *     </dl>
     *     Invokes the kernel <code>f</code> on a <code>grid_width</code> x
     *     <code>grid_height</code> grid of blocks. Each block contains the number
     *     of threads specified by a previous call to cuFuncSetBlockShape().
     *     <p>
     *       cuLaunchGridAsync() can optionally be associated to a stream by passing
     *       a non-zero <code>hStream</code> argument.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_LAUNCH_FAILED,
     * CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES, CUDA_ERROR_LAUNCH_TIMEOUT,
     * CUDA_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING, CUDA_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     *
     * @see JCudaDriver#cuFuncSetBlockShape
     * @see JCudaDriver#cuFuncSetSharedSize
     * @see JCudaDriver#cuFuncGetAttribute
     * @see JCudaDriver#cuParamSetSize
     * @see JCudaDriver#cuParamSetf
     * @see JCudaDriver#cuParamSeti
     * @see JCudaDriver#cuParamSetv
     * @see JCudaDriver#cuLaunch
     * @see JCudaDriver#cuLaunchGrid
     * @see JCudaDriver#cuLaunchKernel
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuLaunchGridAsync(CUfunction f, int grid_width, int grid_height, CUstream hStream)
    {
        return checkResult(cuLaunchGridAsyncNative(f, grid_width, grid_height, hStream));
    }

    private static native int cuLaunchGridAsyncNative(CUfunction f, int grid_width, int grid_height, CUstream hStream);


    /**
     * Creates an event.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuEventCreate           </td>
     *         <td>(</td>
     *         <td>CUevent *&nbsp;</td>
     *         <td> <em>phEvent</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates an event *phEvent with the flags specified via <code>Flags</code>.
     *       Valid flags include:
     *     <ul>
     *       <li>CU_EVENT_DEFAULT: Default event creation
     *         flag.
     *       </li>
     *       <li>CU_EVENT_BLOCKING_SYNC: Specifies that the created event
     *         should use blocking synchronization. A CPU thread that uses
     *         cuEventSynchronize() to wait on an event created with this flag will
     *         block until the event has actually been
     *         recorded.
     *       </li>
     *       <li>CU_EVENT_DISABLE_TIMING: Specifies that the created
     *         event does not need to record timing data. Events created with this
     *         flag specified and the CU_EVENT_BLOCKING_SYNC flag not specified will
     *         provide the best performance when used with cuStreamWaitEvent() and
     *         cuEventQuery().
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuEventRecord
     * @see JCudaDriver#cuEventQuery
     * @see JCudaDriver#cuEventSynchronize
     * @see JCudaDriver#cuEventDestroy
     * @see JCudaDriver#cuEventElapsedTime
     */
    public static int cuEventCreate(CUevent phEvent, int Flags)
    {
        return checkResult(cuEventCreateNative(phEvent, Flags));
    }

    private static native int cuEventCreateNative(CUevent phEvent, int Flags);


    /**
     * Records an event.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuEventRecord           </td>
     *         <td>(</td>
     *         <td>CUevent&nbsp;</td>
     *         <td> <em>hEvent</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Records an event. If <code>hStream</code> is non-zero, the event is
     *       recorded after all preceding operations in <code>hStream</code> have
     *       been completed; otherwise, it is recorded after all preceding operations
     *       in the CUDA context have been completed. Since operation is asynchronous,
     *       cuEventQuery and/or cuEventSynchronize() must be used to determine when
     *       the event has actually been recorded.
     *     <p>
     *       If cuEventRecord() has previously been called on <code>hEvent</code>,
     *       then this call will overwrite any existing state in <code>hEvent</code>.
     *       Any subsequent calls which examine the status of <code>hEvent</code>
     *       will only examine the completion of this most recent call to
     *       cuEventRecord().
     *     <p>
     *       It is necessary that <code>hEvent</code> and <code>hStream</code> be
     *       created on the same context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuEventCreate
     * @see JCudaDriver#cuEventQuery
     * @see JCudaDriver#cuEventSynchronize
     * @see JCudaDriver#cuStreamWaitEvent
     * @see JCudaDriver#cuEventDestroy
     * @see JCudaDriver#cuEventElapsedTime
     */
    public static int cuEventRecord(CUevent hEvent, CUstream hStream)
    {
        return checkResult(cuEventRecordNative(hEvent, hStream));
    }

    private static native int cuEventRecordNative(CUevent hEvent, CUstream hStream);


    /**
     * Queries an event's status.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuEventQuery           </td>
     *         <td>(</td>
     *         <td>CUevent&nbsp;</td>
     *         <td> <em>hEvent</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Query the status of all device work preceding the most recent call to
     *       cuEventRecord() (in the appropriate compute streams, as specified by
     *       the arguments to cuEventRecord()).
     *     <p>
     *       If this work has successfully been completed by the device, or if
     *       cuEventRecord() has not been called on <code>hEvent</code>, then
     *       CUDA_SUCCESS is returned. If this work has not yet been completed by
     *       the device then CUDA_ERROR_NOT_READY is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_NOT_READY
     *
     *
     * @see JCudaDriver#cuEventCreate
     * @see JCudaDriver#cuEventRecord
     * @see JCudaDriver#cuEventSynchronize
     * @see JCudaDriver#cuEventDestroy
     * @see JCudaDriver#cuEventElapsedTime
     */
    public static int cuEventQuery(CUevent hEvent)
    {
        return checkResult(cuEventQueryNative(hEvent));
    }

    private static native int cuEventQueryNative(CUevent hEvent);


    /**
     * Waits for an event to complete.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuEventSynchronize           </td>
     *         <td>(</td>
     *         <td>CUevent&nbsp;</td>
     *         <td> <em>hEvent</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Wait until the completion of all device work preceding the most recent
     *       call to cuEventRecord() (in the appropriate compute streams, as
     *       specified by the arguments to cuEventRecord()).
     *     <p>
     *       If cuEventRecord() has not been called on <code>hEvent</code>,
     *       CUDA_SUCCESS is returned immediately.
     *     <p>
     *       Waiting for an event that was created with the CU_EVENT_BLOCKING_SYNC
     *       flag will cause the calling CPU thread to block until the event has
     *       been completed by the device. If the CU_EVENT_BLOCKING_SYNC flag has
     *       not been set, then the CPU thread will busy-wait until the event has
     *       been completed by the device.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE
     *
     * @see JCudaDriver#cuEventCreate
     * @see JCudaDriver#cuEventRecord
     * @see JCudaDriver#cuEventQuery
     * @see JCudaDriver#cuEventDestroy
     * @see JCudaDriver#cuEventElapsedTime
     */
    public static int cuEventSynchronize(CUevent hEvent)
    {
        return checkResult(cuEventSynchronizeNative(hEvent));
    }

    private static native int cuEventSynchronizeNative(CUevent hEvent);


    /**
     * Destroys an event.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuEventDestroy           </td>
     *         <td>(</td>
     *         <td>CUevent&nbsp;</td>
     *         <td> <em>hEvent</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Destroys the event specified by <code>hEvent</code>.
     *     <p>
     *       In the case that <code>hEvent</code> has been recorded but has not yet
     *       been completed when cuEventDestroy() is called, the function will
     *       return immediately and the resources associated with <code>hEvent</code>
     *       will be released automatically once the device has completed
     *       <code>hEvent</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE
     *
     * @see JCudaDriver#cuEventCreate
     * @see JCudaDriver#cuEventRecord
     * @see JCudaDriver#cuEventQuery
     * @see JCudaDriver#cuEventSynchronize
     * @see JCudaDriver#cuEventElapsedTime
     */
    public static int cuEventDestroy(CUevent hEvent)
    {
        return checkResult(cuEventDestroyNative(hEvent));
    }

    private static native int cuEventDestroyNative(CUevent hEvent);


    /**
     * Computes the elapsed time between two events.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuEventElapsedTime           </td>
     *         <td>(</td>
     *         <td>float *&nbsp;</td>
     *         <td> <em>pMilliseconds</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUevent&nbsp;</td>
     *         <td> <em>hStart</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUevent&nbsp;</td>
     *         <td> <em>hEnd</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Computes the elapsed time between two events (in milliseconds with a
     *       resolution of around 0.5 microseconds).
     *     <p>
     *       If either event was last recorded in a non-NULL stream, the resulting
     *       time may be greater than expected (even if both used the same stream
     *       handle). This happens because the cuEventRecord() operation takes place
     *       asynchronously and there is no guarantee that the measured latency is
     *       actually just between the two events. Any number of other different
     *       stream operations could execute in between the two measured events,
     *       thus altering the timing in a significant way.
     *     <p>
     *       If cuEventRecord() has not been called on either event then
     *       CUDA_ERROR_INVALID_HANDLE is returned. If cuEventRecord() has been
     *       called on both events but one or both of them has not yet been completed
     *       (that is, cuEventQuery() would return CUDA_ERROR_NOT_READY on at least
     *       one of the events), CUDA_ERROR_NOT_READY is returned. If either event
     *       was created with the CU_EVENT_DISABLE_TIMING flag, then this function
     *       will return CUDA_ERROR_INVALID_HANDLE.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_NOT_READY
     *
     *
     * @see JCudaDriver#cuEventCreate
     * @see JCudaDriver#cuEventRecord
     * @see JCudaDriver#cuEventQuery
     * @see JCudaDriver#cuEventSynchronize
     * @see JCudaDriver#cuEventDestroy
     */
    public static int cuEventElapsedTime(float pMilliseconds[], CUevent hStart, CUevent hEnd)
    {
        return checkResult(cuEventElapsedTimeNative(pMilliseconds, hStart, hEnd));
    }

    private static native int cuEventElapsedTimeNative(float pMilliseconds[], CUevent hStart, CUevent hEnd);


    /**
     * Returns information about a pointer.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuPointerGetAttribute           </td>
     *         <td>(</td>
     *         <td>void *&nbsp;</td>
     *         <td> <em>data</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUpointer_attribute&nbsp;</td>
     *         <td> <em>attribute</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdeviceptr&nbsp;</td>
     *         <td> <em>ptr</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       The supported attributes are:
     *     <p>
     *     <ul>
     *       <li>CU_POINTER_ATTRIBUTE_CONTEXT:</li>
     *     </ul>
     *     <p>
     *       Returns in <code>*data</code> the CUcontext in which <code>ptr</code>
     *       was allocated or registered. The type of <code>data</code> must be
     *       CUcontext *.
     *     <p>
     *       If <code>ptr</code> was not allocated by, mapped by, or registered with
     *       a CUcontext which uses unified virtual addressing then
     *       CUDA_ERROR_INVALID_VALUE is returned.
     *     <p>
     *     <ul>
     *       <li>CU_POINTER_ATTRIBUTE_MEMORY_TYPE:</li>
     *     </ul>
     *     <p>
     *       Returns in <code>*data</code> the physical memory type of the memory
     *       that <code>ptr</code> addresses as a CUmemorytype enumerated value.
     *       The type of <code>data</code> must be unsigned int.
     *     <p>
     *       If <code>ptr</code> addresses device memory then <code>*data</code> is
     *       set to CU_MEMORYTYPE_DEVICE. The particular CUdevice on which the
     *       memory resides is the CUdevice of the CUcontext returned by the
     *       CU_POINTER_ATTRIBUTE_CONTEXT attribute of <code>ptr</code>.
     *     <p>
     *       If <code>ptr</code> addresses host memory then <code>*data</code> is
     *       set to CU_MEMORYTYPE_HOST.
     *     <p>
     *       If <code>ptr</code> was not allocated by, mapped by, or registered with
     *       a CUcontext which uses unified virtual addressing then
     *       CUDA_ERROR_INVALID_VALUE is returned.
     *     <p>
     *       If the current CUcontext does not support unified virtual addressing
     *       then CUDA_ERROR_INVALID_CONTEXT is returned.
     *     <p>
     *     <ul>
     *       <li>CU_POINTER_ATTRIBUTE_DEVICE_POINTER:</li>
     *     </ul>
     *     <p>
     *       Returns in <code>*data</code> the device pointer value through which
     *       <code>ptr</code> may be accessed by kernels running in the current
     *       CUcontext. The type of <code>data</code> must be CUdeviceptr *.
     *     <p>
     *       If there exists no device pointer value through which kernels running
     *       in the current CUcontext may access <code>ptr</code> then
     *       CUDA_ERROR_INVALID_VALUE is returned.
     *     <p>
     *       If there is no current CUcontext then CUDA_ERROR_INVALID_CONTEXT is
     *       returned.
     *     <p>
     *       Except in the exceptional disjoint addressing cases discussed below,
     *       the value returned in <code>*data</code> will equal the input value
     *       <code>ptr</code>.
     *     <p>
     *     <ul>
     *       <li>CU_POINTER_ATTRIBUTE_HOST_POINTER:</li>
     *     </ul>
     *     <p>
     *       Returns in <code>*data</code> the host pointer value through which
     *       <code>ptr</code> may be accessed by by the host program. The type of
     *       <code>data</code> must be void **. If there exists no host pointer
     *       value through which the host program may directly access <code>ptr</code>
     *       then CUDA_ERROR_INVALID_VALUE is returned.
     *     <p>
     *       Except in the exceptional disjoint addressing cases discussed below,
     *       the value returned in <code>*data</code> will equal the input value
     *       <code>ptr</code>.
     *     <p>
     *     <dl compact>
     *       <dt><b></b></dt>
     *       <dd></dd>
     *     </dl>
     *     Note that for most allocations in the unified virtual address space
     *     the host and device pointer for accessing the allocation will be the
     *     same. The exceptions to this are
     *     <ul>
     *       <li>user memory registered using cuMemHostRegister</li>
     *       <li>host memory
     *         allocated using cuMemHostAlloc with the CU_MEMHOSTALLOC_WRITECOMBINED
     *         flag For these types of allocation there will exist separate, disjoint
     *         host and device addresses for accessing the allocation. In
     *         particular
     *       </li>
     *       <li>The host address will correspond to an invalid
     *         unmapped device address (which will result in an exception if accessed
     *         from the device)
     *       </li>
     *       <li>The device address will correspond to an
     *         invalid unmapped host address (which will result in an exception if
     *         accessed from the host). For these types of allocations, querying
     *         CU_POINTER_ATTRIBUTE_HOST_POINTER and CU_POINTER_ATTRIBUTE_DEVICE_POINTER
     *         may be used to retrieve the host and device addresses from either
     *         address.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_DEVICE
     *
     * @see JCudaDriver#cuMemAlloc
     * @see JCudaDriver#cuMemFree
     * @see JCudaDriver#cuMemAllocHost
     * @see JCudaDriver#cuMemFreeHost
     * @see JCudaDriver#cuMemHostAlloc
     * @see JCudaDriver#cuMemHostRegister
     * @see JCudaDriver#cuMemHostUnregister
     */
    public static int cuPointerGetAttribute(Pointer data, int attribute, CUdeviceptr ptr)
    {
        return checkResult(cuPointerGetAttributeNative(data, attribute, ptr));
    }

    private static native int cuPointerGetAttributeNative(Pointer data, int attribute, CUdeviceptr ptr);


    /**
     * Create a stream.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuStreamCreate           </td>
     *         <td>(</td>
     *         <td>CUstream *&nbsp;</td>
     *         <td> <em>phStream</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates a stream and returns a handle in <code>phStream</code>.
     *       <code>Flags</code> is required to be 0.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuStreamDestroy
     * @see JCudaDriver#cuStreamWaitEvent
     * @see JCudaDriver#cuStreamQuery
     * @see JCudaDriver#cuStreamSynchronize
     */
    public static int cuStreamCreate(CUstream phStream, int Flags)
    {
        return checkResult(cuStreamCreateNative(phStream, Flags));
    }

    private static native int cuStreamCreateNative(CUstream phStream, int Flags);


    /**
     * Make a compute stream wait on an event.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuStreamWaitEvent           </td>
     *         <td>(</td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUevent&nbsp;</td>
     *         <td> <em>hEvent</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Makes all future work submitted to <code>hStream</code> wait until
     *       <code>hEvent</code> reports completion before beginning execution. This
     *       synchronization will be performed efficiently on the device. The event
     *       <code>hEvent</code> may be from a different context than
     *       <code>hStream</code>, in which case this function will perform
     *       cross-device synchronization.
     *     <p>
     *       The stream <code>hStream</code> will wait only for the completion of
     *       the most recent host call to cuEventRecord() on <code>hEvent</code>.
     *       Once this call has returned, any functions (including cuEventRecord()
     *       and cuEventDestroy()) may be called on <code>hEvent</code> again, and
     *       the subsequent calls will not have any effect on
     *       <code>hStream</code>.
     *     <p>
     *       If <code>hStream</code> is 0 (the NULL stream) any future work submitted
     *       in any stream will wait for <code>hEvent</code> to complete before
     *       beginning execution. This effectively creates a barrier for all future
     *       work submitted to the context.
     *     <p>
     *       If cuEventRecord() has not been called on <code>hEvent</code>, this
     *       call acts as if the record has already completed, and so is a functional
     *       no-op.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     *
     * @see JCudaDriver#cuStreamCreate
     * @see JCudaDriver#cuEventRecord
     * @see JCudaDriver#cuStreamQuery
     * @see JCudaDriver#cuStreamSynchronize
     * @see JCudaDriver#cuStreamDestroy
     */
    public static int cuStreamWaitEvent(CUstream hStream, CUevent hEvent, int Flags)
    {
        return checkResult(cuStreamWaitEventNative(hStream, hEvent, Flags));
    }
    private static native int cuStreamWaitEventNative(CUstream hStream, CUevent hEvent, int Flags);


    /**
     * Determine status of a compute stream.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuStreamQuery           </td>
     *         <td>(</td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns CUDA_SUCCESS if all operations in the stream specified by
     *       <code>hStream</code> have completed, or CUDA_ERROR_NOT_READY if
     *       not.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_NOT_READY
     *
     *
     * @see JCudaDriver#cuStreamCreate
     * @see JCudaDriver#cuStreamWaitEvent
     * @see JCudaDriver#cuStreamDestroy
     * @see JCudaDriver#cuStreamSynchronize
     */
    public static int cuStreamQuery(CUstream hStream)
    {
        return checkResult(cuStreamQueryNative(hStream));
    }

    private static native int cuStreamQueryNative(CUstream hStream);


    /**
     * Wait until a stream's tasks are completed.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuStreamSynchronize           </td>
     *         <td>(</td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Waits until the device has completed all operations in the stream
     *       specified by <code>hStream</code>. If the context was created with the
     *       CU_CTX_SCHED_BLOCKING_SYNC flag, the CPU thread will block until the
     *       stream is finished with all of its tasks.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE
     *
     * @see JCudaDriver#cuStreamCreate
     * @see JCudaDriver#cuStreamDestroy
     * @see JCudaDriver#cuStreamWaitEvent
     * @see JCudaDriver#cuStreamQuery
     */
    public static int cuStreamSynchronize(CUstream hStream)
    {
        return checkResult(cuStreamSynchronizeNative(hStream));
    }

    private static native int cuStreamSynchronizeNative(CUstream hStream);


    /**
     * Destroys a stream.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuStreamDestroy           </td>
     *         <td>(</td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Destroys the stream specified by <code>hStream</code>.
     *     <p>
     *       In the case that the device is still doing work in the stream
     *       <code>hStream</code> when cuStreamDestroy() is called, the function
     *       will return immediately and the resources associated with
     *       <code>hStream</code> will be released automatically once the device
     *       has completed all work in <code>hStream</code>.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuStreamCreate
     * @see JCudaDriver#cuStreamWaitEvent
     * @see JCudaDriver#cuStreamQuery
     * @see JCudaDriver#cuStreamSynchronize
     */
    public static int cuStreamDestroy(CUstream hStream)
    {
        return checkResult(cuStreamDestroyNative(hStream));
    }

    private static native int cuStreamDestroyNative(CUstream hStream);



    /**
     * Initializes OpenGL interoperability.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLInit           </td>
     *         <td>(</td>
     *         <td>void&nbsp;</td>
     *         <td>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Initializes OpenGL interoperability. This function is deprecated and
     *     calling it is no longer required. It may fail if the needed OpenGL
     *     driver facilities are not available.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_UNKNOWN
     *
     * @see JCudaDriver#cuGLCtxCreate
     * @see JCudaDriver#cuGLMapBufferObject
     * @see JCudaDriver#cuGLRegisterBufferObject
     * @see JCudaDriver#cuGLUnmapBufferObject
     * @see JCudaDriver#cuGLUnregisterBufferObject
     * @see JCudaDriver#cuGLMapBufferObjectAsync
     * @see JCudaDriver#cuGLUnmapBufferObjectAsync
     * @see JCudaDriver#cuGLSetBufferObjectMapFlags
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuGLInit()
    {
        return checkResult(cuGLInitNative());
    }
    private static native int cuGLInitNative();


    /**
     * Create a CUDA context for interoperability with OpenGL.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLCtxCreate           </td>
     *         <td>(</td>
     *         <td>CUcontext *&nbsp;</td>
     *         <td> <em>pCtx</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUdevice&nbsp;</td>
     *         <td> <em>device</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Creates a new CUDA context, initializes OpenGL interoperability, and
     *       associates the CUDA context with the calling thread. It must be called
     *       before performing any other OpenGL interoperability operations. It may
     *       fail if the needed OpenGL driver facilities are not available. For
     *       usage of the <code>Flags</code> parameter, see cuCtxCreate().
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_OUT_OF_MEMORY
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuGLInit
     * @see JCudaDriver#cuGLMapBufferObject
     * @see JCudaDriver#cuGLRegisterBufferObject
     * @see JCudaDriver#cuGLUnmapBufferObject
     * @see JCudaDriver#cuGLUnregisterBufferObject
     * @see JCudaDriver#cuGLMapBufferObjectAsync
     * @see JCudaDriver#cuGLUnmapBufferObjectAsync
     * @see JCudaDriver#cuGLSetBufferObjectMapFlags
     */
    public static int cuGLCtxCreate( CUcontext pCtx, int Flags, CUdevice device )
    {
        return checkResult(cuGLCtxCreateNative(pCtx, Flags, device));
    }
    private static native int cuGLCtxCreateNative(CUcontext pCtx, int Flags, CUdevice device);


    /**
     * Registers an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGraphicsGLRegisterBuffer           </td>
     *         <td>(</td>
     *         <td>CUgraphicsResource *&nbsp;</td>
     *         <td> <em>pCudaResource</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Registers the buffer object specified by <code>buffer</code> for access
     *       by CUDA. A handle to the registered object is returned as
     *       <code>pCudaResource</code>. The register flags <code>Flags</code>
     *       specify the intended usage, as follows:
     *     <p>
     *     <ul>
     *       <li>CU_GRAPHICS_REGISTER_FLAGS_NONE: Specifies no hints about how this
     *         resource will be used. It is therefore assumed that this resource will
     *         be read from and written to by CUDA. This is the default
     *         value.
     *       </li>
     *       <li>CU_GRAPHICS_REGISTER_FLAGS_READ_ONLY: Specifies that
     *         CUDA will not write to this
     *         resource.
     *       </li>
     *       <li>CU_GRAPHICS_REGISTER_FLAGS_WRITE_DISCARD: Specifies
     *         that CUDA will not read from this resource and will write over the
     *         entire contents of the resource, so none of the data previously stored
     *         in the resource will be preserved.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_ALREADY_MAPPED,
     * CUDA_ERROR_INVALID_CONTEXT,
     *
     * @see JCudaDriver#cuGLCtxCreate
     * @see JCudaDriver#cuGraphicsUnregisterResource
     * @see JCudaDriver#cuGraphicsMapResources
     * @see JCudaDriver#cuGraphicsResourceGetMappedPointer
     */
    public static int cuGraphicsGLRegisterBuffer(CUgraphicsResource pCudaResource, int buffer, int Flags)
    {
        return checkResult(cuGraphicsGLRegisterBufferNative(pCudaResource, buffer, Flags));
    }
    private static native int cuGraphicsGLRegisterBufferNative(CUgraphicsResource pCudaResource, int buffer, int Flags);




    /**
     * Register an OpenGL texture or renderbuffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGraphicsGLRegisterImage           </td>
     *         <td>(</td>
     *         <td>CUgraphicsResource *&nbsp;</td>
     *         <td> <em>pCudaResource</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>image</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLenum&nbsp;</td>
     *         <td> <em>target</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Registers the texture or renderbuffer object specified by
     *       <code>image</code> for access by CUDA. <code>target</code> must match
     *       the type of the object. A handle to the registered object is returned
     *       as <code>pCudaResource</code>. The register flags <code>Flags</code>
     *       specify the intended usage, as follows:
     *     <p>
     *     <ul>
     *       <li>CU_GRAPHICS_REGISTER_FLAGS_NONE: Specifies no hints about how this
     *         resource will be used. It is therefore assumed that this resource will
     *         be read from and written to by CUDA. This is the default
     *         value.
     *       </li>
     *       <li>CU_GRAPHICS_REGISTER_FLAGS_READ_ONLY: Specifies that
     *         CUDA will not write to this
     *         resource.
     *       </li>
     *       <li>CU_GRAPHICS_REGISTER_FLAGS_WRITE_DISCARD: Specifies
     *         that CUDA will not read from this resource and will write over the
     *         entire contents of the resource, so none of the data previously stored
     *         in the resource will be preserved.
     *       </li>
     *       <li>CU_GRAPHICS_REGISTER_FLAGS_SURFACE_LDST:
     *         Specifies that CUDA will bind this resource to a surface
     *         reference.
     *       </li>
     *     </ul>
     *     <p>
     *       The following image classes are currently disallowed:
     *     <ul>
     *       <li>Textures with borders</li>
     *       <li>Multisampled renderbuffers</li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_ALREADY_MAPPED,
     * CUDA_ERROR_INVALID_CONTEXT,
     *
     * @see JCudaDriver#cuGLCtxCreate
     * @see JCudaDriver#cuGraphicsUnregisterResource
     * @see JCudaDriver#cuGraphicsMapResources
     * @see JCudaDriver#cuGraphicsSubResourceGetMappedArray
     */
    public static int cuGraphicsGLRegisterImage(CUgraphicsResource pCudaResource, int image, int target, int Flags )
    {
        return checkResult(cuGraphicsGLRegisterImageNative(pCudaResource, image, target, Flags));
    }
    private static native int cuGraphicsGLRegisterImageNative(CUgraphicsResource pCudaResource, int image, int target, int Flags);


    /**
     * Registers an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLRegisterBufferObject           </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Registers the buffer object specified by <code>buffer</code> for access
     *     by CUDA. This function must be called before CUDA can map the buffer
     *     object. There must be a valid OpenGL context bound to the current
     *     thread when this function is called, and the buffer name is resolved
     *     by that context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_ALREADY_MAPPED
     *
     * @see JCudaDriver#cuGraphicsGLRegisterBuffer
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuGLRegisterBufferObject( int bufferobj )
    {
        return checkResult(cuGLRegisterBufferObjectNative(bufferobj));
    }
    private static native int cuGLRegisterBufferObjectNative(int bufferobj);


    /**
     * Maps an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLMapBufferObject           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>dptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>size</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Maps the buffer object specified by <code>buffer</code> into the
     *     address space of the current CUDA context and returns in
     *     <code>*dptr</code> and <code>*size</code> the base pointer and size of
     *     the resulting mapping.
     *     <p>
     *       There must be a valid OpenGL context bound to the current thread when
     *       this function is called. This must be the same context, or a member of
     *       the same shareGroup, as the context that was bound when the buffer was
     *       registered.
     *     <p>
     *       All streams in the current CUDA context are synchronized with the
     *       current GL context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_MAP_FAILED
     *
     *
     * @see JCudaDriver#cuGraphicsMapResources
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuGLMapBufferObject( CUdeviceptr dptr, long size[],  int bufferobj )
    {
        return checkResult(cuGLMapBufferObjectNative(dptr, size, bufferobj));
    }
    private static native int cuGLMapBufferObjectNative(CUdeviceptr dptr, long size[],  int bufferobj);


    /**
     * Unmaps an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLUnmapBufferObject           </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Unmaps the buffer object specified by <code>buffer</code> for access
     *     by CUDA.
     *     <p>
     *       There must be a valid OpenGL context bound to the current thread when
     *       this function is called. This must be the same context, or a member of
     *       the same shareGroup, as the context that was bound when the buffer was
     *       registered.
     *     <p>
     *       All streams in the current CUDA context are synchronized with the
     *       current GL context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuGraphicsUnmapResources
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuGLUnmapBufferObject( int bufferobj )
    {
        return checkResult(cuGLUnmapBufferObjectNative(bufferobj));
    }
    private static native int cuGLUnmapBufferObjectNative(int bufferobj);


    /**
     * Unregister an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLUnregisterBufferObject           </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Unregisters the buffer object specified by <code>buffer</code>. This
     *     releases any resources associated with the registered buffer. After
     *     this call, the buffer may no longer be mapped for access by CUDA.
     *     <p>
     *       There must be a valid OpenGL context bound to the current thread when
     *       this function is called. This must be the same context, or a member of
     *       the same shareGroup, as the context that was bound when the buffer was
     *       registered.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuGraphicsUnregisterResource
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuGLUnregisterBufferObject( int bufferobj )
    {
        return checkResult(cuGLUnregisterBufferObjectNative(bufferobj));
    }
    private static native int cuGLUnregisterBufferObjectNative(int bufferobj);



    /**
     * Set the map flags for an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLSetBufferObjectMapFlags           </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>Flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Sets the map flags for the buffer object specified by
     *     <code>buffer</code>.
     *     <p>
     *       Changes to <code>Flags</code> will take effect the next time
     *       <code>buffer</code> is mapped. The <code>Flags</code> argument may be
     *       any of the following:
     *     <ul>
     *       <li>CU_GL_MAP_RESOURCE_FLAGS_NONE: Specifies no hints about how this
     *         resource will be used. It is therefore assumed that this resource will
     *         be read from and written to by CUDA kernels. This is the default
     *         value.
     *       </li>
     *       <li>CU_GL_MAP_RESOURCE_FLAGS_READ_ONLY: Specifies that CUDA
     *         kernels which access this resource will not write to this
     *         resource.
     *       </li>
     *       <li>CU_GL_MAP_RESOURCE_FLAGS_WRITE_DISCARD: Specifies
     *         that CUDA kernels which access this resource will not read from this
     *         resource and will write over the entire contents of the resource, so
     *         none of the data previously stored in the resource will be
     *         preserved.
     *       </li>
     *     </ul>
     *     <p>
     *       If <code>buffer</code> has not been registered for use with CUDA, then
     *       CUDA_ERROR_INVALID_HANDLE is returned. If <code>buffer</code> is
     *       presently mapped for access by CUDA, then CUDA_ERROR_ALREADY_MAPPED is
     *       returned.
     *     <p>
     *       There must be a valid OpenGL context bound to the current thread when
     *       this function is called. This must be the same context, or a member of
     *       the same shareGroup, as the context that was bound when the buffer was
     *       registered.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_NOT_INITIALIZED, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_ALREADY_MAPPED, CUDA_ERROR_INVALID_CONTEXT,
     *
     * @see JCudaDriver#cuGraphicsResourceSetMapFlags
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuGLSetBufferObjectMapFlags( int buffer, int Flags )
    {
        return checkResult((cuGLSetBufferObjectMapFlagsNative(buffer, Flags)));
    }
    private static native int cuGLSetBufferObjectMapFlagsNative( int buffer, int Flags );


    /**
     * Maps an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLMapBufferObjectAsync           </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>dptr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>size</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Maps the buffer object specified by <code>buffer</code> into the
     *     address space of the current CUDA context and returns in
     *     <code>*dptr</code> and <code>*size</code> the base pointer and size of
     *     the resulting mapping.
     *     <p>
     *       There must be a valid OpenGL context bound to the current thread when
     *       this function is called. This must be the same context, or a member of
     *       the same shareGroup, as the context that was bound when the buffer was
     *       registered.
     *     <p>
     *       Stream <code>hStream</code> in the current CUDA context is synchronized
     *       with the current GL context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_MAP_FAILED
     *
     *
     * @see JCudaDriver#cuGraphicsMapResources
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuGLMapBufferObjectAsync( CUdeviceptr dptr, long size[],  int buffer, CUstream hStream)
    {
        return checkResult((cuGLMapBufferObjectAsyncNative(dptr, size, buffer, hStream)));
    }
    private static native int cuGLMapBufferObjectAsyncNative( CUdeviceptr dptr, long size[],  int buffer, CUstream hStream);


    /**
     * Unmaps an OpenGL buffer object.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGLUnmapBufferObjectAsync           </td>
     *         <td>(</td>
     *         <td>GLuint&nbsp;</td>
     *         <td> <em>buffer</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *     <dl compact>
     *       <dt><b>Deprecated:</b></dt>
     *       <dd>This function is deprecated
     *         as of Cuda 3.0.
     *       </dd>
     *     </dl>
     *     Unmaps the buffer object specified by <code>buffer</code> for access
     *     by CUDA.
     *     <p>
     *       There must be a valid OpenGL context bound to the current thread when
     *       this function is called. This must be the same context, or a member of
     *       the same shareGroup, as the context that was bound when the buffer was
     *       registered.
     *     <p>
     *       Stream <code>hStream</code> in the current CUDA context is synchronized
     *       with the current GL context.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuGraphicsUnmapResources
     *
     * @deprecated This function is deprecated in the latest CUDA version
     *
     */
    public static int cuGLUnmapBufferObjectAsync( int buffer, CUstream hStream )
    {
        return checkResult((cuGLUnmapBufferObjectAsyncNative(buffer, hStream)));
    }
    private static native int cuGLUnmapBufferObjectAsyncNative( int buffer, CUstream hStream );




    /**
     * Unregisters a graphics resource for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGraphicsUnregisterResource           </td>
     *         <td>(</td>
     *         <td>CUgraphicsResource&nbsp;</td>
     *         <td> <em>resource</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Unregisters the graphics resource <code>resource</code> so it is not
     *       accessible by CUDA unless registered again.
     *     <p>
     *       If <code>resource</code> is invalid then CUDA_ERROR_INVALID_HANDLE is
     *       returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_UNKNOWN
     *
     *
     * @see JCudaDriver#cuGraphicsGLRegisterBuffer
     * @see JCudaDriver#cuGraphicsGLRegisterImage
     */
    public static int cuGraphicsUnregisterResource(CUgraphicsResource resource)
    {
        return checkResult(cuGraphicsUnregisterResourceNative(resource));
    }
    private static native int cuGraphicsUnregisterResourceNative(CUgraphicsResource resource);


    /**
     * Get an array through which to access a subresource of a mapped graphics
     * resource.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGraphicsSubResourceGetMappedArray          </td>
     *         <td>(</td>
     *         <td>CUarray *&nbsp;</td>
     *         <td> <em>pArray</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUgraphicsResource&nbsp;</td>
     *         <td> <em>resource</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>arrayIndex</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>mipLevel</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pArray</code> an array through which the subresource
     *       of the mapped graphics resource <code>resource</code> which corresponds
     *       to array index <code>arrayIndex</code> and mipmap level
     *       <code>mipLevel</code> may be accessed. The value set in
     *       <code>*pArray</code> may change every time that <code>resource</code>
     *       is mapped.
     *     <p>
     *       If <code>resource</code> is not a texture then it cannot be accessed
     *       via an array and CUDA_ERROR_NOT_MAPPED_AS_ARRAY is returned. If
     *       <code>arrayIndex</code> is not a valid array index for
     *       <code>resource</code> then CUDA_ERROR_INVALID_VALUE is returned. If
     *       <code>mipLevel</code> is not a valid mipmap level for <code>resource</code>
     *       then CUDA_ERROR_INVALID_VALUE is returned. If <code>resource</code> is
     *       not mapped then CUDA_ERROR_NOT_MAPPED is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_NOT_MAPPED
     * CUDA_ERROR_NOT_MAPPED_AS_ARRAY
     *
     * @see JCudaDriver#cuGraphicsResourceGetMappedPointer
     */
    public static int cuGraphicsSubResourceGetMappedArray(CUarray pArray, CUgraphicsResource resource, int arrayIndex, int mipLevel)
    {
        return checkResult(cuGraphicsSubResourceGetMappedArrayNative(pArray, resource, arrayIndex, mipLevel));
    }
    private static native int cuGraphicsSubResourceGetMappedArrayNative(CUarray pArray, CUgraphicsResource resource, int arrayIndex, int mipLevel);


    /**
     * Get a device pointer through which to access a mapped graphics
     * resource.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGraphicsResourceGetMappedPointer          </td>
     *         <td>(</td>
     *         <td>CUdeviceptr *&nbsp;</td>
     *         <td> <em>pDevPtr</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>pSize</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUgraphicsResource&nbsp;</td>
     *         <td> <em>resource</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pDevPtr</code> a pointer through which the mapped
     *       graphics resource <code>resource</code> may be accessed. Returns in
     *       <code>pSize</code> the size of the memory in bytes which may be accessed
     *       from that pointer. The value set in <code>pPointer</code> may change
     *       every time that <code>resource</code> is mapped.
     *     <p>
     *       If <code>resource</code> is not a buffer then it cannot be accessed
     *       via a pointer and CUDA_ERROR_NOT_MAPPED_AS_POINTER is returned. If
     *       <code>resource</code> is not mapped then CUDA_ERROR_NOT_MAPPED is
     *       returned. *
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_NOT_MAPPED
     * CUDA_ERROR_NOT_MAPPED_AS_POINTER
     *
     * @see JCudaDriver#cuGraphicsMapResources
     * @see JCudaDriver#cuGraphicsSubResourceGetMappedArray
     */
    public static int cuGraphicsResourceGetMappedPointer( CUdeviceptr pDevPtr, long pSize[], CUgraphicsResource resource )
    {
        return checkResult(cuGraphicsResourceGetMappedPointerNative(pDevPtr, pSize, resource));
    }
    private static native int cuGraphicsResourceGetMappedPointerNative(CUdeviceptr pDevPtr, long pSize[], CUgraphicsResource resource);


    /**
     * Set usage flags for mapping a graphics resource.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGraphicsResourceSetMapFlags           </td>
     *         <td>(</td>
     *         <td>CUgraphicsResource&nbsp;</td>
     *         <td> <em>resource</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>flags</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Set <code>flags</code> for mapping the graphics resource
     *       <code>resource</code>.
     *     <p>
     *       Changes to <code>flags</code> will take effect the next time
     *       <code>resource</code> is mapped. The <code>flags</code> argument may
     *       be any of the following:
     *     <p>
     *     <ul>
     *       <li>CU_GRAPHICS_MAP_RESOURCE_FLAGS_NONE: Specifies no hints about how
     *         this resource will be used. It is therefore assumed that this resource
     *         will be read from and written to by CUDA kernels. This is the default
     *         value.
     *       </li>
     *       <li>CU_GRAPHICS_MAP_RESOURCE_FLAGS_READONLY: Specifies that
     *         CUDA kernels which access this resource will not write to this
     *         resource.
     *       </li>
     *       <li>CU_GRAPHICS_MAP_RESOURCE_FLAGS_WRITEDISCARD: Specifies
     *         that CUDA kernels which access this resource will not read from this
     *         resource and will write over the entire contents of the resource, so
     *         none of the data previously stored in the resource will be
     *         preserved.
     *       </li>
     *     </ul>
     *     <p>
     *       If <code>resource</code> is presently mapped for access by CUDA then
     *       CUDA_ERROR_ALREADY_MAPPED is returned. If <code>flags</code> is not
     *       one of the above values then CUDA_ERROR_INVALID_VALUE is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE,
     * CUDA_ERROR_INVALID_HANDLE, CUDA_ERROR_ALREADY_MAPPED
     *
     * @see JCudaDriver#cuGraphicsMapResources
     */
    public static int cuGraphicsResourceSetMapFlags( CUgraphicsResource resource, int flags )
    {
        return checkResult(cuGraphicsResourceSetMapFlagsNative(resource, flags));
    }
    private static native int cuGraphicsResourceSetMapFlagsNative( CUgraphicsResource resource, int flags );


    /**
     * Map graphics resources for access by CUDA.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGraphicsMapResources           </td>
     *         <td>(</td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUgraphicsResource *&nbsp;</td>
     *         <td> <em>resources</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Maps the <code>count</code> graphics resources in <code>resources</code>
     *       for access by CUDA.
     *     <p>
     *       The resources in <code>resources</code> may be accessed by CUDA until
     *       they are unmapped. The graphics API from which <code>resources</code>
     *       were registered should not access any resources while they are mapped
     *       by CUDA. If an application does so, the results are undefined.
     *     <p>
     *       This function provides the synchronization guarantee that any graphics
     *       calls issued before cuGraphicsMapResources() will complete before any
     *       subsequent CUDA work issued in <code>stream</code> begins.
     *     <p>
     *       If <code>resources</code> includes any duplicate entries then
     *       CUDA_ERROR_INVALID_HANDLE is returned. If any of <code>resources</code>
     *       are presently mapped for access by CUDA then CUDA_ERROR_ALREADY_MAPPED
     *       is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_ALREADY_MAPPED, CUDA_ERROR_UNKNOWN
     *
     * @see JCudaDriver#cuGraphicsResourceGetMappedPointer
     */
    public static int cuGraphicsMapResources(int count, CUgraphicsResource resources[], CUstream hStream)
    {
        return checkResult(cuGraphicsMapResourcesNative(count, resources, hStream));
    }
    private static native int cuGraphicsMapResourcesNative(int count, CUgraphicsResource resources[], CUstream hStream);


    /**
     * Unmap graphics resources.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuGraphicsUnmapResources           </td>
     *         <td>(</td>
     *         <td>unsigned int&nbsp;</td>
     *         <td> <em>count</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUgraphicsResource *&nbsp;</td>
     *         <td> <em>resources</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUstream&nbsp;</td>
     *         <td> <em>hStream</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Unmaps the <code>count</code> graphics resources in
     *       <code>resources</code>.
     *     <p>
     *       Once unmapped, the resources in <code>resources</code> may not be
     *       accessed by CUDA until they are mapped again.
     *     <p>
     *       This function provides the synchronization guarantee that any CUDA work
     *       issued in <code>stream</code> before cuGraphicsUnmapResources() will
     *       complete before any subsequently issued graphics work begins.
     *     <p>
     *       If <code>resources</code> includes any duplicate entries then
     *       CUDA_ERROR_INVALID_HANDLE is returned. If any of <code>resources</code>
     *       are not presently mapped for access by CUDA then CUDA_ERROR_NOT_MAPPED
     *       is returned.
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_HANDLE,
     * CUDA_ERROR_NOT_MAPPED, CUDA_ERROR_UNKNOWN
     *
     * @see JCudaDriver#cuGraphicsMapResources
     */
    public static int cuGraphicsUnmapResources( int count, CUgraphicsResource resources[], CUstream hStream)
    {
        return checkResult(cuGraphicsUnmapResourcesNative(count, resources, hStream));
    }
    private static native int cuGraphicsUnmapResourcesNative(int count, CUgraphicsResource resources[], CUstream hStream);



    /**
     * Set resource limits.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxSetLimit           </td>
     *         <td>(</td>
     *         <td>CUlimit&nbsp;</td>
     *         <td> <em>limit</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>size_t&nbsp;</td>
     *         <td> <em>value</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Setting <code>limit</code> to <code>value</code> is a request by the
     *       application to update the current limit maintained by the context. The
     *       driver is free to modify the requested value to meet h/w requirements
     *       (this could be clamping to minimum or maximum values, rounding up to
     *       nearest element size, etc). The application can use cuCtxGetLimit() to
     *       find out exactly what the limit has been set to.
     *     <p>
     *       Setting each CUlimit has its own specific restrictions, so each is
     *       discussed here.
     *     <p>
     *     <ul>
     *       <li>CU_LIMIT_STACK_SIZE controls the stack size of each GPU thread.
     *         This limit is only applicable to devices of compute capability 2.0 and
     *         higher. Attempting to set this limit on devices of compute capability
     *         less than 2.0 will result in the error CUDA_ERROR_UNSUPPORTED_LIMIT
     *         being returned.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_LIMIT_PRINTF_FIFO_SIZE controls the size of the FIFO used by
     *         the printf() device system call. Setting CU_LIMIT_PRINTF_FIFO_SIZE must
     *         be performed before launching any kernel that uses the printf() device
     *         system call, otherwise CUDA_ERROR_INVALID_VALUE will be returned. This
     *         limit is only applicable to devices of compute capability 2.0 and
     *         higher. Attempting to set this limit on devices of compute capability
     *         less than 2.0 will result in the error CUDA_ERROR_UNSUPPORTED_LIMIT
     *         being returned.
     *       </li>
     *     </ul>
     *     <p>
     *     <ul>
     *       <li>CU_LIMIT_MALLOC_HEAP_SIZE controls the size of the heap used by
     *         the malloc() and free() device system calls. Setting
     *         CU_LIMIT_MALLOC_HEAP_SIZE must be performed before launching any kernel
     *         that uses the malloc() or free() device system calls, otherwise
     *         CUDA_ERROR_INVALID_VALUE will be returned. This limit is only applicable
     *         to devices of compute capability 2.0 and higher. Attempting to set this
     *         limit on devices of compute capability less than 2.0 will result in
     *         the error CUDA_ERROR_UNSUPPORTED_LIMIT being returned.
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_UNSUPPORTED_LIMIT
     *
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSynchronize
     */
    public static int cuCtxSetLimit(int limit, long value)
    {
        return checkResult(cuCtxSetLimitNative(limit, value));
    }
    private static native int cuCtxSetLimitNative(int limit, long value);



    /**
     * Returns the preferred cache configuration for the current context.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxGetCacheConfig           </td>
     *         <td>(</td>
     *         <td>CUfunc_cache *&nbsp;</td>
     *         <td> <em>pconfig</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       On devices where the L1 cache and shared memory use the same hardware
     *       resources, this returns through <code>pconfig</code> the preferred
     *       cache configuration for the current context. This is only a preference.
     *       The driver will use the requested configuration if possible, but it is
     *       free to choose a different configuration if required to execute
     *       functions.
     *     <p>
     *       This will return a <code>pconfig</code> of CU_FUNC_CACHE_PREFER_NONE
     *       on devices where the size of the L1 cache and shared memory are
     *       fixed.
     *     <p>
     *       The supported cache configurations are:
     *     <ul>
     *       <li>CU_FUNC_CACHE_PREFER_NONE: no preference for shared memory or L1
     *         (default)
     *       </li>
     *       <li>CU_FUNC_CACHE_PREFER_SHARED: prefer larger shared
     *         memory and smaller L1 cache
     *       </li>
     *       <li>CU_FUNC_CACHE_PREFER_L1: prefer
     *         larger L1 cache and smaller shared memory
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     * @see JCudaDriver#cuFuncSetCacheConfig
     */
    public static int cuCtxGetCacheConfig(int pconfig[])
    {
        return checkResult(cuCtxGetCacheConfigNative(pconfig));
    }
    private static native int cuCtxGetCacheConfigNative(int[] pconfig);

    /**
     * Sets the preferred cache configuration for the current context.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxSetCacheConfig           </td>
     *         <td>(</td>
     *         <td>CUfunc_cache&nbsp;</td>
     *         <td> <em>config</em>          </td>
     *         <td>&nbsp;)&nbsp;</td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       On devices where the L1 cache and shared memory use the same hardware
     *       resources, this sets through <code>config</code> the preferred cache
     *       configuration for the current context. This is only a preference. The
     *       driver will use the requested configuration if possible, but it is free
     *       to choose a different configuration if required to execute the function.
     *       Any function preference set via cuFuncSetCacheConfig() will be preferred
     *       over this context-wide setting. Setting the context-wide cache
     *       configuration to CU_FUNC_CACHE_PREFER_NONE will cause subsequent kernel
     *       launches to prefer to not change the cache configuration unless required
     *       to launch the kernel.
     *     <p>
     *       This setting does nothing on devices where the size of the L1 cache
     *       and shared memory are fixed.
     *     <p>
     *       Launching a kernel with a different preference than the most recent
     *       preference setting may insert a device-side synchronization point.
     *     <p>
     *       The supported cache configurations are:
     *     <ul>
     *       <li>CU_FUNC_CACHE_PREFER_NONE: no preference for shared memory or L1
     *         (default)
     *       </li>
     *       <li>CU_FUNC_CACHE_PREFER_SHARED: prefer larger shared
     *         memory and smaller L1 cache
     *       </li>
     *       <li>CU_FUNC_CACHE_PREFER_L1: prefer
     *         larger L1 cache and smaller shared memory
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_DEINITIALIZED, CUDA_ERROR_NOT_INITIALIZED,
     * CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_INVALID_VALUE
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxGetLimit
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     * @see JCudaDriver#cuFuncSetCacheConfig
     */
    public static int cuCtxSetCacheConfig(int config)
    {
        return checkResult(cuCtxSetCacheConfigNative(config));
    }
    private static native int cuCtxSetCacheConfigNative(int config);


    public static int cuLaunchKernel(
        CUfunction f,
        int gridDimX,
        int gridDimY,
        int gridDimZ,
        int blockDimX,
        int blockDimY,
        int blockDimZ,
        int sharedMemBytes,
        CUstream hStream,
        Pointer kernelParams,
        Pointer extra)
    {
        return checkResult(cuLaunchKernelNative(f, gridDimX, gridDimY, gridDimZ, blockDimX, blockDimY, blockDimZ, sharedMemBytes, hStream, kernelParams, extra));
    }

    private static native int cuLaunchKernelNative(
        CUfunction f,
        int gridDimX,
        int gridDimY,
        int gridDimZ,
        int blockDimX,
        int blockDimY,
        int blockDimZ,
        int sharedMemBytes,
        CUstream hStream,
        Pointer kernelParams,
        Pointer extra);

    /**
     * Returns resource limits.
     *
     * <div>
     *   <div>
     *     <table>
     *       <tr>
     *         <td>CUresult cuCtxGetLimit           </td>
     *         <td>(</td>
     *         <td>size_t *&nbsp;</td>
     *         <td> <em>pvalue</em>, </td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td></td>
     *         <td>CUlimit&nbsp;</td>
     *         <td> <em>limit</em></td>
     *         <td>&nbsp;</td>
     *       </tr>
     *       <tr>
     *         <td></td>
     *         <td>)</td>
     *         <td></td>
     *         <td></td>
     *         <td></td>
     *       </tr>
     *     </table>
     *   </div>
     *   <div>
     *     <p>
     *       Returns in <code>*pvalue</code> the current size of <code>limit</code>.
     *       The supported CUlimit values are:
     *     <ul>
     *       <li>CU_LIMIT_STACK_SIZE: stack size of each GPU
     *         thread;
     *       </li>
     *       <li>CU_LIMIT_PRINTF_FIFO_SIZE: size of the FIFO used by
     *         the printf() device system call.
     *       </li>
     *       <li>CU_LIMIT_MALLOC_HEAP_SIZE:
     *         size of the heap used by the malloc() and free() device system
     *         calls;
     *       </li>
     *     </ul>
     *     <p>
     *   </div>
     * </div>
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_UNSUPPORTED_LIMIT
     *
     *
     * @see JCudaDriver#cuCtxCreate
     * @see JCudaDriver#cuCtxDestroy
     * @see JCudaDriver#cuCtxGetCacheConfig
     * @see JCudaDriver#cuCtxGetDevice
     * @see JCudaDriver#cuCtxPopCurrent
     * @see JCudaDriver#cuCtxPushCurrent
     * @see JCudaDriver#cuCtxSetCacheConfig
     * @see JCudaDriver#cuCtxSetLimit
     * @see JCudaDriver#cuCtxSynchronize
     */
    public static int cuCtxGetLimit(long pvalue[], int limit)
    {
        return checkResult(cuCtxGetLimitNative(pvalue, limit));
    }
    private static native int cuCtxGetLimitNative(long pvalue[], int limit);




    /**
     * Initialize the profiling.<br />
     * <br />
     * cuProfilerInitialize is used to programmatically initialize the profiling. Using
     * this API user can specify config file, output file and output file format. This
     * API is generally used to profile different set of counters by looping the kernel launch. configFile
     * parameter can be used to load new set of counters for profiling.<br />
     * <br />
     * Configurations defined initially by environment variable settings are overwritten
     * by cuProfilerInitialize().<br />
     * <br />
     * Limitation: Profiling APIs do not work when the application is running with any profiler tool.
     * User must handle error CUDA_ERROR_PROFILER_DISABLED returned by profiler APIs if
     * application is likely to be used with any profiler tool.<br />
     * <br />
     * @param configFile Name of the config file that lists the counters for profiling.
     * @param outputFile Name of the outputFile where the profiling results will be stored.
     * @param outputMode outputMode, can be CU_OUT_KEY_VALUE_PAIR or CU_OUT_CSV.
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_VALUE, CUDA_ERROR_PROFILER_DISABLED
     *
     * @see JCudaDriver#cuProfilerStart
     * @see JCudaDriver#cuProfilerStop
     */
    public static int cuProfilerInitialize(String configFile, String outputFile, int outputMode)
    {
        return checkResult(cuProfilerInitializeNative(configFile, outputFile, outputMode));
    }
    private static native int cuProfilerInitializeNative(String configFile, String outputFile, int outputMode);

    /**
     * Start the profiling.<br />
     * <br />
     * cuProfilerStart/cuProfilerStop is used to programmatically control the profiling duration.
     * APIs give added benefit of controlling the profiling granularity i.e. allow profiling to be
     * done only on selective pieces of code.<br />
     * <br />
     * cuProfilerStart() can also be used to selectively start profiling on a particular context even
     * when profiling is NOT ENABLED using environment variable. Profiling structures must be initialized
     * using cuProfilerInitialize() before making a call to cuProfilerStart().<br />
     * <br />
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_PROFILER_DISABLED,
     * CUDA_ERROR_PROFILER_ALREADY_STARTED
     *
     * @see JCudaDriver#cuProfilerInitialize
     * @see JCudaDriver#cuProfilerStop
     */
    public static int cuProfilerStart()
    {
        return checkResult(cuProfilerStartNative());
    }
    private static native int cuProfilerStartNative();

    /**
     * Stop the profiling. <br />
     * <br />
     * This API can be used in conjunction with cuProfilerStart to selectively profile subsets of the
     * CUDA program.<br />
     * cuProfilerStop() can also be used to stop profiling for current context even when profiling is
     * NOT ENABLED using environment variable. Profiling structures must be initialized using
     * cuProfilerInitialize() before making a call to cuProfilerStop().<br />
     *
     * @return CUDA_SUCCESS, CUDA_ERROR_INVALID_CONTEXT, CUDA_ERROR_PROFILER_DISABLED,
     * CUDA_ERROR_PROFILER_ALREADY_STOPPED
     *
     * @see JCudaDriver#cuProfilerInitialize
     * @see JCudaDriver#cuProfilerStart
     */
    public static int cuProfilerStop()
    {
        return checkResult(cuProfilerStopNative());
    }
    private static native int cuProfilerStopNative();


    
    



}





