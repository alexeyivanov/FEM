/*
 * JCufft - Java bindings for CUFFT, the NVIDIA CUDA FFT library,
 * to be used with JCuda
 *
 * Copyright (c) 2008 Marco Hutter - http://www.jcuda.org
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include "JCufft.hpp"
#include "JCufft_common.hpp"
#include <iostream>
#include <cuda_runtime.h>

jfieldID cufftHandle_plan; // int


/**
 * Initializes JCufft and the CUDA device
 */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *jvm, void *reserved)
{
    JNIEnv *env = NULL;
    if (jvm->GetEnv((void **)&env, JNI_VERSION_1_4))
    {
        return JNI_ERR;
    }
    Logger::log(LOG_TRACE, "Initializing JCufft\n");

    jclass cls = NULL;

    // Initialize the JNIUtils and PointerUtils
    if (initJNIUtils(env) == JNI_ERR) return JNI_ERR;
    if (initPointerUtils(env) == JNI_ERR) return JNI_ERR;

    // Obtain the methodID for cufftHandle#plan
    if (!init(env, cls, "jcuda/jcufft/cufftHandle")) return JNI_ERR;
    if (!init(env, cls, cufftHandle_plan, "plan", "I")) return JNI_ERR;

    return JNI_VERSION_1_4;
}

/*
 * Set the log level
 *
 * Class:     jcuda_jcufft_JCufft
 * Method:    setLogLevel
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_jcuda_jcufft_JCufft_setLogLevel
  (JNIEnv *env, jclass cla, jint logLevel)
{
    Logger::setLogLevel((LogLevel)logLevel);
}


/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftGetVersionNative
 * Signature: ([I)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftGetVersionNative
  (JNIEnv *env, jclass cls, jintArray version)
{
    if (version == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'version' is null for cufftGetVersion");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftGetVersion\n");

	int nativeVersion = 0;
	int result = cufftGetVersion(&nativeVersion);
	set(env, version, 0, nativeVersion);
    return result;
}



/**
 * Returns the cufftType enum element that corresponds to
 * the given int value
 */
cufftType getCufftType(int type)
{
    switch (type)
    {
        case 0x2A: return CUFFT_R2C;
        case 0x2C: return CUFFT_C2R;
        case 0x29: return CUFFT_C2C;
        case 0x6a: return CUFFT_D2Z;
        case 0x6c: return CUFFT_Z2D;
        case 0x69: return CUFFT_Z2Z;
    }
    Logger::log(LOG_ERROR, "Invalid cufftType specified: %d\n", type);
    return CUFFT_C2C;
}


/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftPlan1dNative
 * Signature: (Ljcuda/jcufft/JCufftHandle;III)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftPlan1dNative
  (JNIEnv *env, jclass cla, jobject handle, jint nx, jint type, jint batch)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftPlan1d");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Creating 1D plan for %d elements of type %d\n", nx, type);

    cufftHandle plan = env->GetIntField(handle, cufftHandle_plan);
    cufftResult result = cufftPlan1d(&plan, nx, getCufftType(type), batch);
    env->SetIntField(handle, cufftHandle_plan, plan);
    return result;
}

/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftPlan2dNative
 * Signature: (Ljcuda/jcufft/JCufftHandle;III)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftPlan2dNative
  (JNIEnv *env, jclass cla, jobject handle, jint nx, jint ny, jint type)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftPlan2d");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Creating 2D plan for (%d, %d) elements of type %d\n", nx, ny, type);

    cufftHandle plan = env->GetIntField(handle, cufftHandle_plan);
    cufftResult result = cufftPlan2d(&plan, nx, ny, getCufftType(type));
    env->SetIntField(handle, cufftHandle_plan, plan);
    return result;
}

/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftPlan3dNative
 * Signature: (Ljcuda/jcufft/JCufftHandle;IIII)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftPlan3dNative
  (JNIEnv *env, jclass cla, jobject handle, jint nx, jint ny, jint nz, jint type)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftPlan3d");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Creating 3D plan for (%d, %d, %d) elements of type %d\n", nx, ny, nz, type);

    cufftHandle plan = env->GetIntField(handle, cufftHandle_plan);
    cufftResult result = cufftPlan3d(&plan, nx, ny, nz, getCufftType(type));
    env->SetIntField(handle, cufftHandle_plan, plan);
    return result;
}


/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftPlanManyNative
 * Signature: (Ljcuda/jcufft/cufftHandle;I[I[III[IIIII)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftPlanManyNative
  (JNIEnv *env, jclass cla, jobject handle, jint rank, jintArray n, jintArray inembed, jint istride, jint idist, jintArray onembed, jint ostride, jint odist, jint type, jint batch)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftPlanMany");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (n == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'n' is null for cufftPlanMany");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (inembed == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'inembed' is null for cufftPlanMany");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (onembed == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'onembed' is null for cufftPlanMany");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftPlanMany\n");

    cufftHandle plan = env->GetIntField(handle, cufftHandle_plan);
	int *nativeN = getArrayContents(env, n);
	int *nativeInembed = getArrayContents(env, inembed);
	int *nativeOnembed = getArrayContents(env, onembed);

    cufftResult result = cufftPlanMany(&plan, rank, nativeN, nativeInembed, (int)istride, (int)idist, nativeOnembed, (int)ostride, (int)odist, getCufftType(type), (int)batch);

    delete[] nativeN;
    delete[] nativeInembed;
    delete[] nativeOnembed;
    env->SetIntField(handle, cufftHandle_plan, plan);
    return result;

}



/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftDestroyNative
 * Signature: (Ljcuda/jcufft/JCufftHandle;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftDestroyNative
  (JNIEnv *env, jclass cla, jobject handle)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftDestroy");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Destroying plan\n");

    cufftHandle plan = env->GetIntField(handle, cufftHandle_plan);
    cufftResult result = cufftDestroy(plan);
    return result;
}


//=== Single precision =======================================================

/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftExecC2CNative
 * Signature: (Ljcuda/jcufft/cufftHandle;Ljcuda/Pointer;Ljcuda/Pointer;I)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftExecC2CNative
  (JNIEnv *env, jclass cla, jobject handle, jobject cIdata, jobject cOdata, jint direction)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftExecC2C");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (cIdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'cIdata' is null for cufftExecC2C");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (cOdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'cOdata' is null for cufftExecC2C");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftExecC2C\n");

    cufftHandle nativePlan = env->GetIntField(handle, cufftHandle_plan);
    cufftComplex* nativeCIData = (cufftComplex*)getPointer(env, cIdata);
    cufftComplex* nativeCOData = (cufftComplex*)getPointer(env, cOdata);

    cufftResult result = cufftExecC2C(nativePlan, nativeCIData, nativeCOData, direction);
    return result;
}

/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftExecR2CNative
 * Signature: (Ljcuda/jcufft/cufftHandle;Ljcuda/Pointer;Ljcuda/Pointer;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftExecR2CNative
  (JNIEnv *env, jclass cla, jobject handle, jobject rIdata, jobject cOdata)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftExecR2C");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (rIdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'rIdata' is null for cufftExecR2C");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (cOdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'cOdata' is null for cufftExecR2C");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftExecR2C\n");

    cufftHandle nativePlan = env->GetIntField(handle, cufftHandle_plan);
    float* nativeRIData = (float*)getPointer(env, rIdata);
    cufftComplex* nativeCOData = (cufftComplex*)getPointer(env, cOdata);

    cufftResult result = cufftExecR2C(nativePlan, nativeRIData, nativeCOData);
    return result;
}

/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftExecC2RNative
 * Signature: (Ljcuda/jcufft/cufftHandle;Ljcuda/Pointer;Ljcuda/Pointer;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftExecC2RNative
  (JNIEnv *env, jclass cla, jobject handle, jobject cIdata, jobject rOdata)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftExecC2R");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (cIdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'cIdata' is null for cufftExecC2R");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (rOdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'rOdata' is null for cufftExecC2R");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftExecC2R\n");

    cufftHandle nativePlan = env->GetIntField(handle, cufftHandle_plan);
    cufftComplex* nativeCIData = (cufftComplex*)getPointer(env, cIdata);
    float* nativeROData = (float*)getPointer(env, rOdata);

    cufftResult result = cufftExecC2R(nativePlan, nativeCIData, nativeROData);
    return result;
}



//=== Double precision =======================================================



/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftExecZ2ZNative
 * Signature: (Ljcuda/jcufft/cufftHandle;Ljcuda/Pointer;Ljcuda/Pointer;I)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftExecZ2ZNative
  (JNIEnv *env, jclass cla, jobject handle, jobject cIdata, jobject cOdata, jint direction)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftExecZ2Z");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (cIdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'cIdata' is null for cufftExecZ2Z");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (cOdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'cOdata' is null for cufftExecZ2Z");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftExecZ2Z\n");

    cufftHandle nativePlan = env->GetIntField(handle, cufftHandle_plan);
    cufftDoubleComplex* nativeCIData = (cufftDoubleComplex*)getPointer(env, cIdata);
    cufftDoubleComplex* nativeCOData = (cufftDoubleComplex*)getPointer(env, cOdata);

    cufftResult result = cufftExecZ2Z(nativePlan, nativeCIData, nativeCOData, direction);
    return result;
}

/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftExecD2ZNative
 * Signature: (Ljcuda/jcufft/cufftHandle;Ljcuda/Pointer;Ljcuda/Pointer;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftExecD2ZNative
  (JNIEnv *env, jclass cla, jobject handle, jobject rIdata, jobject cOdata)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftExecD2Z");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (rIdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'rIdata' is null for cufftExecD2Z");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (cOdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'cOdata' is null for cufftExecD2Z");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftExecD2Z\n");

    cufftHandle nativePlan = env->GetIntField(handle, cufftHandle_plan);
    double* nativeRIData = (double*)getPointer(env, rIdata);
    cufftDoubleComplex* nativeCOData = (cufftDoubleComplex*)getPointer(env, cOdata);

    cufftResult result = cufftExecD2Z(nativePlan, nativeRIData, nativeCOData);
    return result;
}

/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftExecZ2DNative
 * Signature: (Ljcuda/jcufft/cufftHandle;Ljcuda/Pointer;Ljcuda/Pointer;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftExecZ2DNative
  (JNIEnv *env, jclass cla, jobject handle, jobject cIdata, jobject rOdata)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftExecZ2D");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (cIdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'cIdata' is null for cufftExecZ2D");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (rOdata == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'rOdata' is null for cufftExecZ2D");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftExecZ2D\n");

    cufftHandle nativePlan = env->GetIntField(handle, cufftHandle_plan);
    cufftDoubleComplex* nativeCIData = (cufftDoubleComplex*)getPointer(env, cIdata);
    double* nativeROData = (double*)getPointer(env, rOdata);

    cufftResult result = cufftExecZ2D(nativePlan, nativeCIData, nativeROData);
    return result;
}


/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftSetStreamNative
 * Signature: (Ljcuda/jcufft/cufftHandle;Ljcuda/runtime/cudaStream_t;)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftSetStreamNative
  (JNIEnv *env, jclass cla, jobject handle, jobject stream)
{
    if (handle == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'handle' is null for cufftSetStream");
        return JCUFFT_INTERNAL_ERROR;
    }
    if (stream == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'stream' is null for cufftSetStream");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftSetStream\n");

    cufftHandle nativePlan = env->GetIntField(handle, cufftHandle_plan);
    cudaStream_t nativeStream = NULL;
    nativeStream = (cudaStream_t)getNativePointerValue(env, stream);

    cufftResult result = cufftSetStream(nativePlan, nativeStream);
    return result;
}



/*
 * Class:     jcuda_jcufft_JCufft
 * Method:    cufftSetCompatibilityModeNative
 * Signature: (Ljcuda/jcufft/cufftHandle;I)I
 */
JNIEXPORT jint JNICALL Java_jcuda_jcufft_JCufft_cufftSetCompatibilityModeNative
  (JNIEnv *env, jclass cla, jobject plan, jint mode)
{
    if (plan == NULL)
    {
        ThrowByName(env, "java/lang/NullPointerException", "Parameter 'plan' is null for cufftSetCompatibilityMode");
        return JCUFFT_INTERNAL_ERROR;
    }

    Logger::log(LOG_TRACE, "Executing cufftSetCompatibilityMode\n");

    cufftHandle nativePlan = env->GetIntField(plan, cufftHandle_plan);
	cufftCompatibility nativeMode = (cufftCompatibility)mode;

    cufftResult result = cufftSetCompatibilityMode(nativePlan, nativeMode);
    return result;
}
